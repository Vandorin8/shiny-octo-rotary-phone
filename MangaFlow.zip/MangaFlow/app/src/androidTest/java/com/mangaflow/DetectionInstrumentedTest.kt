package com.mangaflow

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mangaflow.data.Codecs
import com.mangaflow.detection.ClassicalPanelDetector
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.layout.AssemblerConfig
import com.mangaflow.engine.layout.LayoutAssembler
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.BeforeClass
import org.junit.Test
import org.junit.runner.RunWith
import org.opencv.android.OpenCVLoader

/**
 * On-device tests of the OpenCV detector (the same synthetic cases used by
 * tools/detector_prototype.py) plus the cache codecs. Run with: ./gradlew connectedAndroidTest
 */
@RunWith(AndroidJUnit4::class)
class DetectionInstrumentedTest {
    companion object {
        @BeforeClass @JvmStatic fun init() { assertTrue(OpenCVLoader.initLocal()) }
    }

    private val W = 1600
    private val H = 2400

    /** 2-3-1 grid page with right-to-left truth order and a bubble crossing a gutter. */
    private fun gridPage(blackGutters: Boolean = false): Pair<Bitmap, List<RectF>> {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawColor(if (blackGutters) Color.rgb(15, 15, 15) else Color.WHITE)
        val m = 90; val gut = 36
        val rows = listOf(m to 900, 900 + gut to 1500, 1500 + gut to H - m)
        val cols = listOf(2, 3, 1)
        val truth = ArrayList<RectF>()
        val fill = Paint().apply { color = Color.rgb(235, 235, 235) }
        val border = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.BLACK }
        val art = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 3f; color = Color.DKGRAY }
        val rnd = java.util.Random(1)
        rows.forEachIndexed { ri, (y0, y1) ->
            val n = cols[ri]
            val cw = (W - 2 * m - gut * (n - 1)) / n
            for (ci in 0 until n) {
                val x0 = W - m - (ci + 1) * cw - ci * gut
                val r = RectF(x0.toFloat(), y0.toFloat(), (x0 + cw).toFloat(), y1.toFloat())
                truth += r
                cv.drawRect(r.left, r.top, r.right, r.bottom, fill)
                cv.drawRect(r.left, r.top, r.right, r.bottom, border)
                repeat(25) {
                    cv.drawLine(
                        r.left + 20 + rnd.nextFloat() * (r.width - 40), r.top + 20 + rnd.nextFloat() * (r.height - 40),
                        r.left + 20 + rnd.nextFloat() * (r.width - 40), r.top + 20 + rnd.nextFloat() * (r.height - 40), art,
                    )
                }
            }
        }
        return bmp to truth
    }

    @Test fun detectsGridPanelsInJapaneseOrder() {
        val (bmp, truth) = gridPage()
        val det = ClassicalPanelDetector()
        val scaled = Bitmap.createScaledBitmap(bmp, 800, 1200, true)
        val img = det.preprocess(scaled, W.toFloat(), H.toFloat())
        val res = det.detect(img)
        img.release()
        assertEquals(6, res.panels.size)
        val layout = LayoutAssembler(3).assemble(SizeF(W.toFloat(), H.toFloat()), res.contentBounds, res.panels, emptyList(), res.bubbles, AssemblerConfig())
        // Truth list is already in right-to-left, top-to-bottom order.
        layout.panels.forEachIndexed { i, p -> assertTrue("panel $i iou=${p.bounds.iou(truth[i])}", p.bounds.iou(truth[i]) > 0.85f) }
        assertTrue(!layout.lowConfidenceFallback)
    }

    @Test fun blackGutterPagesAreHandled() {
        val (bmp, _) = gridPage(blackGutters = true)
        val det = ClassicalPanelDetector()
        val img = det.preprocess(Bitmap.createScaledBitmap(bmp, 800, 1200, true), W.toFloat(), H.toFloat())
        assertTrue(img.blackGutters)
        assertEquals(6, det.detect(img).panels.size)
        img.release()
    }

    @Test fun layoutCodecRoundTrip() {
        val (bmp, _) = gridPage()
        val det = ClassicalPanelDetector()
        val img = det.preprocess(Bitmap.createScaledBitmap(bmp, 800, 1200, true), W.toFloat(), H.toFloat())
        val res = det.detect(img)
        val layout = LayoutAssembler(3).assemble(SizeF(W.toFloat(), H.toFloat()), res.contentBounds, res.panels, emptyList(), res.bubbles, AssemblerConfig())
        val back = Codecs.decodeLayout(Codecs.encode(layout))
        assertEquals(layout.panels.map { it.bounds }, back.panels.map { it.bounds })
        assertEquals(layout.confidence, back.confidence)
    }
}
