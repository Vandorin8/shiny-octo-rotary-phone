package com.mangaflow.detection

import android.graphics.Bitmap
import com.mangaflow.engine.geometry.PointF
import com.mangaflow.engine.geometry.Polygon
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.model.Bubble
import com.mangaflow.engine.model.CandidateSource
import com.mangaflow.engine.model.PanelCandidate
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfInt
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.min

/**
 * Stage A preprocessing result for one page. Coordinates in the analysis image are mapped back
 * to source pixels with [toSource]; the original artwork is never modified.
 */
class AnalysisImage(
    val gray: Mat,          // CV_8UC1, gutters normalised to white
    val sourceWidth: Float,
    val sourceHeight: Float,
    val blackGutters: Boolean,
) {
    val width: Int get() = gray.cols()
    val height: Int get() = gray.rows()
    val sx: Float get() = sourceWidth / width
    val sy: Float get() = sourceHeight / height
    fun toSource(x0: Float, y0: Float, x1: Float, y1: Float) = RectF(x0 * sx, y0 * sy, x1 * sx, y1 * sy)
    fun release() = gray.release()
}

data class ClassicalResult(
    val panels: List<PanelCandidate>,
    val bubbles: List<Bubble>,
    val contentBounds: RectF,
)

/**
 * Stages A + B: deterministic OpenCV panel and speech-bubble detection.
 *
 * Kotlin port of tools/detector_prototype.py (validated there on a synthetic benchmark):
 *  1. grayscale + min/max contrast normalisation; gutter polarity from the page frame
 *     (black-gutter pages are inverted so the rest of the pipeline sees white gutters);
 *  2. gutter segmentation: paper-white connected components that touch the page edge,
 *     after an erosion that seals hairline breaks in panel borders;
 *  3. recursive projection cuts over the gutter mask (a row/column is a gutter if ≥ 80 % of it
 *     is gutter, so bubbles and art crossing a gutter don't merge panels);
 *  4. within each leaf, connected components of non-gutter content split diagonal /
 *     irregular arrangements; contours → convex polygon + box; gutter-ring evidence → score.
 */
class ClassicalPanelDetector {

    fun preprocess(bitmap: Bitmap, sourceWidth: Float, sourceHeight: Float): AnalysisImage {
        val rgba = Mat()
        Utils.bitmapToMat(bitmap, rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        rgba.release()
        Core.normalize(gray, gray, 0.0, 255.0, Core.NORM_MINMAX)

        val w = gray.cols()
        val h = gray.rows()
        val m = max(4, (0.02 * min(w, h)).toInt())
        val px = ByteArray(w * h).also { gray.get(0, 0, it) }
        val frame = ArrayList<Int>(2 * m * (w + h))
        for (y in 0 until h) for (x in 0 until w) {
            if (y < m || y >= h - m || x < m || x >= w - m) frame += px[y * w + x].toInt() and 0xFF
        }
        frame.sort()
        val black = frame[frame.size / 2] < 100
        if (black) Core.bitwise_not(gray, gray)
        return AnalysisImage(gray, sourceWidth, sourceHeight, black)
    }

    fun detect(img: AnalysisImage): ClassicalResult {
        val w = img.width
        val h = img.height
        val gutter = gutterMask(img.gray)            // ByteArray 0/1
        val minGap = max(2, (0.006 * min(w, h)).toInt())
        val leaves = ArrayList<IntArray>()
        xyCut(gutter, w, 0, 0, w, h, minGap, 0, leaves)

        val pageArea = w.toDouble() * h
        val minArea = 0.006 * pageArea
        val panels = ArrayList<PanelCandidate>()
        val gutterMat = Mat(h, w, CvType.CV_8UC1).also { it.put(0, 0, gutter) }
        val closeK = max(3, (0.004 * min(w, h)).toInt() or 1)
        val closeKernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(closeK.toDouble(), closeK.toDouble()))

        for ((x0, y0, x1, y1) in leaves.map { it.toList() }) {
            val roi = Rect(x0, y0, x1 - x0, y1 - y0)
            val content = Mat()
            Core.subtract(Mat.ones(roi.height, roi.width, CvType.CV_8UC1), gutterMat.submat(roi), content)
            if (Core.countNonZero(content) < minArea) { content.release(); continue }
            Imgproc.morphologyEx(content, content, Imgproc.MORPH_CLOSE, closeKernel)

            val labels = Mat()
            val stats = Mat()
            val centroids = Mat()
            val n = Imgproc.connectedComponentsWithStats(content, labels, stats, centroids, 8, CvType.CV_32S)
            for (i in 1 until n) {
                val area = stats.get(i, Imgproc.CC_STAT_AREA)[0]
                if (area < minArea) continue
                val comp = Mat()
                Core.compare(labels, Scalar(i.toDouble()), comp, Core.CMP_EQ)
                val contours = ArrayList<MatOfPoint>()
                Imgproc.findContours(comp, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
                val c = contours.maxByOrNull { Imgproc.contourArea(it) } ?: continue
                val hull = convexHull(c)
                val hull2f = MatOfPoint2f(*hull.toArray())
                val eps = 0.01 * Imgproc.arcLength(hull2f, true)
                val approx = MatOfPoint2f()
                Imgproc.approxPolyDP(hull2f, approx, eps, true)
                val br = Imgproc.boundingRect(c)
                val bx = br.x + x0
                val by = br.y + y0
                val solidity = Imgproc.contourArea(c) / max(Imgproc.contourArea(hull), 1.0)
                val fill = Core.countNonZero(comp).toDouble() / max(br.width * br.height, 1)

                // Gutter evidence: fraction of a thin ring just outside the box that is gutter.
                val r = max(2, minGap / 2)
                var ringTotal = 0
                var ringGutter = 0
                val ox0 = max(0, bx - r); val oy0 = max(0, by - r)
                val ox1 = min(w, bx + br.width + r); val oy1 = min(h, by + br.height + r)
                for (yy in oy0 until oy1) for (xx in ox0 until ox1) {
                    val inside = xx >= bx && xx < bx + br.width && yy >= by && yy < by + br.height
                    if (!inside) { ringTotal++; ringGutter += gutter[yy * w + xx] }
                }
                val gutterEv = ringGutter.toFloat() / max(ringTotal, 1)
                val edgeTouch = bx <= 2 || by <= 2 || bx + br.width >= w - 2 || by + br.height >= h - 2
                val score = (0.35 + 0.35 * min(1.0, gutterEv.toDouble()) + 0.2 * min(1.0, solidity) + 0.1 * min(1.0, fill)).toFloat()

                val poly = Polygon(approx.toArray().map { p ->
                    PointF(((p.x + x0) * img.sx).toFloat(), ((p.y + y0) * img.sy).toFloat())
                })
                panels += PanelCandidate(
                    bounds = img.toSource(bx.toFloat(), by.toFloat(), (bx + br.width).toFloat(), (by + br.height).toFloat()),
                    polygon = poly.takeIf { it.points.size >= 3 },
                    score = min(score, 0.95f),
                    source = CandidateSource.CLASSICAL,
                    gutterEvidence = gutterEv,
                    borderless = edgeTouch && gutterEv < 0.6f,
                )
                comp.release(); hull.release(); hull2f.release(); approx.release(); contours.forEach { it.release() }
            }
            labels.release(); stats.release(); centroids.release(); content.release()
        }

        val bubbles = detectBubbles(img, gutter)
        val content = contentBounds(gutter, w, h)?.let { img.toSource(it[0].toFloat(), it[1].toFloat(), it[2].toFloat(), it[3].toFloat()) }
            ?: RectF(0f, 0f, img.sourceWidth, img.sourceHeight)
        gutterMat.release()
        return ClassicalResult(panels, bubbles, content)
    }

    /** Paper-white region connected to the page edge, as a 0/1 byte mask. */
    private fun gutterMask(gray: Mat): ByteArray {
        val w = gray.cols()
        val h = gray.rows()
        val white = Mat()
        Imgproc.threshold(gray, white, 215.0, 255.0, Imgproc.THRESH_BINARY)
        val k = max(3, (0.004 * min(w, h)).toInt() or 1)
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(k.toDouble(), k.toDouble()))
        Imgproc.erode(white, white, kernel)

        val labels = Mat()
        val n = Imgproc.connectedComponents(white, labels, 4, CvType.CV_32S)
        val lab = IntArray(w * h).also { labels.get(0, 0, it) }
        val border = BooleanArray(n)
        for (x in 0 until w) { border[lab[x]] = true; border[lab[(h - 1) * w + x]] = true }
        for (y in 0 until h) { border[lab[y * w]] = true; border[lab[y * w + w - 1]] = true }
        border[0] = false // label 0 = non-white
        val g = ByteArray(w * h) { if (border[lab[it]]) 1 else 0 }

        // Undo the erosion so panel boxes are not inflated.
        val gm = Mat(h, w, CvType.CV_8UC1).also { it.put(0, 0, g) }
        Imgproc.dilate(gm, gm, kernel)
        gm.get(0, 0, g)
        white.release(); labels.release(); gm.release()
        return g
    }

    private fun xyCut(g: ByteArray, w: Int, x0: Int, y0: Int, x1: Int, y1: Int, minGap: Int, depth: Int, out: MutableList<IntArray>) {
        if (x1 <= x0 || y1 <= y0) return
        for (horizontal in listOf(true, false)) {
            val n = if (horizontal) y1 - y0 else x1 - x0
            val span = if (horizontal) x1 - x0 else y1 - y0
            val isGap = BooleanArray(n)
            for (i in 0 until n) {
                var s = 0
                if (horizontal) { val row = (y0 + i) * w; for (x in x0 until x1) s += g[row + x] }
                else { val x = x0 + i; for (y in y0 until y1) s += g[y * w + x] }
                isGap[i] = s >= 0.80 * span
            }
            val cuts = ArrayList<Pair<Int, Int>>()
            var i = 0
            while (i < n) {
                if (isGap[i]) {
                    var j = i
                    while (j < n && isGap[j]) j++
                    if (i > 0 && j < n && j - i >= minGap) cuts += i to j
                    i = j
                } else i++
            }
            if (cuts.isNotEmpty() && depth < 12) {
                val edges = ArrayList<Int>().apply { add(0); cuts.forEach { add(it.first); add(it.second) }; add(n) }
                var k = 0
                while (k < edges.size) {
                    val s = edges[k]; val e = edges[k + 1]
                    if (e - s >= minGap) {
                        if (horizontal) xyCut(g, w, x0, y0 + s, x1, y0 + e, minGap, depth + 1, out)
                        else xyCut(g, w, x0 + s, y0, x0 + e, y1, minGap, depth + 1, out)
                    }
                    k += 2
                }
                return
            }
        }
        out += intArrayOf(x0, y0, x1, y1)
    }

    /** White, convex, outlined blobs containing several small glyph-like marks. */
    private fun detectBubbles(img: AnalysisImage, gutter: ByteArray): List<Bubble> {
        val w = img.width
        val h = img.height
        val pageArea = w.toDouble() * h
        val whiteM = Mat()
        Imgproc.threshold(img.gray, whiteM, 200.0, 1.0, Imgproc.THRESH_BINARY)
        val white = ByteArray(w * h).also { whiteM.get(0, 0, it) }
        for (i in white.indices) if (gutter[i].toInt() == 1) white[i] = 0
        whiteM.put(0, 0, white)

        val labels = Mat()
        val stats = Mat()
        val cents = Mat()
        val n = Imgproc.connectedComponentsWithStats(whiteM, labels, stats, cents, 4, CvType.CV_32S)
        val st = IntArray(n * 5).also { stats.get(0, 0, it) }
        val out = ArrayList<Bubble>()
        for (i in 1 until n) {
            val x = st[i * 5]; val y = st[i * 5 + 1]; val bw = st[i * 5 + 2]; val bh = st[i * 5 + 3]; val area = st[i * 5 + 4]
            if (area < 0.0015 * pageArea || area > 0.08 * pageArea) continue
            val roi = Rect(x, y, bw, bh)
            val comp = Mat()
            Core.compare(labels.submat(roi), Scalar(i.toDouble()), comp, Core.CMP_EQ)
            val contours = ArrayList<MatOfPoint>()
            Imgproc.findContours(comp.clone(), contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
            val c = contours.maxByOrNull { Imgproc.contourArea(it) }
            if (c == null) { comp.release(); continue }
            val filled = Mat.zeros(bh, bw, CvType.CV_8UC1)
            Imgproc.drawContours(filled, listOf(c), -1, Scalar(255.0), -1)
            val filledArea = Core.countNonZero(filled).toDouble()
            val hull = convexHull(c)
            val solidity = filledArea / max(Imgproc.contourArea(hull), 1.0)
            val holes = Mat()
            Core.bitwise_not(comp, comp)
            Core.bitwise_and(filled, comp, holes)
            val ink = Core.countNonZero(holes) / max(filledArea, 1.0)
            var accepted = false
            var vertical = true
            var glyphCount = 0
            if (solidity >= 0.80 && ink in 0.01..0.40) {
                val hl = Mat(); val hs = Mat(); val hc = Mat()
                val hn = Imgproc.connectedComponentsWithStats(holes, hl, hs, hc, 8, CvType.CV_32S)
                val hst = IntArray(hn * 5).also { hs.get(0, 0, it) }
                var minX = Int.MAX_VALUE; var maxX = Int.MIN_VALUE; var minY = Int.MAX_VALUE; var maxY = Int.MIN_VALUE
                for (j in 1 until hn) {
                    if (hst[j * 5 + 4] < 0.02 * filledArea) {
                        glyphCount++
                        minX = min(minX, hst[j * 5]); maxX = max(maxX, hst[j * 5])
                        minY = min(minY, hst[j * 5 + 1]); maxY = max(maxY, hst[j * 5 + 1])
                    }
                }
                if (glyphCount >= 3) {
                    accepted = true
                    vertical = (maxY - minY + 1) >= (maxX - minX + 1) * 0.8
                }
                hl.release(); hs.release(); hc.release()
            }
            if (accepted) {
                val score = min(0.95, 0.4 + 0.3 * solidity + 0.05 * min(glyphCount, 5)).toFloat()
                out += Bubble(img.toSource(x.toFloat(), y.toFloat(), (x + bw).toFloat(), (y + bh).toFloat()), score, vertical)
            }
            comp.release(); filled.release(); hull.release(); holes.release(); contours.forEach { it.release() }
        }
        whiteM.release(); labels.release(); stats.release(); cents.release()
        return out
    }

    private fun contentBounds(g: ByteArray, w: Int, h: Int): IntArray? {
        var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) if (g[row + x].toInt() == 0) {
                if (x < x0) x0 = x; if (x > x1) x1 = x
                if (y < y0) y0 = y; if (y > y1) y1 = y
            }
        }
        return if (x1 < 0) null else intArrayOf(x0, y0, x1 + 1, y1 + 1)
    }

    private fun convexHull(c: MatOfPoint): MatOfPoint {
        val idx = MatOfInt()
        Imgproc.convexHull(c, idx)
        val pts = c.toArray()
        val hullPts = idx.toArray().map { pts[it] }
        idx.release()
        return MatOfPoint(*hullPts.toTypedArray<Point>())
    }
}
