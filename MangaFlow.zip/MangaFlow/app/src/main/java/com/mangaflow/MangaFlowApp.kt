package com.mangaflow

import android.app.Application
import android.util.Log
import com.mangaflow.data.BookRepository
import com.mangaflow.data.SettingsRepository
import com.mangaflow.data.db.AppDatabase
import com.mangaflow.detection.DetectionService
import com.mangaflow.detection.MlPanelDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.opencv.android.OpenCVLoader

class MangaFlowApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        val cvOk = OpenCVLoader.initLocal()
        if (!cvOk) Log.e("MangaFlow", "OpenCV failed to load — panel detection will fall back to full pages")
        container = AppContainer(this, cvOk)
    }
}

/** Manual dependency container (no DI framework needed for an app this size). */
class AppContainer(app: Application, val openCvReady: Boolean) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val db = AppDatabase.create(app)
    val books = BookRepository(app, db)
    val settings = SettingsRepository(app, scope)
    val ml = MlPanelDetector(app)
    val detection = DetectionService(db, ml)

    init {
        scope.launch {
            settings.init()
            ml.load()                 // off the main thread; absent model is a normal state
            detection.pruneStaleCache()
        }
    }
}
