package com.mangaflow.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import com.mangaflow.data.db.AppDatabase
import com.mangaflow.data.db.BookEntity
import com.mangaflow.data.source.BookFormat
import com.mangaflow.data.source.PageSource
import com.mangaflow.data.source.PageSourceFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

sealed class ImportResult {
    data class Imported(val book: BookEntity) : ImportResult()
    data class AlreadyInLibrary(val book: BookEntity) : ImportResult()
    data class Failed(val name: String, val reason: String) : ImportResult()
}

/**
 * Library management. Imported files are copied into app-private storage through the Storage
 * Access Framework so the reader has fast random access and works fully offline; the user's
 * original file is never modified.
 */
class BookRepository(private val context: Context, private val db: AppDatabase) {

    private val booksDir = File(context.filesDir, "books").apply { mkdirs() }
    private val coversDir = File(context.filesDir, "covers").apply { mkdirs() }

    val books = db.books().observeAll()

    suspend fun get(id: Long) = db.books().get(id)

    suspend fun import(uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        val name = displayName(uri) ?: "Untitled"
        val tmp = File(booksDir, "import-${System.nanoTime()}.tmp")
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { input.copyTo(it, 1 shl 16) }
            } ?: return@withContext ImportResult.Failed(name, "Could not open file")

            val header = ByteArray(8).also { b -> tmp.inputStream().use { it.read(b) } }
            val format = BookFormat.detect(name, header)
                ?: return@withContext ImportResult.Failed(name, "Unsupported format (CBZ, CBR, EPUB and PDF are supported)")

            val fp = fingerprint(tmp)
            db.books().byFingerprint(fp)?.let {
                tmp.delete()
                return@withContext ImportResult.AlreadyInLibrary(it)
            }

            val dest = File(booksDir, "$fp.${format.name.lowercase()}")
            if (!tmp.renameTo(dest)) { tmp.copyTo(dest, overwrite = true); tmp.delete() }

            val source = try {
                PageSourceFactory.open(dest, format)
            } catch (e: Throwable) {
                dest.delete()
                val reason = if (e.javaClass.simpleName.contains("RarV5", ignoreCase = true))
                    "RAR5 archives are not supported by the offline RAR decoder. Re-pack as CBZ."
                else "Could not read archive: ${e.message ?: e.javaClass.simpleName}"
                return@withContext ImportResult.Failed(name, reason)
            }
            source.use { src ->
                if (src.pageCount == 0) {
                    dest.delete()
                    return@withContext ImportResult.Failed(name, "No pages found")
                }
                val cover = runCatching { saveCover(src, fp) }.getOrNull()
                val entity = BookEntity(
                    title = name.substringBeforeLast('.'),
                    path = dest.absolutePath,
                    format = format.name,
                    fingerprint = fp,
                    pageCount = src.pageCount,
                    coverPath = cover,
                    addedAt = System.currentTimeMillis(),
                )
                val id = db.books().insert(entity)
                ImportResult.Imported(entity.copy(id = id))
            }
        } catch (e: Throwable) {
            tmp.delete()
            ImportResult.Failed(name, e.message ?: e.javaClass.simpleName)
        }
    }

    fun open(book: BookEntity): PageSource = PageSourceFactory.open(File(book.path), BookFormat.valueOf(book.format))

    suspend fun delete(book: BookEntity) = withContext(Dispatchers.IO) {
        db.books().delete(book.id)
        db.analysis().deleteBook(book.fingerprint)
        // Manual corrections are intentionally kept (keyed by file identity) so re-importing
        // the same volume restores them.
        File(book.path).delete()
        book.coverPath?.let { File(it).delete() }
    }

    suspend fun saveProgress(id: Long, page: Int, panel: Int, step: Int) =
        db.books().saveProgress(id, page, panel, step, System.currentTimeMillis())

    suspend fun saveOverrides(id: Long, json: String?) = db.books().saveOverrides(id, json)

    private fun saveCover(src: PageSource, fp: String): String? {
        val bmp = src.decodeScaled(0, 480) ?: return null
        val f = File(coversDir, "$fp.jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        bmp.recycle()
        return f.absolutePath
    }

    private fun displayName(uri: Uri): String? =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: uri.lastPathSegment

    /** Identity = SHA-256(size ‖ first MiB ‖ last MiB). Fast even for 500 MB volumes. */
    private fun fingerprint(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        val len = f.length()
        md.update(len.toString().toByteArray())
        RandomAccessFile(f, "r").use { raf ->
            val buf = ByteArray(1 shl 20)
            val n1 = raf.read(buf, 0, minOf(buf.size.toLong(), len).toInt())
            if (n1 > 0) md.update(buf, 0, n1)
            if (len > buf.size) {
                raf.seek(maxOf(0, len - buf.size))
                val n2 = raf.read(buf)
                if (n2 > 0) md.update(buf, 0, n2)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }.take(32)
    }
}
