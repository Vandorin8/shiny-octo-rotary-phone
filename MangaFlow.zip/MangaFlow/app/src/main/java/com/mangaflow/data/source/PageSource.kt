package com.mangaflow.data.source

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.os.Build
import android.util.LruCache
import com.mangaflow.engine.geometry.SizeF
import java.io.Closeable
import java.io.File

/**
 * Random-access page provider for one book. All sizes are in "source pixels": the native image
 * resolution for archive formats, and a fixed render resolution for PDF.
 *
 * Implementations must be thread-safe; the reader decodes tiles from several coroutines.
 */
interface PageSource : Closeable {
    val pageCount: Int
    fun pageSize(index: Int): SizeF

    /** Decodes [region] (source px) downsampled by [sampleSize] (power of two). */
    fun decodeRegion(index: Int, region: Rect, sampleSize: Int): Bitmap?

    /** Decodes the whole page so its long side is at most [maxLongSide] pixels. */
    fun decodeScaled(index: Int, maxLongSide: Int): Bitmap? {
        val s = pageSize(index)
        var sample = 1
        while (maxOf(s.width, s.height) / (sample * 2) >= maxLongSide) sample *= 2
        return decodeRegion(index, Rect(0, 0, s.width.toInt(), s.height.toInt()), sample)
    }
}

/**
 * Shared implementation for formats whose pages are encoded images (CBZ, CBR, EPUB).
 * Keeps a small LRU of [BitmapRegionDecoder]s so panning across a page never re-parses it.
 */
abstract class ImagePageSource : PageSource {
    protected abstract fun readBytes(index: Int): ByteArray

    private val sizes = HashMap<Int, SizeF>()
    private val decoders = object : LruCache<Int, Holder>(3) {
        override fun entryRemoved(evicted: Boolean, key: Int, old: Holder, new: Holder?) {
            if (evicted) synchronized(old) { old.region?.recycle() }
        }
    }

    private class Holder(val bytes: ByteArray, val region: BitmapRegionDecoder?)

    private fun holder(index: Int): Holder = synchronized(decoders) {
        decoders.get(index) ?: run {
            val bytes = readBytes(index)
            val dec = try {
                @Suppress("DEPRECATION")
                if (Build.VERSION.SDK_INT >= 31) BitmapRegionDecoder.newInstance(bytes, 0, bytes.size)
                else BitmapRegionDecoder.newInstance(bytes, 0, bytes.size, false)
            } catch (_: Exception) {
                null // e.g. GIF: falls back to full decode + crop
            }
            Holder(bytes, dec).also { decoders.put(index, it) }
        }
    }

    override fun pageSize(index: Int): SizeF {
        synchronized(sizes) { sizes[index]?.let { return it } }
        val h = holder(index)
        val size = h.region?.let { SizeF(it.width.toFloat(), it.height.toFloat()) } ?: run {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(h.bytes, 0, h.bytes.size, o)
            SizeF(o.outWidth.coerceAtLeast(1).toFloat(), o.outHeight.coerceAtLeast(1).toFloat())
        }
        synchronized(sizes) { sizes[index] = size }
        return size
    }

    override fun decodeRegion(index: Int, region: Rect, sampleSize: Int): Bitmap? {
        val h = holder(index)
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize.coerceAtLeast(1)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val dec = h.region
        if (dec != null) {
            synchronized(h) {
                if (dec.isRecycled) return decodeRegion(index, region, sampleSize)
                val r = Rect(region).apply { intersect(0, 0, dec.width, dec.height) }
                if (r.isEmpty) return null
                return dec.decodeRegion(r, opts)
            }
        }
        val full = BitmapFactory.decodeByteArray(h.bytes, 0, h.bytes.size, opts) ?: return null
        val s = opts.inSampleSize
        val r = Rect(region.left / s, region.top / s, region.right / s, region.bottom / s)
        r.intersect(0, 0, full.width, full.height)
        if (r.isEmpty) return null
        return Bitmap.createBitmap(full, r.left, r.top, r.width(), r.height())
    }

    override fun close() {
        synchronized(decoders) { decoders.evictAll() }
    }
}

enum class BookFormat { CBZ, CBR, EPUB, PDF;
    companion object {
        fun detect(name: String, header: ByteArray): BookFormat? {
            val lower = name.lowercase()
            // Magic numbers first: many files are mislabelled (.cbr that is really a zip, etc.).
            if (header.size >= 4 && header[0] == '%'.code.toByte() && header[1] == 'P'.code.toByte() && header[2] == 'D'.code.toByte() && header[3] == 'F'.code.toByte()) return PDF
            if (header.size >= 4 && header[0] == 'R'.code.toByte() && header[1] == 'a'.code.toByte() && header[2] == 'r'.code.toByte() && header[3] == '!'.code.toByte()) return CBR
            if (header.size >= 2 && header[0] == 'P'.code.toByte() && header[1] == 'K'.code.toByte()) {
                return if (lower.endsWith(".epub")) EPUB else CBZ
            }
            return when {
                lower.endsWith(".cbz") || lower.endsWith(".zip") -> CBZ
                lower.endsWith(".cbr") || lower.endsWith(".rar") -> CBR
                lower.endsWith(".epub") -> EPUB
                lower.endsWith(".pdf") -> PDF
                else -> null
            }
        }
    }
}

object PageSourceFactory {
    fun open(file: File, format: BookFormat): PageSource = when (format) {
        BookFormat.CBZ -> ZipPageSource(file)
        BookFormat.CBR -> RarPageSource(file)
        BookFormat.EPUB -> EpubPageSource(file)
        BookFormat.PDF -> PdfPageSource(file)
    }
}

internal val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif")

internal fun isImageName(name: String): Boolean {
    val n = name.substringAfterLast('/')
    if (n.startsWith(".") || name.contains("__MACOSX")) return false
    return n.substringAfterLast('.', "").lowercase() in IMAGE_EXTENSIONS
}

/** Natural ("human") ordering: page2 < page10. */
object NaturalOrder : Comparator<String> {
    private val chunk = Regex("(\\d+)|(\\D+)")
    override fun compare(a: String, b: String): Int {
        val ca = chunk.findAll(a.lowercase()).map { it.value }.toList()
        val cb = chunk.findAll(b.lowercase()).map { it.value }.toList()
        for (i in 0 until minOf(ca.size, cb.size)) {
            val x = ca[i]
            val y = cb[i]
            val c = if (x[0].isDigit() && y[0].isDigit()) {
                val nx = x.trimStart('0')
                val ny = y.trimStart('0')
                if (nx.length != ny.length) nx.length - ny.length else nx.compareTo(ny)
            } else x.compareTo(y)
            if (c != 0) return c
        }
        return ca.size - cb.size
    }
}
