package com.mangaflow.reader

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.mangaflow.engine.model.ReadingDirection
import com.mangaflow.engine.settings.BookOverrides
import com.mangaflow.engine.settings.ReaderSettings
import com.mangaflow.engine.settings.ReadingSizePreset
import com.mangaflow.engine.settings.RevealMode
import com.mangaflow.ui.ChoiceRow
import com.mangaflow.ui.label

/**
 * Per-book overrides. Each row offers "Global" plus explicit values; choosing a value only
 * affects this book and never changes global preferences.
 */
@Composable
fun BookSettingsDialog(o: BookOverrides, effective: ReaderSettings, onDismiss: () -> Unit, onChange: (BookOverrides) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
        dismissButton = { TextButton(onClick = { onChange(BookOverrides()) }) { Text("Reset to global") } },
        title = { Text("This book") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                ChoiceRow("Reading direction", listOf(null) + ReadingDirection.entries, o.direction, { it?.label() ?: "Global (${effective.direction.label()})" }) {
                    onChange(o.copy(direction = it))
                }
                ChoiceRow("Cinematic panel reveal", listOf(null) + RevealMode.entries, o.revealMode, { it?.label() ?: "Global" }) {
                    onChange(o.copy(revealMode = it))
                }
                ChoiceRow("Reading size", listOf(null) + ReadingSizePreset.entries.filter { it != ReadingSizePreset.CUSTOM }, o.sizePreset, { it?.label() ?: "Global" }) {
                    onChange(o.copy(sizePreset = it))
                }
                ChoiceRow("Panel detection", listOf(null, true, false), o.intelligentDetection, { when (it) { null -> "Global"; true -> "On"; false -> "Off (full pages)" } }) {
                    onChange(o.copy(intelligentDetection = it))
                }
                ChoiceRow("Automatic panel zoom", listOf(null, true, false), o.automaticPanelZoom, { when (it) { null -> "Global"; true -> "On"; false -> "Off" } }) {
                    onChange(o.copy(automaticPanelZoom = it))
                }
            }
        },
    )
}
