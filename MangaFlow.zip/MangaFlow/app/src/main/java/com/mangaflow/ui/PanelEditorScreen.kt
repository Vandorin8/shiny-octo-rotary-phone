package com.mangaflow.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AssistChip
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.mangaflow.AppContainer
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.layout.PageCorrection
import com.mangaflow.engine.layout.PanelEdits
import com.mangaflow.engine.model.RevealOverride
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.min

private enum class EditMode { SELECT, ADD, ORDER }

/**
 * Manual correction editor. Works on a normalized copy of the page layout; saving stores a
 * PageCorrection that overrides automatic detection for this page. The manga file is untouched.
 */
@Composable
fun PanelEditorScreen(c: AppContainer, bookId: Long, page: Int, onClose: (saved: Boolean) -> Unit) {
    val scope = rememberCoroutineScope()
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var correction by remember { mutableStateOf<PageCorrection?>(null) }
    var fingerprint by remember { mutableStateOf("") }
    var hadCorrection by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<Int>()) }
    var mode by remember { mutableStateOf(EditMode.SELECT) }
    var orderNext by remember { mutableStateOf(0) }
    var drawing by remember { mutableStateOf<RectF?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(bookId, page) {
        val book = c.books.get(bookId) ?: run { error = "Book not found"; return@LaunchedEffect }
        fingerprint = book.fingerprint
        val settings = c.settings.settings.first()
        withContext(Dispatchers.IO) {
            c.books.open(book).use { src ->
                bitmap = src.decodeScaled(page, 1600)
                val layout = c.detection.layoutFor(book.fingerprint, src, page, settings.copy(manualCorrections = true))
                correction = PageCorrection.fromLayout(layout)
                hadCorrection = c.detection.hasCorrection(book.fingerprint, page)
            }
        }
    }

    val dir = remember { mutableStateOf(com.mangaflow.engine.model.ReadingDirection.RIGHT_TO_LEFT) }
    LaunchedEffect(Unit) { dir.value = c.settings.settings.first().direction }

    Column(Modifier.fillMaxSize().background(Color(0xFF121214)).statusBarsPadding().navigationBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onClose(false) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Cancel", tint = Color.White) }
            Text("Edit panels · page ${page + 1}", color = Color.White, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            if (hadCorrection) TextButton(onClick = {
                scope.launch { c.detection.clearCorrection(fingerprint, page); onClose(true) }
            }) { Text("Use automatic") }
            TextButton(onClick = {
                val cur = correction ?: return@TextButton
                scope.launch { c.detection.saveCorrection(fingerprint, page, cur); onClose(true) }
            }) { Text("Save") }
        }
        error?.let { Text(it, color = Color.White, modifier = Modifier.padding(16.dp)) }

        val bmp = bitmap
        val corr = correction
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (bmp != null && corr != null) {
                // Page-fit transform (normalized page coords ↔ canvas px).
                var fit by remember { mutableStateOf(Triple(1f, 0f, 0f)) } // scale(px per normalized unit width), offX, offY
                val aspect = bmp.width.toFloat() / bmp.height
                fun toNorm(o: Offset): Offset {
                    val (s, ox, oy) = fit
                    return Offset(((o.x - ox) / s).coerceIn(0f, 1f), ((o.y - oy) / (s / aspect)).coerceIn(0f, 1f))
                }
                fun hit(n: Offset): Int? = corr.panels.indices.reversed().firstOrNull { corr.panels[it].bounds.contains(n.x, n.y) }

                Canvas(
                    Modifier.fillMaxSize()
                        .pointerInput(mode, corr) {
                            detectTapGestures(
                                onTap = { o ->
                                    val idx = hit(toNorm(o))
                                    when (mode) {
                                        EditMode.ORDER -> if (idx != null && idx >= orderNext) {
                                            correction = PanelEdits.move(corr, idx, orderNext)
                                            orderNext++
                                            if (orderNext >= corr.panels.size) { mode = EditMode.SELECT; orderNext = 0 }
                                        }
                                        else -> selected = if (idx == null) emptySet() else setOf(idx)
                                    }
                                },
                                onLongPress = { o -> hit(toNorm(o))?.let { idx -> selected = if (idx in selected) selected - idx else selected + idx } },
                            )
                        }
                        .pointerInput(mode, corr, selected) {
                            var dragKind = 0 // 1 move, 2 resize corner, 3 draw
                            var corner = 0
                            var start = Offset.Zero
                            var orig: RectF? = null
                            detectDragGestures(
                                onDragStart = { o ->
                                    val n = toNorm(o)
                                    start = n
                                    val sel = selected.singleOrNull()
                                    if (mode == EditMode.ADD) { dragKind = 3; drawing = RectF(n.x, n.y, n.x, n.y) }
                                    else if (sel != null) {
                                        val r = corr.panels[sel].bounds
                                        val tol = 0.04f
                                        val corners = listOf(Offset(r.left, r.top), Offset(r.right, r.top), Offset(r.left, r.bottom), Offset(r.right, r.bottom))
                                        val ci = corners.indexOfFirst { abs(it.x - n.x) < tol && abs(it.y - n.y) < tol * aspect }
                                        orig = r
                                        if (ci >= 0) { dragKind = 2; corner = ci } else if (r.contains(n.x, n.y)) dragKind = 1 else dragKind = 0
                                    } else dragKind = 0
                                },
                                onDrag = { change, _ ->
                                    val n = toNorm(change.position)
                                    val sel = selected.singleOrNull()
                                    val r = orig
                                    when (dragKind) {
                                        3 -> drawing = RectF(start.x, start.y, n.x, n.y)
                                        1 -> if (sel != null && r != null) {
                                            val moved = r.translate(n.x - start.x, n.y - start.y).shiftInto(RectF(0f, 0f, 1f, 1f))
                                            correction = PanelEdits.resize(correction!!, sel, moved)
                                        }
                                        2 -> if (sel != null && r != null) {
                                            val nr = when (corner) {
                                                0 -> RectF(n.x, n.y, r.right, r.bottom)
                                                1 -> RectF(r.left, n.y, n.x, r.bottom)
                                                2 -> RectF(n.x, r.top, r.right, n.y)
                                                else -> RectF(r.left, r.top, n.x, n.y)
                                            }
                                            correction = PanelEdits.resize(correction!!, sel, nr)
                                        }
                                    }
                                    change.consume()
                                },
                                onDragEnd = {
                                    if (dragKind == 3) {
                                        drawing?.let { d ->
                                            if (abs(d.width) > 0.03f && abs(d.height) > 0.03f) {
                                                correction = PanelEdits.add(correction!!, d)
                                                selected = setOf(correction!!.panels.lastIndex)
                                            }
                                        }
                                        drawing = null
                                        mode = EditMode.SELECT
                                    }
                                    dragKind = 0
                                },
                            )
                        },
                ) {
                    val s = min(size.width, size.height * aspect)
                    val ox = (size.width - s) / 2f
                    val oy = (size.height - s / aspect) / 2f
                    fit = Triple(s, ox, oy)
                    drawImage(bmp.asImageBitmap(), IntOffset.Zero, IntSize(bmp.width, bmp.height), IntOffset(ox.toInt(), oy.toInt()), IntSize(s.toInt(), (s / aspect).toInt()), filterQuality = FilterQuality.Medium)
                    fun px(r: RectF) = Pair(Offset(ox + r.left * s, oy + r.top * s / aspect), Size(r.width * s, r.height * s / aspect))
                    val label = android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 40f; isFakeBoldText = true }
                    val labelBg = android.graphics.Paint().apply { color = android.graphics.Color.argb(200, 230, 70, 60) }
                    if (corr.fullPage) {
                        drawRect(Color(0x33FF7A6E), Offset(ox, oy), Size(s, s / aspect))
                    }
                    corr.panels.forEachIndexed { i, p ->
                        if (p.safeBounds != p.bounds) {
                            val (so, ss) = px(p.safeBounds)
                            drawRect(Color(0xFF64B5F6), so, ss, style = Stroke(2f))
                        }
                        val (o, sz) = px(p.bounds)
                        val sel = i in selected
                        drawRect(if (sel) Color(0x40FF7A6E) else Color(0x1AFF7A6E), o, sz)
                        drawRect(if (sel) Color(0xFFFF7A6E) else Color(0xCCFF5A4E), o, sz, style = Stroke(if (sel) 6f else 3f))
                        drawContext.canvas.nativeCanvas.apply {
                            drawRect(o.x, o.y, o.x + 64f, o.y + 52f, labelBg)
                            drawText("${i + 1}", o.x + 12f, o.y + 40f, label)
                        }
                        if (sel && selected.size == 1) {
                            listOf(o, Offset(o.x + sz.width, o.y), Offset(o.x, o.y + sz.height), Offset(o.x + sz.width, o.y + sz.height)).forEach {
                                drawCircle(Color.White, 14f, it); drawCircle(Color(0xFFFF7A6E), 10f, it)
                            }
                        }
                    }
                    drawing?.let { d ->
                        val n = RectF(min(d.left, d.right), min(d.top, d.bottom), maxOf(d.left, d.right), maxOf(d.top, d.bottom))
                        val (o, sz) = px(n)
                        drawRect(Color.White, o, sz, style = Stroke(3f))
                    }
                }
            } else if (error == null) {
                Text("Loading page…", color = Color.White, modifier = Modifier.align(Alignment.Center))
            }
        }

        // ---- Tools ----
        val corr2 = correction
        if (corr2 != null) {
            val single = selected.singleOrNull()
            Text(
                when (mode) {
                    EditMode.ADD -> "Drag on the page to draw a new panel"
                    EditMode.ORDER -> "Tap panels in reading order (${orderNext + 1} of ${corr2.panels.size})"
                    EditMode.SELECT -> "Tap to select · long-press to multi-select · drag corners to resize"
                },
                color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 12.dp),
            )
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(8.dp)) {
                FilterChip(selected = mode == EditMode.ADD, onClick = { mode = if (mode == EditMode.ADD) EditMode.SELECT else EditMode.ADD }, label = { Text("Add") })
                AssistChip(onClick = { single?.let { correction = PanelEdits.remove(corr2, it); selected = emptySet() } }, label = { Text("Delete") }, enabled = single != null, modifier = Modifier.padding(start = 6.dp))
                FilterChip(selected = mode == EditMode.ORDER, onClick = { mode = if (mode == EditMode.ORDER) EditMode.SELECT else EditMode.ORDER; orderNext = 0; selected = emptySet() }, label = { Text("Reorder") }, modifier = Modifier.padding(start = 6.dp))
                AssistChip(onClick = { correction = PanelEdits.merge(corr2, selected); selected = emptySet() }, label = { Text("Combine") }, enabled = selected.size >= 2, modifier = Modifier.padding(start = 6.dp))
                AssistChip(onClick = { single?.let { correction = PanelEdits.split(corr2, it, vertical = true, fraction = 0.5f, direction = dir.value) } }, label = { Text("Split ⇆") }, enabled = single != null, modifier = Modifier.padding(start = 6.dp))
                AssistChip(onClick = { single?.let { correction = PanelEdits.split(corr2, it, vertical = false, fraction = 0.5f, direction = dir.value) } }, label = { Text("Split ⇅") }, enabled = single != null, modifier = Modifier.padding(start = 6.dp))
                FilterChip(selected = corr2.fullPage, onClick = { correction = PanelEdits.markFullPage(corr2, !corr2.fullPage) }, label = { Text("Full-page illustration") }, modifier = Modifier.padding(start = 6.dp))
            }
            if (single != null && single < corr2.panels.size) {
                val p = corr2.panels[single]
                Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Cinematic reveal:", color = Color.White, style = MaterialTheme.typography.labelMedium)
                    RevealOverride.entries.forEach { r ->
                        FilterChip(selected = p.reveal == r, onClick = { correction = PanelEdits.setReveal(corr2, single, r) }, label = { Text(r.label()) }, modifier = Modifier.padding(start = 6.dp))
                    }
                }
                Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Dialogue-safe margin", color = Color.White, style = MaterialTheme.typography.labelMedium)
                    Slider(value = p.margin, onValueChange = { correction = PanelEdits.setMargin(corr2, single, it) }, valueRange = 0f..0.15f, modifier = Modifier.weight(1f).padding(start = 8.dp))
                }
            }
        }
    }
}
