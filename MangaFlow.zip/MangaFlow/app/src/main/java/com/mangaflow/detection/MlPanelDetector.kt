package com.mangaflow.detection

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.mangaflow.engine.geometry.PointF
import com.mangaflow.engine.geometry.Polygon
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.model.CandidateSource
import com.mangaflow.engine.model.PanelCandidate
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.io.File
import java.nio.FloatBuffer
import java.security.MessageDigest
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/**
 * Stage C: optional on-device ML panel detector (ONNX Runtime).
 *
 * Manga Flow does not ship pretrained weights (see README → "Machine-learning model"). The
 * runtime, preprocessing and postprocessing below are complete; a model is loaded from
 *   1. files/models/panel.onnx   (imported by the user in Settings), or
 *   2. assets/models/panel.onnx  (bundled at build time).
 *
 * Supported model contracts (detected automatically from the output shape):
 *   • Segmentation: input [1,3,S,S] RGB 0..1, output [1,1,S,S] or [1,S,S] panel probability
 *     (logits are passed through a sigmoid). Instances = connected components of the mask.
 *   • YOLOv8-style detection: input [1,3,S,S], output [1, 4+C, N] (cx,cy,w,h,class scores…)
 *     — the format produced by `yolo export format=onnx` for a panel detector.
 * Input is letterboxed to S×S with white padding (manga paper colour).
 */
class MlPanelDetector(private val context: Context) {

    @Volatile private var session: OrtSession? = null
    @Volatile var status: String = "not loaded"; private set
    @Volatile var modelId: String = "none"; private set
    private val env: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }

    val userModelFile: File get() = File(context.filesDir, "models/panel.onnx")

    val isAvailable: Boolean get() = session != null

    /** Loads the model if present. Never throws: failure leaves the classical detector in charge. */
    @Synchronized
    fun load() {
        session?.close()
        session = null
        val bytes = try {
            when {
                userModelFile.exists() -> userModelFile.readBytes()
                context.assets.list("models")?.contains("panel.onnx") == true -> context.assets.open("models/panel.onnx").use { it.readBytes() }
                else -> null
            }
        } catch (e: Exception) { null }
        if (bytes == null) {
            status = "No model installed — using the OpenCV detector only"
            modelId = "none"
            return
        }
        try {
            val opts = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(2)
                runCatching { addNnapi() } // hardware acceleration when the device supports it
            }
            val s = env.createSession(bytes, opts)
            val shape = (s.inputInfo.values.first().info as ai.onnxruntime.TensorInfo).shape
            require(shape.size == 4 && shape[1] == 3L) { "expected input [1,3,S,S], got ${shape.toList()}" }
            session = s
            modelId = MessageDigest.getInstance("SHA-1").digest(bytes).take(6).joinToString("") { "%02x".format(it) }
            status = "Model loaded (${bytes.size / 1024} KB, input ${shape.toList()})"
        } catch (e: Throwable) {
            status = "Model failed to load: ${e.message}"
            modelId = "none"
        }
    }

    @Synchronized
    fun installUserModel(bytes: ByteArray) {
        userModelFile.parentFile?.mkdirs()
        userModelFile.writeBytes(bytes)
        load()
    }

    @Synchronized
    fun removeUserModel() {
        userModelFile.delete()
        load()
    }

    fun detect(page: Bitmap, sourceWidth: Float, sourceHeight: Float): List<PanelCandidate> {
        val s = session ?: return emptyList()
        val inputName = s.inputNames.first()
        val shape = (s.inputInfo.values.first().info as ai.onnxruntime.TensorInfo).shape
        val size = (if (shape[2] > 0) shape[2] else 640L).toInt()

        // Letterbox to size×size.
        val scale = min(size.toFloat() / page.width, size.toFloat() / page.height)
        val nw = (page.width * scale).toInt().coerceAtLeast(1)
        val nh = (page.height * scale).toInt().coerceAtLeast(1)
        val padX = (size - nw) / 2
        val padY = (size - nh) / 2
        val boxed = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(boxed).apply {
            drawColor(Color.WHITE)
            drawBitmap(Bitmap.createScaledBitmap(page, nw, nh, true), padX.toFloat(), padY.toFloat(), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        val pixels = IntArray(size * size).also { boxed.getPixels(it, 0, size, 0, 0, size, size) }
        boxed.recycle()
        val chw = FloatBuffer.allocate(3 * size * size)
        for (c in 0 until 3) for (i in pixels.indices) {
            val p = pixels[i]
            val v = when (c) { 0 -> (p shr 16) and 0xFF; 1 -> (p shr 8) and 0xFF; else -> p and 0xFF }
            chw.put(v / 255f)
        }
        chw.rewind()

        OnnxTensor.createTensor(env, chw, longArrayOf(1, 3, size.toLong(), size.toLong())).use { input ->
            s.run(mapOf(inputName to input)).use { result ->
                val out = result[0] as OnnxTensor
                val oShape = out.info.shape
                val data = out.floatBuffer.let { b -> FloatArray(b.remaining()).also { b.get(it) } }
                // Map letterboxed model coordinates back to source pixels.
                val toSrcX = { x: Float -> ((x - padX) / scale) * (sourceWidth / page.width) }
                val toSrcY = { y: Float -> ((y - padY) / scale) * (sourceHeight / page.height) }
                return when {
                    oShape.size == 3 && oShape[1] in 5..64 && oShape[2] > oShape[1] ->
                        decodeYolo(data, oShape[1].toInt(), oShape[2].toInt(), toSrcX, toSrcY, sourceWidth, sourceHeight)
                    (oShape.size == 4 && oShape[1] == 1L) || oShape.size == 3 ->
                        decodeMask(data, size, padX, padY, nw, nh, toSrcX, toSrcY)
                    else -> {
                        status = "Unsupported model output ${oShape.toList()}"
                        emptyList()
                    }
                }
            }
        }
    }

    private fun decodeMask(
        data: FloatArray, size: Int, padX: Int, padY: Int, nw: Int, nh: Int,
        toSrcX: (Float) -> Float, toSrcY: (Float) -> Float,
    ): List<PanelCandidate> {
        val needsSigmoid = data.any { it < 0f || it > 1f }
        val prob = if (needsSigmoid) FloatArray(data.size) { 1f / (1f + exp(-data[it])) } else data
        val mask = Mat(size, size, CvType.CV_8UC1)
        val bytes = ByteArray(size * size)
        for (y in 0 until size) for (x in 0 until size) {
            val inside = x >= padX && x < padX + nw && y >= padY && y < padY + nh
            bytes[y * size + x] = if (inside && prob[y * size + x] >= 0.5f) 1 else 0
        }
        mask.put(0, 0, bytes)
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_OPEN, Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0)))
        val labels = Mat(); val stats = Mat(); val cents = Mat()
        val n = Imgproc.connectedComponentsWithStats(mask, labels, stats, cents, 4, CvType.CV_32S)
        val out = ArrayList<PanelCandidate>()
        val minArea = 0.006 * nw * nh
        val lab = IntArray(size * size).also { labels.get(0, 0, it) }
        for (i in 1 until n) {
            if (stats.get(i, Imgproc.CC_STAT_AREA)[0] < minArea) continue
            val comp = Mat()
            Core.compare(labels, Scalar(i.toDouble()), comp, Core.CMP_EQ)
            val contours = ArrayList<MatOfPoint>()
            Imgproc.findContours(comp, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
            val c = contours.maxByOrNull { Imgproc.contourArea(it) } ?: continue
            val c2f = MatOfPoint2f(*c.toArray())
            val approx = MatOfPoint2f()
            Imgproc.approxPolyDP(c2f, approx, 0.01 * Imgproc.arcLength(c2f, true), true)
            // Mean probability inside the instance is its confidence.
            var sum = 0.0; var cnt = 0
            for (k in lab.indices) if (lab[k] == i) { sum += prob[k]; cnt++ }
            val poly = Polygon(approx.toArray().map { PointF(toSrcX(it.x.toFloat()), toSrcY(it.y.toFloat())) })
            if (poly.points.size >= 3) {
                out += PanelCandidate(poly.bounds, poly, (sum / max(cnt, 1)).toFloat().coerceIn(0f, 0.99f), CandidateSource.ML)
            }
            comp.release(); c2f.release(); approx.release(); contours.forEach { it.release() }
        }
        mask.release(); labels.release(); stats.release(); cents.release()
        return out
    }

    private fun decodeYolo(
        data: FloatArray, rows: Int, n: Int,
        toSrcX: (Float) -> Float, toSrcY: (Float) -> Float, sw: Float, sh: Float,
    ): List<PanelCandidate> {
        val boxes = ArrayList<PanelCandidate>()
        for (j in 0 until n) {
            var best = 0f
            for (c in 4 until rows) best = max(best, data[c * n + j])
            if (best < 0.3f) continue
            val cx = data[j]; val cy = data[n + j]; val w = data[2 * n + j]; val h = data[3 * n + j]
            val r = RectF(toSrcX(cx - w / 2), toSrcY(cy - h / 2), toSrcX(cx + w / 2), toSrcY(cy + h / 2))
                .clampTo(RectF(0f, 0f, sw, sh))
            if (!r.isEmpty) boxes += PanelCandidate(r, null, best, CandidateSource.ML)
        }
        // Class-agnostic NMS at IoU 0.6 (overlapping manga panels below that are kept).
        val keep = ArrayList<PanelCandidate>()
        for (b in boxes.sortedByDescending { it.score }) if (keep.none { it.bounds.iou(b.bounds) > 0.6f }) keep += b
        return keep
    }
}
