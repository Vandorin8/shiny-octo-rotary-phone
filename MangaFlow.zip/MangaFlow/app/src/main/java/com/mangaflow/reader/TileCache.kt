package com.mangaflow.reader

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import android.util.LruCache
import com.mangaflow.data.source.PageSource
import com.mangaflow.engine.geometry.RectF
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Tiled high-resolution renderer backing store.
 *
 * Every page has a "base" bitmap sized for the screen. When the camera magnifies beyond the base
 * resolution, the visible area is covered by tiles decoded straight from the original image with
 * BitmapRegionDecoder at the smallest power-of-two subsample that still gives ≥ 1 source pixel
 * per screen pixel. Nothing is ever cropped or rewritten on disk.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class TileCache(
    private val source: PageSource,
    private val scope: CoroutineScope,
    private val baseLongSide: Int,
) {
    data class TileKey(val page: Int, val sample: Int, val col: Int, val row: Int)
    class Tile(val key: TileKey, val src: Rect, val bitmap: Bitmap)

    /** Bumped whenever a new bitmap becomes available so the canvas redraws. */
    val version = MutableStateFlow(0)

    private val decodeLane = Dispatchers.IO.limitedParallelism(2)
    private val baseLane = Dispatchers.IO.limitedParallelism(1)

    private val bases = object : LruCache<Int, Bitmap>(4) {}
    private val pendingBases = HashSet<Int>()

    private val maxTileBytes = (Runtime.getRuntime().maxMemory() / 6).toInt().coerceIn(24 shl 20, 160 shl 20)
    private val tiles = object : LruCache<TileKey, Tile>(maxTileBytes) {
        override fun sizeOf(key: TileKey, value: Tile) = value.bitmap.byteCount
    }
    private val pendingTiles = HashSet<TileKey>()

    fun base(page: Int): Bitmap? {
        bases.get(page)?.let { return it }
        requestBase(page)
        return null
    }

    fun requestBase(page: Int) {
        if (page < 0 || page >= source.pageCount) return
        synchronized(pendingBases) { if (bases.get(page) != null || !pendingBases.add(page)) return }
        scope.launch(baseLane) {
            try {
                source.decodeScaled(page, baseLongSide)?.let { bases.put(page, it); version.value++ }
            } catch (t: Throwable) {
                Log.e("TileCache", "base decode failed for page $page", t)
            } finally {
                synchronized(pendingBases) { pendingBases.remove(page) }
            }
        }
    }

    /**
     * Tiles covering [visible] (source px) for a camera [scale] (screen px per source px), or an
     * empty list when the base bitmap is already sharp enough.
     */
    fun tilesFor(page: Int, pageW: Float, visible: RectF, scale: Float, baseWidth: Int): List<Tile> {
        val baseSourcePerPx = pageW / baseWidth            // source px per base px
        val needSourcePerScreenPx = 1f / scale
        if (needSourcePerScreenPx >= baseSourcePerPx * 0.8f) return emptyList()

        var sample = 1
        while (sample * 2 <= needSourcePerScreenPx) sample *= 2
        val tileSrc = TILE_PX * sample
        val c0 = max(0, floor(visible.left / tileSrc).toInt())
        val r0 = max(0, floor(visible.top / tileSrc).toInt())
        val c1 = floor(min(visible.right, pageW) / tileSrc).toInt()
        val pageH = source.pageSize(page).height
        val r1 = floor(min(visible.bottom, pageH) / tileSrc).toInt()
        val out = ArrayList<Tile>()
        for (r in r0..r1) for (c in c0..c1) {
            val key = TileKey(page, sample, c, r)
            val t = tiles.get(key)
            if (t != null) out += t else request(key, tileSrc, pageW, pageH)
        }
        return out
    }

    private fun request(key: TileKey, tileSrc: Int, pageW: Float, pageH: Float) {
        synchronized(pendingTiles) { if (!pendingTiles.add(key)) return }
        scope.launch(decodeLane) {
            try {
                val src = Rect(
                    key.col * tileSrc, key.row * tileSrc,
                    min(((key.col + 1) * tileSrc).toFloat(), pageW).toInt(),
                    min(((key.row + 1) * tileSrc).toFloat(), ceil(pageH)).toInt(),
                )
                if (!src.isEmpty) {
                    source.decodeRegion(key.page, src, key.sample)?.let {
                        tiles.put(key, Tile(key, src, it))
                        version.value++
                    }
                }
            } catch (t: Throwable) {
                Log.w("TileCache", "tile decode failed $key", t)
            } finally {
                synchronized(pendingTiles) { pendingTiles.remove(key) }
            }
        }
    }

    fun trimTo(pages: Set<Int>) {
        tiles.snapshot().keys.filter { it.page !in pages }.forEach { tiles.remove(it) }
    }

    companion object { const val TILE_PX = 512 }
}
