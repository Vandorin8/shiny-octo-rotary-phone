package com.mangaflow.data.source

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.github.junrar.Archive
import com.github.junrar.rarfile.FileHeader
import com.mangaflow.engine.geometry.SizeF
import org.w3c.dom.Element
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory

/** CBZ: a zip of images, ordered naturally by path. */
open class ZipPageSource(file: File) : ImagePageSource() {
    protected val zip = ZipFile(file)
    protected open val entries: List<String> by lazy {
        zip.entries().asSequence().filter { !it.isDirectory && isImageName(it.name) }.map { it.name }
            .sortedWith(NaturalOrder).toList()
    }
    override val pageCount: Int get() = entries.size
    override fun readBytes(index: Int): ByteArray = synchronized(zip) {
        zip.getInputStream(zip.getEntry(entries[index])).use { it.readBytes() }
    }
    override fun close() {
        super.close()
        zip.close()
    }
}

/**
 * EPUB: follows the OPF spine and extracts the image referenced by each XHTML page
 * (fixed-layout manga EPUBs are one image per page). Falls back to all images in manifest order.
 */
class EpubPageSource(file: File) : ZipPageSource(file) {
    override val entries: List<String> by lazy { resolveSpineImages().ifEmpty { super.entries } }

    private fun read(name: String): ByteArray? = synchronized(zip) {
        zip.getEntry(name)?.let { e -> zip.getInputStream(e).use { it.readBytes() } }
    }

    private fun resolveSpineImages(): List<String> = runCatching {
        val factory = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }
        fun parse(bytes: ByteArray) = factory.newDocumentBuilder().parse(bytes.inputStream())

        val container = parse(read("META-INF/container.xml") ?: return emptyList())
        val opfPath = (container.getElementsByTagNameNS("*", "rootfile").item(0) as Element).getAttribute("full-path")
        val base = opfPath.substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" }
        val opf = parse(read(opfPath) ?: return emptyList())

        val manifest = HashMap<String, Pair<String, String>>() // id -> (href, media-type)
        val items = opf.getElementsByTagNameNS("*", "item")
        for (i in 0 until items.length) {
            val e = items.item(i) as Element
            manifest[e.getAttribute("id")] = resolve(base, e.getAttribute("href")) to e.getAttribute("media-type")
        }
        val result = mutableListOf<String>()
        val refs = opf.getElementsByTagNameNS("*", "itemref")
        val imgSrc = Regex("""(?:src|xlink:href|href)\s*=\s*["']([^"']+\.(?:jpe?g|png|webp|gif))["']""", RegexOption.IGNORE_CASE)
        for (i in 0 until refs.length) {
            val (href, type) = manifest[(refs.item(i) as Element).getAttribute("idref")] ?: continue
            if (type.startsWith("image/")) { result += href; continue }
            val html = read(href)?.toString(Charsets.UTF_8) ?: continue
            val dir = href.substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" }
            imgSrc.findAll(html).map { resolve(dir, it.groupValues[1]) }.filter { zip.getEntry(it) != null }.forEach { result += it }
        }
        result.distinct()
    }.getOrDefault(emptyList())

    private fun resolve(base: String, href: String): String {
        val parts = ArrayDeque<String>()
        for (p in (base + java.net.URLDecoder.decode(href, "UTF-8")).split('/')) {
            when (p) { "", "." -> {}; ".." -> parts.removeLastOrNull(); else -> parts.addLast(p) }
        }
        return parts.joinToString("/")
    }
}

/** CBR via junrar. Supports RAR4 archives; RAR5 is rejected with a clear error at import. */
class RarPageSource(file: File) : ImagePageSource() {
    private val archive = Archive(file)
    private val headers: List<FileHeader> = archive.fileHeaders
        .filter { !it.isDirectory && isImageName(it.fileName.replace('\\', '/')) }
        .sortedWith(compareBy(NaturalOrder) { it.fileName.replace('\\', '/') })

    override val pageCount: Int get() = headers.size
    override fun readBytes(index: Int): ByteArray = synchronized(archive) {
        val out = ByteArrayOutputStream(headers[index].fullUnpackSize.toInt().coerceAtLeast(1024))
        archive.extractFile(headers[index], out)
        out.toByteArray()
    }
    override fun close() {
        super.close()
        archive.close()
    }
}

/** PDF via the platform renderer. Pages are rendered at [RENDER_SCALE] × their point size. */
class PdfPageSource(file: File) : PageSource {
    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val sizes = HashMap<Int, SizeF>()

    override val pageCount: Int get() = renderer.pageCount

    override fun pageSize(index: Int): SizeF = synchronized(renderer) {
        sizes.getOrPut(index) {
            renderer.openPage(index).use { SizeF(it.width * RENDER_SCALE, it.height * RENDER_SCALE) }
        }
    }

    override fun decodeRegion(index: Int, region: Rect, sampleSize: Int): Bitmap? = synchronized(renderer) {
        val size = pageSize(index)
        val r = Rect(region).apply { intersect(0, 0, size.width.toInt(), size.height.toInt()) }
        if (r.isEmpty) return null
        val s = sampleSize.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap((r.width() / s).coerceAtLeast(1), (r.height() / s).coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        renderer.openPage(index).use { page ->
            val k = RENDER_SCALE / s
            val m = Matrix().apply {
                setScale(k, k)
                postTranslate(-r.left.toFloat() / s, -r.top.toFloat() / s)
            }
            page.render(bmp, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        }
        bmp
    }

    override fun close() {
        synchronized(renderer) { renderer.close() }
        pfd.close()
    }

    companion object { const val RENDER_SCALE = 3f }
}
