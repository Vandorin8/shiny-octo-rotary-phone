package com.mangaflow.reader

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangaflow.MangaFlowApp
import com.mangaflow.data.Codecs
import com.mangaflow.data.db.BookEntity
import com.mangaflow.data.source.PageSource
import com.mangaflow.engine.camera.CameraState
import com.mangaflow.engine.camera.FramingStrategy
import com.mangaflow.engine.camera.LearnedBias
import com.mangaflow.engine.camera.NavResult
import com.mangaflow.engine.camera.PagePlan
import com.mangaflow.engine.camera.PanelClass
import com.mangaflow.engine.camera.PlanBuilder
import com.mangaflow.engine.camera.ReadingNavigator
import com.mangaflow.engine.camera.ReadingPosition
import com.mangaflow.engine.camera.Viewport
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.learning.Adjustment
import com.mangaflow.engine.model.PageLayout
import com.mangaflow.engine.settings.BookOverrides
import com.mangaflow.engine.settings.ReaderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ReaderUi(
    val loading: Boolean = true,
    val error: String? = null,
    val title: String = "",
    val pageCount: Int = 0,
    val position: ReadingPosition = ReadingPosition(0, 0, 0),
    val pageSize: SizeF? = null,
    /** Where the camera should be; the screen animates toward it. */
    val target: CameraState? = null,
    /** Increments on every navigation so identical targets still restart animation. */
    val targetVersion: Int = 0,
    /** True when the page changed, so the camera should jump rather than glide. */
    val pageJump: Boolean = true,
    val settings: ReaderSettings = ReaderSettings(),
    val overrides: BookOverrides = BookOverrides(),
    val layout: PageLayout? = null,
    val panelCount: Int = 1,
    val stepCount: Int = 1,
    val revealing: Boolean = false,
    val detectionPending: Boolean = true,
    val controlsVisible: Boolean = false,
    val message: String? = null,
    val endOfBook: Boolean = false,
)

class ReaderViewModel(app: Application, private val bookId: Long, private val startPage: Int?) : AndroidViewModel(app) {
    private val c = (app as MangaFlowApp).container
    private val _ui = MutableStateFlow(ReaderUi())
    val ui: StateFlow<ReaderUi> = _ui.asStateFlow()

    private lateinit var book: BookEntity
    lateinit var source: PageSource
        private set
    var tiles: TileCache? = null
        private set

    private val builder = PlanBuilder()
    private val layouts = HashMap<Int, PageLayout>()
    private val plans = HashMap<Int, PagePlan>()
    private val sizes = HashMap<Int, SizeF>()
    private val loadJobs = HashMap<Int, Job>()
    private var viewport: Viewport? = null
    private var global = ReaderSettings()
    private var overrides = BookOverrides()
    private val settings: ReaderSettings get() = overrides.applyTo(global)
    private lateinit var navigator: ReadingNavigator

    /** Saved panel/step to restore once the starting page's real plan exists. */
    private var pendingRestore: ReadingPosition? = null

    // Learning bookkeeping
    private var manualScale: Float? = null
    private var manualAt = 0L

    init {
        viewModelScope.launch {
            val b = c.books.get(bookId) ?: run { _ui.update { it.copy(loading = false, error = "Book not found") }; return@launch }
            book = b
            source = try {
                withContext(Dispatchers.IO) { c.books.open(b) }
            } catch (e: Throwable) {
                _ui.update { it.copy(loading = false, error = "Cannot open book: ${e.message}") }
                return@launch
            }
            overrides = Codecs.decodeOverrides(b.overridesJson)
            global = c.settings.settings.first()
            navigator = ReadingNavigator(source.pageCount) { planFor(it) }
            val startPos = if (startPage != null) ReadingPosition(startPage.coerceIn(0, source.pageCount - 1), 0, 0)
            else ReadingPosition(b.lastPage.coerceIn(0, source.pageCount - 1), b.lastPanel, b.lastStep)
            pendingRestore = startPos.takeIf { it.panel > 0 || it.step > 0 }
            _ui.update { it.copy(title = b.title, pageCount = source.pageCount, position = startPos, overrides = overrides) }
            // Settings stream: re-plan whenever global settings change.
            launch {
                c.settings.settings.collect { s ->
                    val detectionChanged = s.direction != global.direction || s.intelligentDetection != global.intelligentDetection ||
                        s.speechBubbleProtection != global.speechBubbleProtection || s.lowConfidenceFallback != global.lowConfidenceFallback ||
                        s.manualCorrections != global.manualCorrections
                    global = s
                    onSettingsChanged(relayout = detectionChanged)
                }
            }
            maybeInitTiles()
            loadPage(startPos.page, focus = true)
            _ui.update { it.copy(loading = false) }
        }
    }

    // ------------------------------------------------------------------ viewport & settings

    fun setViewport(width: Float, height: Float) {
        if (width <= 0 || height <= 0) return
        val vp = Viewport(width, height)
        if (vp == viewport) return
        viewport = vp
        maybeInitTiles()
        if (::navigator.isInitialized) rebuildPlans()
    }

    private fun maybeInitTiles() {
        val vp = viewport ?: return
        if (tiles != null || !::source.isInitialized) return
        val longSide = maxOf(vp.width, vp.height).toInt().coerceIn(1280, 2048)
        tiles = TileCache(source, viewModelScope, longSide)
    }

    private fun onSettingsChanged(relayout: Boolean) {
        if (!::navigator.isInitialized) return
        _ui.update { it.copy(settings = settings) }
        if (relayout) {
            layouts.clear()
            val p = _ui.value.position.page
            loadJobs.values.forEach { it.cancel() }
            loadJobs.clear()
            loadPage(p, focus = true)
        } else rebuildPlans()
    }

    fun setOverrides(o: BookOverrides) {
        val old = settings
        overrides = o
        _ui.update { it.copy(overrides = o) }
        viewModelScope.launch { c.books.saveOverrides(bookId, Codecs.encode(o)) }
        val s = settings
        onSettingsChanged(relayout = s.direction != old.direction || s.intelligentDetection != old.intelligentDetection || s.speechBubbleProtection != old.speechBubbleProtection)
    }

    private val bias: LearnedBias get() = if (settings.learnPreferences) c.settings.learner else LearnedBias.None

    private fun rebuildPlans() {
        val vp = viewport ?: return
        val pos = _ui.value.position
        val old = plans[pos.page]
        plans.clear()
        for ((page, layout) in layouts) plans[page] = builder.build(page, layout, vp, settings, bias)
        val newPlan = planFor(pos.page)
        val reconciled = if (old != null) navigator.reconcile(pos, old, newPlan) else navigator.clamp(pos, newPlan)
        moveTo(reconciled, pageJump = true)
    }

    // ------------------------------------------------------------------ page loading & preloading

    private fun pageSize(page: Int): SizeF = sizes[page] ?: SizeF(1000f, 1500f)

    /** Plan for a page, or a provisional whole-page plan while detection runs. */
    private fun planFor(page: Int): PagePlan {
        plans[page]?.let { return it }
        val vp = viewport ?: Viewport(1080f, 1920f)
        return builder.fullPage(page, pageSize(page), vp, provisional = true)
    }

    private fun loadPage(page: Int, focus: Boolean) {
        if (page < 0 || page >= source.pageCount) return
        if (layouts.containsKey(page) && plans.containsKey(page)) {
            if (focus) preloadAround(page)
            return
        }
        if (loadJobs[page]?.isActive == true) return
        loadJobs[page] = viewModelScope.launch {
            val size = withContext(Dispatchers.IO) { runCatching { source.pageSize(page) }.getOrNull() }
            if (size != null) {
                sizes[page] = size
                if (_ui.value.position.page == page) {
                    // Show the page immediately (provisional framing) while detection runs.
                    plans.remove(page)
                    refreshTarget(pageJump = true)
                }
            }
            tiles?.requestBase(page)
            val layout = runCatching {
                c.detection.layoutFor(book.fingerprint, source, page, settings)
            }.getOrElse { PageLayout.fullPage(size ?: pageSize(page), settings.direction, 0, "error: ${it.message}") }
            layouts[page] = layout
            launch { runCatching { c.detection.rememberLayout(book.fingerprint, page, layout) } }
            val vp = viewport
            if (vp != null) {
                val old = plans[page]
                val plan = builder.build(page, layout, vp, settings, bias)
                plans[page] = plan
                if (_ui.value.position.page == page) {
                    val restore = pendingRestore?.takeIf { it.page == page }
                    pendingRestore = null
                    val reconciled = if (restore != null) navigator.clamp(restore, plan)
                    else navigator.reconcile(_ui.value.position, old ?: builder.fullPage(page, layout.pageSize, vp, true), plan)
                    // Keep the camera on the whole page if the reader was still looking at the placeholder.
                    moveTo(reconciled, pageJump = old == null || old.provisional)
                }
            }
            if (focus) preloadAround(page)
        }
    }

    private fun preloadAround(page: Int) {
        // Prepare next/previous pages: detection metadata, plans and base bitmaps.
        loadPage(page + 1, focus = false)
        loadPage(page - 1, focus = false)
        tiles?.requestBase(page + 1)
        tiles?.requestBase(page - 1)
        tiles?.trimTo(setOf(page - 1, page, page + 1))
        // Forget far-away plans to bound memory.
        layouts.keys.filter { kotlin.math.abs(it - page) > 4 }.forEach { layouts.remove(it); plans.remove(it) }
    }

    // ------------------------------------------------------------------ navigation

    fun forward() = navigate(true)
    fun backward() = navigate(false)

    private fun navigate(forward: Boolean) {
        if (!::navigator.isInitialized) return
        recordManualAdjustment()
        pendingRestore = null
        val pos = _ui.value.position
        val wasRevealing = _ui.value.revealing
        when (val r = if (forward) navigator.forward(pos) else navigator.backward(pos)) {
            is NavResult.Moved -> {
                val p = r.position
                if (forward && wasRevealing && p.panel != pos.panel) learn(Adjustment.RevealAccepted(panelClass(pos)))
                moveTo(p, pageJump = p.page != pos.page)
                if (p.page != pos.page) loadPage(p.page, focus = true)
            }
            NavResult.EndOfBook -> _ui.update { it.copy(endOfBook = true, message = "End of volume") }
            NavResult.StartOfBook -> _ui.update { it.copy(message = "Beginning of volume") }
        }
    }

    fun goToPage(page: Int) {
        if (!::navigator.isInitialized) return
        recordManualAdjustment()
        pendingRestore = null
        val p = page.coerceIn(0, source.pageCount - 1)
        moveTo(ReadingPosition(p, 0, 0), pageJump = true)
        loadPage(p, focus = true)
    }

    /** Jumps to the overview step of the current panel ("show whole panel"). */
    fun showWholePanel() {
        val pos = _ui.value.position
        val plan = planFor(pos.page)
        val steps = plan.panels[pos.panel]
        val framing = plan.framings.getOrNull(pos.panel)
        if (framing != null) learn(Adjustment.FullPanel(framing.panelClass, framing.scale, framing.fitScale))
        if (framing?.strategy == FramingStrategy.PROGRESSIVE_REVEAL) learn(Adjustment.RevealRejected(framing.panelClass))
        val overview = steps.indexOfLast { it.overview }
        if (overview >= 0) {
            moveTo(pos.copy(step = overview), pageJump = false)
        } else if (framing != null) {
            val whole = CameraState(framing.content.centerX, framing.content.centerY, framing.fitScale)
            _ui.update { it.copy(target = whole, targetVersion = it.targetVersion + 1, pageJump = false) }
        }
    }

    /** Shows the whole page without changing the reading position. */
    fun showWholePage() {
        val size = sizes[_ui.value.position.page] ?: return
        val vp = viewport ?: return
        _ui.update { it.copy(target = CameraState.fit(size.toRect(), vp), targetVersion = it.targetVersion + 1, pageJump = false) }
    }

    private fun moveTo(pos: ReadingPosition, pageJump: Boolean) {
        _ui.update { it.copy(position = pos, endOfBook = false) }
        refreshTarget(pageJump)
        viewModelScope.launch(Dispatchers.IO) { c.books.saveProgress(bookId, pos.page, pos.panel, pos.step) }
    }

    private fun refreshTarget(pageJump: Boolean) {
        val pos = _ui.value.position
        val plan = planFor(pos.page)
        val p = navigator.clamp(pos, plan)
        val step = plan.step(p)
        val framing = plan.framings.getOrNull(p.panel)
        _ui.update {
            it.copy(
                position = p,
                pageSize = sizes[p.page],
                target = step.camera,
                targetVersion = it.targetVersion + 1,
                pageJump = pageJump,
                layout = layouts[p.page],
                panelCount = plan.panels.size,
                stepCount = plan.panels[p.panel].size,
                revealing = framing?.strategy == FramingStrategy.PROGRESSIVE_REVEAL && !step.overview,
                detectionPending = plan.provisional,
                settings = settings,
                message = layouts[p.page]?.takeIf { l -> l.lowConfidenceFallback && p.panel == 0 && p.step == 0 }
                    ?.let { "Panel detection is uncertain on this page — showing the full page. Tap ✎ to fix." },
            )
        }
    }

    // ------------------------------------------------------------------ manual camera & learning

    /** Called by the screen when a pinch/pan gesture ends. */
    fun onManualCamera(scale: Float) {
        manualScale = scale
        manualAt = System.currentTimeMillis()
    }

    private fun recordManualAdjustment() {
        val s = manualScale ?: return
        manualScale = null
        val target = _ui.value.target ?: return
        learn(Adjustment.Zoom(panelClass(_ui.value.position), target.scale, s, System.currentTimeMillis() - manualAt))
    }

    private fun panelClass(pos: ReadingPosition): PanelClass =
        plans[pos.page]?.framings?.getOrNull(pos.panel)?.panelClass ?: PanelClass.FULL_PAGE

    private fun learn(a: Adjustment) {
        if (!settings.learnPreferences) return
        if (c.settings.learner.observe(a)) c.settings.persistLearner()
    }

    fun toggleControls() = _ui.update { it.copy(controlsVisible = !it.controlsVisible) }
    fun dismissMessage() = _ui.update { it.copy(message = null) }

    /** Called after the panel editor saves, so the page is re-read with the correction. */
    fun reloadPage(page: Int) {
        layouts.remove(page)
        plans.remove(page)
        loadJobs.remove(page)?.cancel()
        loadPage(page, focus = page == _ui.value.position.page)
    }

    val fingerprint: String get() = book.fingerprint

    override fun onCleared() {
        if (::source.isInitialized) runCatching { source.close() }
    }
}
