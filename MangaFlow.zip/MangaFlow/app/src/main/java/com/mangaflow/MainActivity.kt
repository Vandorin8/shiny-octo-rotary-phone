package com.mangaflow

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mangaflow.reader.ReaderScreen
import com.mangaflow.ui.CalibrationScreen
import com.mangaflow.ui.LibraryScreen
import com.mangaflow.ui.MangaFlowTheme
import com.mangaflow.ui.PanelEditorScreen
import com.mangaflow.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    private var pendingImport by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val c = (application as MangaFlowApp).container
        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            MangaFlowTheme {
                val nav = rememberNavController()
                val calibrated by c.settings.calibrated.collectAsState(initial = true)
                NavHost(nav, startDestination = "library") {
                    composable("library") {
                        if (!calibrated) {
                            // First run: onboarding calibration.
                            CalibrationScreen(c) { c.settings.setCalibratedIfUnset() }
                        } else {
                            LibraryScreen(
                                c, pendingImport, onImportConsumed = { pendingImport = null },
                                onOpen = { nav.navigate("reader/$it") },
                                onSettings = { nav.navigate("settings") },
                            )
                        }
                    }
                    composable("settings") {
                        SettingsScreen(c, onBack = { nav.popBackStack() }, onCalibrate = { nav.navigate("calibrate") })
                    }
                    composable("calibrate") { CalibrationScreen(c) { nav.popBackStack() } }
                    composable("reader/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                        val id = entry.arguments!!.getLong("id")
                        val edited by entry.savedStateHandle.getStateFlow<Int?>("editedPage", null).collectAsState()
                        ReaderScreen(
                            bookId = id,
                            onBack = { nav.popBackStack() },
                            onEditPanels = { _, page -> nav.navigate("editor/$id/$page") },
                            editedPage = edited,
                            onEditedPageConsumed = { entry.savedStateHandle["editedPage"] = null },
                        )
                    }
                    composable(
                        "editor/{id}/{page}",
                        arguments = listOf(navArgument("id") { type = NavType.LongType }, navArgument("page") { type = NavType.IntType }),
                    ) { entry ->
                        val id = entry.arguments!!.getLong("id")
                        val page = entry.arguments!!.getInt("page")
                        PanelEditorScreen(c, id, page) { saved ->
                            if (saved) nav.previousBackStackEntry?.savedStateHandle?.set("editedPage", page)
                            nav.popBackStack()
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) intent.data?.let { pendingImport = it }
    }
}
