package com.mangaflow.data.db

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "books", indices = [Index(value = ["fingerprint"], unique = true)])
data class BookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    /** Private copy of the imported file inside app storage (originals are never modified). */
    val path: String,
    val format: String,
    /** Source-file identity: SHA-256 of size + first/last MiB. Survives re-imports. */
    val fingerprint: String,
    val pageCount: Int,
    val coverPath: String?,
    val addedAt: Long,
    val lastReadAt: Long = 0,
    val lastPage: Int = 0,
    val lastPanel: Int = 0,
    val lastStep: Int = 0,
    /** Per-book setting overrides (JSON), null = use global settings. */
    val overridesJson: String? = null,
)

/**
 * Versioned detection cache. Automatic results are invalidated when [detectorId] changes;
 * manual corrections live in a separate table and are never invalidated.
 */
@Entity(tableName = "page_analysis", primaryKeys = ["fingerprint", "pageIndex"])
data class PageAnalysisEntity(
    val fingerprint: String,
    val pageIndex: Int,
    val width: Float,
    val height: Float,
    val detectorId: String,
    /** Raw detector output (candidates, bubbles, content bounds) — settings-independent. */
    val rawJson: String,
    /** Last assembled layout (geometry, reading sequence, confidence). */
    val layoutJson: String?,
    val analyzedAt: Long,
    val detectMillis: Long,
)

@Entity(tableName = "page_corrections", primaryKeys = ["fingerprint", "pageIndex"])
data class PageCorrectionEntity(
    val fingerprint: String,
    val pageIndex: Int,
    val correctionJson: String,
    val updatedAt: Long,
)

@Dao
interface BookDao {
    @Query("SELECT * FROM books ORDER BY CASE WHEN lastReadAt = 0 THEN addedAt ELSE lastReadAt END DESC")
    fun observeAll(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE id = :id")
    suspend fun get(id: Long): BookEntity?

    @Query("SELECT * FROM books WHERE fingerprint = :fp")
    suspend fun byFingerprint(fp: String): BookEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(book: BookEntity): Long

    @Query("UPDATE books SET lastPage = :page, lastPanel = :panel, lastStep = :step, lastReadAt = :at WHERE id = :id")
    suspend fun saveProgress(id: Long, page: Int, panel: Int, step: Int, at: Long)

    @Query("UPDATE books SET overridesJson = :json WHERE id = :id")
    suspend fun saveOverrides(id: Long, json: String?)

    @Query("DELETE FROM books WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface AnalysisDao {
    @Query("SELECT * FROM page_analysis WHERE fingerprint = :fp AND pageIndex = :page")
    suspend fun get(fp: String, page: Int): PageAnalysisEntity?

    @Upsert
    suspend fun put(e: PageAnalysisEntity)

    @Query("DELETE FROM page_analysis WHERE fingerprint = :fp")
    suspend fun deleteBook(fp: String)

    @Query("DELETE FROM page_analysis WHERE detectorId != :currentId")
    suspend fun invalidateOtherThan(currentId: String)

    @Query("SELECT COUNT(*) FROM page_analysis WHERE fingerprint = :fp AND detectorId = :id")
    suspend fun analyzedCount(fp: String, id: String): Int

    @Query("SELECT AVG(detectMillis) FROM page_analysis WHERE detectorId = :id")
    suspend fun averageMillis(id: String): Double?
}

@Dao
interface CorrectionDao {
    @Query("SELECT * FROM page_corrections WHERE fingerprint = :fp AND pageIndex = :page")
    suspend fun get(fp: String, page: Int): PageCorrectionEntity?

    @Upsert
    suspend fun put(e: PageCorrectionEntity)

    @Query("DELETE FROM page_corrections WHERE fingerprint = :fp AND pageIndex = :page")
    suspend fun delete(fp: String, page: Int)

    @Query("DELETE FROM page_corrections WHERE fingerprint = :fp")
    suspend fun deleteBook(fp: String)
}

@Database(entities = [BookEntity::class, PageAnalysisEntity::class, PageCorrectionEntity::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun books(): BookDao
    abstract fun analysis(): AnalysisDao
    abstract fun corrections(): CorrectionDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "mangaflow.db").build()
    }
}
