package com.mangaflow.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mangaflow.AppContainer
import com.mangaflow.data.ImportResult
import com.mangaflow.data.db.BookEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(c: AppContainer, pendingImport: Uri?, onImportConsumed: () -> Unit, onOpen: (Long) -> Unit, onSettings: () -> Unit) {
    val books by c.books.books.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var importing by remember { mutableStateOf(0) }
    var toDelete by remember { mutableStateOf<BookEntity?>(null) }

    fun importAll(uris: List<Uri>) {
        if (uris.isEmpty()) return
        scope.launch {
            importing += uris.size
            val failures = mutableListOf<String>()
            var imported = 0
            for (u in uris) {
                when (val r = c.books.import(u)) {
                    is ImportResult.Imported -> imported++
                    is ImportResult.AlreadyInLibrary -> failures += "${r.book.title}: already in library"
                    is ImportResult.Failed -> failures += "${r.name}: ${r.reason}"
                }
                importing--
            }
            val msg = buildString {
                if (imported > 0) append("Imported $imported volume${if (imported > 1) "s" else ""}. ")
                if (failures.isNotEmpty()) append(failures.joinToString("; "))
            }
            if (msg.isNotBlank()) snackbar.showSnackbar(msg)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { importAll(it) }

    LaunchedEffect(pendingImport) {
        if (pendingImport != null) { importAll(listOf(pendingImport)); onImportConsumed() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manga Flow") },
                actions = { IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Settings") } },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    picker.launch(arrayOf(
                        "application/zip", "application/x-cbz", "application/vnd.comicbook+zip",
                        "application/x-rar-compressed", "application/vnd.rar", "application/x-cbr", "application/vnd.comicbook-rar",
                        "application/epub+zip", "application/pdf", "application/octet-stream",
                    ))
                },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Import") },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (importing > 0) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (books.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Import CBZ, CBR, EPUB or PDF manga to start reading.\nEverything stays on this device.",
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            } else {
                LazyVerticalGrid(GridCells.Adaptive(118.dp), contentPadding = PaddingValues(12.dp)) {
                    items(books, key = { it.id }) { b ->
                        Column(
                            Modifier.padding(6.dp).combinedClickable(onClick = { onOpen(b.id) }, onLongClick = { toDelete = b }),
                        ) {
                            Cover(b)
                            Text(b.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                            if (b.lastReadAt > 0) {
                                LinearProgressIndicator(
                                    progress = { (b.lastPage + 1f) / b.pageCount },
                                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp).height(3.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { b ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Remove from library?") },
            text = { Text("“${b.title}” will be removed from Manga Flow. Your original file is not affected; panel corrections are kept in case you re-import it.") },
            confirmButton = { TextButton(onClick = { scope.launch { c.books.delete(b) }; toDelete = null }) { Text("Remove") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Cover(b: BookEntity) {
    val img by produceState<ImageBitmap?>(null, b.coverPath) {
        value = b.coverPath?.let { p -> withContext(Dispatchers.IO) { BitmapFactory.decodeFile(p)?.asImageBitmap() } }
    }
    Box(Modifier.fillMaxWidth().aspectRatio(0.7f).background(Color(0xFF2A2A30))) {
        img?.let { Image(it, b.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
    }
}
