package com.mangaflow.data

import com.mangaflow.engine.geometry.PointF
import com.mangaflow.engine.geometry.Polygon
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.layout.EditedPanel
import com.mangaflow.engine.layout.PageCorrection
import com.mangaflow.engine.model.Bubble
import com.mangaflow.engine.model.CandidateSource
import com.mangaflow.engine.model.LayoutConfidence
import com.mangaflow.engine.model.PageKind
import com.mangaflow.engine.model.PageLayout
import com.mangaflow.engine.model.Panel
import com.mangaflow.engine.model.PanelCandidate
import com.mangaflow.engine.model.ReadingDirection
import com.mangaflow.engine.model.RevealOverride
import com.mangaflow.engine.settings.BookOverrides
import com.mangaflow.engine.settings.ReadingSizePreset
import com.mangaflow.engine.settings.RevealMode
import org.json.JSONArray
import org.json.JSONObject

/** Settings-independent detector output, cached per page. */
data class RawDetection(
    val pageSize: SizeF,
    val contentBounds: RectF,
    val classical: List<PanelCandidate>,
    val ml: List<PanelCandidate>,
    val bubbles: List<Bubble>,
    val mlStatus: String,
)

object Codecs {
    // ---- primitives ----
    private fun RectF.json() = JSONArray().put(left.toDouble()).put(top.toDouble()).put(right.toDouble()).put(bottom.toDouble())
    private fun JSONArray.rect() = RectF(getDouble(0).toFloat(), getDouble(1).toFloat(), getDouble(2).toFloat(), getDouble(3).toFloat())
    private fun Polygon.json() = JSONArray().also { a -> points.forEach { a.put(it.x.toDouble()).put(it.y.toDouble()) } }
    private fun JSONArray.polygon() = Polygon((0 until length() / 2).map { PointF(getDouble(2 * it).toFloat(), getDouble(2 * it + 1).toFloat()) })
    private fun List<RectF>.json() = JSONArray().also { a -> forEach { a.put(it.json()) } }
    private fun JSONArray.rects() = (0 until length()).map { getJSONArray(it).rect() }

    private fun PanelCandidate.json() = JSONObject()
        .put("b", bounds.json()).put("s", score.toDouble()).put("src", source.name)
        .put("g", gutterEvidence.toDouble()).put("bl", borderless)
        .also { o -> polygon?.let { o.put("p", it.json()) } }

    private fun JSONObject.candidate() = PanelCandidate(
        bounds = getJSONArray("b").rect(),
        polygon = optJSONArray("p")?.polygon(),
        score = getDouble("s").toFloat(),
        source = CandidateSource.valueOf(getString("src")),
        gutterEvidence = optDouble("g", 0.0).toFloat(),
        borderless = optBoolean("bl", false),
    )

    // ---- raw detection ----
    fun encode(r: RawDetection): String = JSONObject()
        .put("w", r.pageSize.width.toDouble()).put("h", r.pageSize.height.toDouble())
        .put("content", r.contentBounds.json())
        .put("cv", JSONArray().also { a -> r.classical.forEach { a.put(it.json()) } })
        .put("ml", JSONArray().also { a -> r.ml.forEach { a.put(it.json()) } })
        .put("bubbles", JSONArray().also { a ->
            r.bubbles.forEach { a.put(JSONObject().put("b", it.bounds.json()).put("s", it.score.toDouble()).put("v", it.verticalText)) }
        })
        .put("mlStatus", r.mlStatus)
        .toString()

    fun decodeRaw(s: String): RawDetection {
        val o = JSONObject(s)
        fun cands(k: String) = o.getJSONArray(k).let { a -> (0 until a.length()).map { a.getJSONObject(it).candidate() } }
        val b = o.getJSONArray("bubbles")
        return RawDetection(
            SizeF(o.getDouble("w").toFloat(), o.getDouble("h").toFloat()),
            o.getJSONArray("content").rect(),
            cands("cv"), cands("ml"),
            (0 until b.length()).map { b.getJSONObject(it).let { j -> Bubble(j.getJSONArray("b").rect(), j.getDouble("s").toFloat(), j.optBoolean("v", true)) } },
            o.optString("mlStatus", ""),
        )
    }

    // ---- assembled layout ----
    fun encode(l: PageLayout): String = JSONObject()
        .put("w", l.pageSize.width.toDouble()).put("h", l.pageSize.height.toDouble())
        .put("kind", l.kind.name).put("dir", l.direction.name).put("ver", l.detectorVersion)
        .put("manual", l.manual).put("fallback", l.lowConfidenceFallback)
        .put("conf", JSONArray().put(l.confidence.boundaries.toDouble()).put(l.confidence.panelCount.toDouble())
            .put(l.confidence.readingOrder.toDouble()).put(l.confidence.dialogue.toDouble()).put(l.confidence.classification.toDouble()))
        .put("panels", JSONArray().also { a ->
            l.panels.forEach { p ->
                a.put(JSONObject().put("id", p.id).put("b", p.bounds.json()).put("safe", p.safeBounds.json())
                    .put("c", p.confidence.toDouble()).put("bubbles", p.bubbles.json()).put("bl", p.borderless)
                    .put("rev", p.revealOverride.name).put("m", p.extraMargin.toDouble())
                    .also { o -> p.polygon?.let { o.put("p", it.json()) } })
            }
        })
        .put("diag", JSONArray(l.diagnostics))
        .toString()

    fun decodeLayout(s: String): PageLayout {
        val o = JSONObject(s)
        val c = o.getJSONArray("conf")
        val pa = o.getJSONArray("panels")
        val d = o.optJSONArray("diag")
        return PageLayout(
            pageSize = SizeF(o.getDouble("w").toFloat(), o.getDouble("h").toFloat()),
            panels = (0 until pa.length()).map { i ->
                val p = pa.getJSONObject(i)
                Panel(
                    id = p.getInt("id"), bounds = p.getJSONArray("b").rect(), polygon = p.optJSONArray("p")?.polygon(),
                    safeBounds = p.getJSONArray("safe").rect(), confidence = p.getDouble("c").toFloat(),
                    bubbles = p.getJSONArray("bubbles").rects(), borderless = p.optBoolean("bl"),
                    revealOverride = RevealOverride.valueOf(p.optString("rev", "DEFAULT")), extraMargin = p.optDouble("m", 0.0).toFloat(),
                )
            },
            kind = PageKind.valueOf(o.getString("kind")),
            confidence = LayoutConfidence(c.getDouble(0).toFloat(), c.getDouble(1).toFloat(), c.getDouble(2).toFloat(), c.getDouble(3).toFloat(), c.getDouble(4).toFloat()),
            direction = ReadingDirection.valueOf(o.getString("dir")),
            detectorVersion = o.getInt("ver"),
            manual = o.optBoolean("manual"),
            lowConfidenceFallback = o.optBoolean("fallback"),
            diagnostics = if (d == null) emptyList() else (0 until d.length()).map { d.getString(it) },
        )
    }

    // ---- manual corrections ----
    fun encode(c: PageCorrection): String = JSONObject()
        .put("full", c.fullPage)
        .put("panels", JSONArray().also { a ->
            c.panels.forEach { p ->
                a.put(JSONObject().put("b", p.bounds.json()).put("safe", p.safeBounds.json()).put("rev", p.reveal.name).put("m", p.margin.toDouble()))
            }
        }).toString()

    fun decodeCorrection(s: String): PageCorrection {
        val o = JSONObject(s)
        val a = o.getJSONArray("panels")
        return PageCorrection(
            panels = (0 until a.length()).map { i ->
                val p = a.getJSONObject(i)
                EditedPanel(p.getJSONArray("b").rect(), p.getJSONArray("safe").rect(), RevealOverride.valueOf(p.optString("rev", "DEFAULT")), p.optDouble("m", 0.0).toFloat())
            },
            fullPage = o.optBoolean("full"),
        )
    }

    // ---- per-book overrides ----
    fun encode(o: BookOverrides): String? = if (o.isEmpty) null else JSONObject().apply {
        o.intelligentDetection?.let { put("det", it) }
        o.direction?.let { put("dir", it.name) }
        o.automaticPanelZoom?.let { put("zoom", it) }
        o.sizePreset?.let { put("size", it.name) }
        o.customSize?.let { put("custom", it.toDouble()) }
        o.revealMode?.let { put("reveal", it.name) }
        o.showCompletePanelAfterReveal?.let { put("complete", it) }
        o.speechBubbleProtection?.let { put("bubbles", it) }
    }.toString()

    fun decodeOverrides(s: String?): BookOverrides {
        if (s.isNullOrBlank()) return BookOverrides()
        val o = JSONObject(s)
        return BookOverrides(
            intelligentDetection = if (o.has("det")) o.getBoolean("det") else null,
            direction = o.optString("dir").takeIf { it.isNotEmpty() }?.let { ReadingDirection.valueOf(it) },
            automaticPanelZoom = if (o.has("zoom")) o.getBoolean("zoom") else null,
            sizePreset = o.optString("size").takeIf { it.isNotEmpty() }?.let { ReadingSizePreset.valueOf(it) },
            customSize = if (o.has("custom")) o.getDouble("custom").toFloat() else null,
            revealMode = o.optString("reveal").takeIf { it.isNotEmpty() }?.let { RevealMode.valueOf(it) },
            showCompletePanelAfterReveal = if (o.has("complete")) o.getBoolean("complete") else null,
            speechBubbleProtection = if (o.has("bubbles")) o.getBoolean("bubbles") else null,
        )
    }
}
