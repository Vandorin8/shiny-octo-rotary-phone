package com.mangaflow.reader

import android.app.Application
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mangaflow.engine.camera.CameraState
import com.mangaflow.engine.camera.Viewport
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.settings.TransitionSpeed
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

class ReaderVmFactory(private val app: Application, private val bookId: Long, private val page: Int?) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = ReaderViewModel(app, bookId, page) as T
}

@Composable
fun ReaderScreen(
    bookId: Long,
    onBack: () -> Unit,
    onEditPanels: (fingerprint: String, page: Int) -> Unit,
    editedPage: Int?,
    onEditedPageConsumed: () -> Unit,
) {
    val context = LocalContext.current
    val app = context.applicationContext as Application
    val vm: ReaderViewModel = viewModel(key = "reader-$bookId", factory = ReaderVmFactory(app, bookId, null))
    val ui by vm.ui.collectAsState()

    LaunchedEffect(editedPage) {
        if (editedPage != null) { vm.reloadPage(editedPage); onEditedPageConsumed() }
    }

    // ---- Camera animation: interruptible, retargets instead of queueing ----
    var displayed by remember { mutableStateOf<CameraState?>(null) }
    var manual by remember { mutableStateOf(false) }
    val systemNoAnim = remember {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }
    val duration = if (ui.settings.reducedMotion || systemNoAnim) 0 else ui.settings.transition.millis
    val pageAlpha = remember { Animatable(1f) }

    LaunchedEffect(ui.targetVersion) {
        val target = ui.target ?: return@LaunchedEffect
        manual = false
        val start = displayed
        if (start == null || ui.pageJump || duration == 0) {
            displayed = target
            if (ui.pageJump && duration > 0 && ui.settings.transition != TransitionSpeed.OFF) {
                pageAlpha.snapTo(0.35f)
                pageAlpha.animateTo(1f, tween(180))
            }
            return@LaunchedEffect
        }
        val t = Animatable(0f)
        t.animateTo(1f, tween(duration, easing = FastOutSlowInEasing)) {
            displayed = CameraState.lerp(start, target, value)
        }
    }

    var vpSize by remember { mutableStateOf(IntSize.Zero) }
    val tileVersion = vm.tiles?.version?.collectAsState()

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged {
                vpSize = it
                vm.setViewport(it.width.toFloat(), it.height.toFloat())
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { o ->
                        val w = size.width
                        when {
                            o.x < w * 0.33f -> vm.forward()   // tap left: forward (Japanese convention)
                            o.x > w * 0.67f -> vm.backward()  // tap right: backward
                            else -> vm.toggleControls()
                        }
                    },
                    onDoubleTap = { vm.showWholePanel() },
                )
            }
            .pointerInput(Unit) {
                // Pinch-zoom and pan. A drag only becomes a pan after the touch slop (or with two
                // fingers) and consumes its events, which cancels the tap detector.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var transforming = false
                    var accumulated = Offset.Zero
                    do {
                        val event = awaitPointerEvent()
                        val pointers = event.changes.count { it.pressed }
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        if (!transforming) {
                            accumulated += pan
                            if (pointers >= 2 || accumulated.getDistance() > viewConfiguration.touchSlop) transforming = true
                        }
                        val cam = displayed
                        val pageSz = ui.pageSize
                        if (transforming && cam != null && pageSz != null && vpSize.width > 0 && pointers > 0) {
                            val vp = Viewport(vpSize.width.toFloat(), vpSize.height.toFloat())
                            val minScale = minOf(vp.width / pageSz.width, vp.height / pageSz.height) * 0.9f
                            val newScale = (cam.scale * zoom).coerceIn(minScale, 4f)
                            // Zoom about the gesture centroid, then pan.
                            val centroid = event.calculateCentroid(useCurrent = true)
                            val focus = cam.toSource(centroid.x, centroid.y, vp)
                            val cx = focus.x - (centroid.x - vp.width / 2f) / newScale - pan.x / newScale
                            val cy = focus.y - (centroid.y - vp.height / 2f) / newScale - pan.y / newScale
                            displayed = CameraState(cx, cy, newScale).constrainedTo(pageSz, vp, minScale, 4f)
                            manual = true
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                    if (transforming) displayed?.let { vm.onManualCamera(it.scale) }
                }
            },
    ) {
        val cam = displayed
        val pageSize = ui.pageSize
        val tc = vm.tiles
        if (cam != null && pageSize != null && tc != null && vpSize.width > 0) {
            val page = ui.position.page
            Canvas(Modifier.fillMaxSize()) {
                // Reading the tile version in the draw phase redraws as soon as tiles arrive.
                tileVersion?.value
                drawPage(tc, page, pageSize.width, pageSize.height, cam, pageAlpha.value)
            }
        }

        if (ui.loading || (ui.detectionPending && ui.target == null)) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
        ui.error?.let { Text(it, color = Color.White, modifier = Modifier.align(Alignment.Center).padding(24.dp)) }

        // Small progress hint for multi-step reveals.
        if (ui.stepCount > 1 && !ui.controlsVisible) {
            Text(
                "${ui.position.step + 1}/${ui.stepCount}",
                color = Color.White.copy(alpha = 0.6f),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.4f)).padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }

        ui.message?.let { msg ->
            Row(
                Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp)
                    .background(Color(0xE0202024), MaterialTheme.shapes.medium).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(msg, color = Color.White, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f, fill = false))
                TextButton(onClick = vm::dismissMessage) { Text("OK") }
            }
        }

        AnimatedVisibility(ui.controlsVisible, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
            ReaderControls(
                ui = ui,
                onBack = onBack,
                onEdit = { onEditPanels(vm.fingerprint, ui.position.page) },
                onPage = vm::goToPage,
                onWholePage = vm::showWholePage,
                onWholePanel = vm::showWholePanel,
                onOverrides = vm::setOverrides,
                manual = manual,
            )
        }
    }
}

/** Draws the page through the camera: base bitmap, then sharper tiles where needed. */
private fun DrawScope.drawPage(tc: TileCache, page: Int, pageW: Float, pageH: Float, cam: CameraState, alpha: Float) {
    val vp = Viewport(size.width, size.height)
    fun dst(r: RectF): Pair<IntOffset, IntSize> {
        val tl = cam.toScreen(r.left, r.top, vp)
        val br = cam.toScreen(r.right, r.bottom, vp)
        val l = floor(tl.x).toInt(); val t = floor(tl.y).toInt()
        return IntOffset(l, t) to IntSize(ceil(br.x).toInt() - l, ceil(br.y).toInt() - t)
    }
    val base = tc.base(page) ?: return
    val (o, s) = dst(RectF(0f, 0f, pageW, pageH))
    drawImage(base.asImageBitmap(), IntOffset.Zero, IntSize(base.width, base.height), o, s, alpha = alpha, filterQuality = FilterQuality.Medium)
    val visible = cam.visibleRect(vp)
    for (t in tc.tilesFor(page, pageW, visible, cam.scale, base.width)) {
        val (to, ts) = dst(RectF(t.src.left.toFloat(), t.src.top.toFloat(), t.src.right.toFloat(), t.src.bottom.toFloat()))
        drawImage(t.bitmap.asImageBitmap(), IntOffset.Zero, IntSize(t.bitmap.width, t.bitmap.height), to, ts, alpha = alpha, filterQuality = FilterQuality.Medium)
    }
}

@Composable
private fun ReaderControls(
    ui: ReaderUi,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onPage: (Int) -> Unit,
    onWholePage: () -> Unit,
    onWholePanel: () -> Unit,
    onOverrides: (com.mangaflow.engine.settings.BookOverrides) -> Unit,
    manual: Boolean,
) {
    var showBookSettings by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xCC111114)).statusBarsPadding().padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(ui.title, color = Color.White, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                val l = ui.layout
                val detail = when {
                    ui.detectionPending -> "Detecting panels…"
                    l == null -> ""
                    l.manual -> "Panel ${ui.position.panel + 1}/${ui.panelCount} · manual layout"
                    l.lowConfidenceFallback -> "Full page (detection confidence ${(l.confidence.overall * 100).roundToInt()}%)"
                    else -> "Panel ${ui.position.panel + 1}/${ui.panelCount} · confidence ${(l.confidence.overall * 100).roundToInt()}%"
                }
                Text(detail, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall)
            }
            if (ui.settings.manualCorrections) IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Edit panels", tint = Color.White) }
            IconButton(onClick = { showBookSettings = true }) { Icon(Icons.Filled.Tune, "Book settings", tint = Color.White) }
        }

        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xCC111114)).navigationBarsPadding().padding(12.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onWholePanel) { Icon(Icons.Filled.Crop, null, tint = Color.White); Spacer(Modifier.width(4.dp)); Text("Whole panel", color = Color.White) }
                TextButton(onClick = onWholePage) { Icon(Icons.Filled.CropFree, null, tint = Color.White); Spacer(Modifier.width(4.dp)); Text("Whole page", color = Color.White) }
                if (manual) Text("Manual zoom · tap to resume", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall)
            }
            if (ui.pageCount > 1) {
                var slider by remember(ui.position.page) { mutableFloatStateOf(ui.position.page.toFloat()) }
                // Right-to-left books get a right-to-left page slider.
                val rtl = ui.settings.direction == com.mangaflow.engine.model.ReadingDirection.RIGHT_TO_LEFT
                Text("Page ${slider.roundToInt() + 1} / ${ui.pageCount}", color = Color.White, style = MaterialTheme.typography.labelMedium)
                Slider(
                    value = if (rtl) (ui.pageCount - 1) - slider else slider,
                    onValueChange = { v -> slider = if (rtl) (ui.pageCount - 1) - v else v },
                    onValueChangeFinished = { onPage(slider.roundToInt()) },
                    valueRange = 0f..(ui.pageCount - 1).toFloat(),
                )
            }
        }
    }
    if (showBookSettings) {
        BookSettingsDialog(ui.overrides, ui.settings, onDismiss = { showBookSettings = false }, onChange = onOverrides)
    }
}
