package com.mangaflow.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mangaflow.engine.layout.LowConfidenceFallback
import com.mangaflow.engine.model.ReadingDirection
import com.mangaflow.engine.model.RevealOverride
import com.mangaflow.engine.settings.ReadingSizePreset
import com.mangaflow.engine.settings.RevealMode
import com.mangaflow.engine.settings.TransitionSpeed

@Composable
fun MangaFlowTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFFF7A6E),
            secondary = Color(0xFFB9C4FF),
            background = Color(0xFF121214),
            surface = Color(0xFF1B1B1F),
        ),
        content = content,
    )
}

fun Enum<*>.label(): String = when (this) {
    ReadingDirection.RIGHT_TO_LEFT -> "Japanese (right → left)"
    ReadingDirection.LEFT_TO_RIGHT -> "Western (left → right)"
    RevealMode.OFF -> "Off"
    RevealMode.AUTOMATIC -> "Automatic"
    RevealMode.ALWAYS_FOR_OVERSIZED -> "Always for oversized panels"
    ReadingSizePreset.COMPACT -> "Compact"
    ReadingSizePreset.BALANCED -> "Balanced"
    ReadingSizePreset.LARGE -> "Large"
    ReadingSizePreset.EXTRA_LARGE -> "Extra Large"
    ReadingSizePreset.CUSTOM -> "Custom"
    TransitionSpeed.OFF -> "Off"
    TransitionSpeed.FAST -> "Fast"
    TransitionSpeed.NORMAL -> "Normal"
    TransitionSpeed.SLOW -> "Slow"
    LowConfidenceFallback.FULL_PAGE -> "Full page"
    LowConfidenceFallback.CONSERVATIVE_CROP -> "Conservative larger crop"
    LowConfidenceFallback.SUGGEST_REGIONS -> "Full page + suggest regions"
    RevealOverride.DEFAULT -> "Auto"
    RevealOverride.NEVER -> "Never"
    RevealOverride.ALWAYS -> "Always"
    else -> name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> ChoiceRow(title: String, options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)) {
            options.forEach { opt ->
                FilterChip(selected = opt == selected, onClick = { onSelect(opt) }, label = { Text(label(opt)) })
            }
        }
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String? = null, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)) }
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
