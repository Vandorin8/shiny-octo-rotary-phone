package com.mangaflow.ui

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.mangaflow.AppContainer
import com.mangaflow.engine.camera.RevealPlanner
import com.mangaflow.engine.camera.Viewport
import com.mangaflow.engine.camera.ZoomEngine
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.model.LayoutConfidence
import com.mangaflow.engine.model.PageKind
import com.mangaflow.engine.model.PageLayout
import com.mangaflow.engine.model.Panel
import com.mangaflow.engine.model.ReadingDirection
import com.mangaflow.engine.settings.ReaderSettings
import com.mangaflow.engine.settings.ReadingSizePreset
import kotlinx.coroutines.flow.first
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * "Choose Your Reading Comfort": the slider drives the real ZoomEngine, and the preview renders
 * each representative sample at exactly the on-screen scale the reader would use on this phone.
 */
@Composable
fun CalibrationScreen(c: AppContainer, onDone: () -> Unit) {
    val context = LocalContext.current
    val samples = remember { CalibrationSamples.build() }
    var selected by remember { mutableIntStateOf(0) }
    var value by remember { mutableFloatStateOf(ReadingSizePreset.BALANCED.value) }
    LaunchedEffect(Unit) { value = c.settings.settings.first().readingSize }

    val dm = context.resources.displayMetrics
    val screen = Viewport(dm.widthPixels.toFloat(), dm.heightPixels.toFloat())
    val zoom = remember { ZoomEngine() }
    val planner = remember { RevealPlanner() }

    Column(Modifier.fillMaxSize().background(Color(0xFF121214)).statusBarsPadding().navigationBarsPadding()) {
        Text("Choose Your Reading Comfort", style = MaterialTheme.typography.headlineSmall, color = Color.White, modifier = Modifier.padding(16.dp))
        Text(
            "Move the slider until the dialogue and artwork feel comfortable. The preview is shown at the exact size the reader will use on this screen.",
            style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.75f), modifier = Modifier.padding(horizontal = 16.dp),
        )
        LazyRow(Modifier.padding(8.dp)) {
            itemsIndexed(samples) { i, s ->
                FilterChip(selected = i == selected, onClick = { selected = i }, label = { Text(s.name) }, modifier = Modifier.padding(horizontal = 4.dp))
            }
        }
        val sample = samples[selected]
        val settings = ReaderSettings(sizePreset = ReadingSizePreset.CUSTOM, customSize = value)
        val framing = zoom.frame(sample.panel, sample.layout, screen, settings)
        val firstStep = planner.plan(sample.panel, framing, sample.layout.pageSize, screen, ReadingDirection.RIGHT_TO_LEFT, true).first()

        Box(Modifier.fillMaxWidth().weight(1f).clipToBounds().background(Color.Black)) {
            Canvas(Modifier.fillMaxSize()) {
                val vp = Viewport(size.width, size.height)
                val cam = firstStep.camera
                val img = sample.bitmap
                val tl = cam.toScreen(sample.panel.bounds.left, sample.panel.bounds.top, vp)
                val br = cam.toScreen(sample.panel.bounds.right, sample.panel.bounds.bottom, vp)
                drawImage(
                    img.asImageBitmap(), IntOffset.Zero, IntSize(img.width, img.height),
                    IntOffset(floor(tl.x).toInt(), floor(tl.y).toInt()),
                    IntSize(ceil(br.x - tl.x).toInt(), ceil(br.y - tl.y).toInt()),
                    filterQuality = FilterQuality.Medium,
                )
            }
            Text(
                if (framing.strategy.name == "PROGRESSIVE_REVEAL") "Revealed in steps at this size" else "Whole panel fits",
                color = Color.White, style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(8.dp).background(Color.Black.copy(alpha = 0.6f)).padding(4.dp),
            )
        }

        Column(Modifier.padding(16.dp)) {
            Row {
                Text("Compact", color = Color.White, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.weight(1f))
                Text(ReadingSizePreset.nearest(value).label() + " · ${(value * 100).roundToInt()}", color = Color.White, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.weight(1f))
                Text("Extra Large", color = Color.White, style = MaterialTheme.typography.labelSmall)
            }
            Slider(value = value, onValueChange = { value = it }, valueRange = 0f..1f)
            Row {
                TextButton(onClick = onDone) { Text("Skip") }
                Spacer(Modifier.weight(1f))
                Button(onClick = { c.settings.setCalibrated(value); onDone() }) { Text("Save") }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

/** Procedurally drawn sample panels (no copyrighted artwork is bundled). */
object CalibrationSamples {
    class Sample(val name: String, val layout: PageLayout, val panel: Panel, val bitmap: Bitmap)

    private val PAGE = SizeF(1600f, 2400f)
    private const val K = 0.5f // bitmap resolution relative to source pixels

    fun build(): List<Sample> = listOf(
        make("Small dialogue", RectF(100f, 100f, 800f, 600f), listOf(Bub(450f, 80f, 130f, 300f, 26f, "そうか…ありがとう")), seed = 1),
        make("Large dialogue", RectF(100f, 100f, 1500f, 1000f), listOf(Bub(950f, 60f, 300f, 600f, 46f, "絶対にあきらめない！"), Bub(250f, 420f, 220f, 420f, 40f, "行くぞ")), seed = 2),
        make("Tall artwork", RectF(500f, 50f, 1100f, 2350f), listOf(Bub(300f, 100f, 200f, 420f, 30f, "ここはどこだ"), Bub(80f, 1700f, 200f, 420f, 30f, "下を見ろ")), seed = 3),
        make("Wide artwork", RectF(50f, 200f, 1550f, 800f), listOf(Bub(1200f, 60f, 200f, 420f, 30f, "遠いな…"), Bub(150f, 120f, 180f, 360f, 30f, "急げ")), seed = 4),
        make("Detailed illustration", RectF(100f, 100f, 1500f, 1500f), listOf(Bub(1100f, 80f, 160f, 300f, 24f, "静かだ")), seed = 5, detail = true),
    )

    private class Bub(val x: Float, val y: Float, val w: Float, val h: Float, val textSize: Float, val text: String)

    private fun make(name: String, panelRect: RectF, bubbles: List<Bub>, seed: Int, detail: Boolean = false): Sample {
        val w = (panelRect.width * K).toInt()
        val h = (panelRect.height * K).toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = android.graphics.Canvas(bmp)
        cv.drawColor(android.graphics.Color.WHITE)
        val rnd = Random(seed)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.BLACK }
        // Artwork: strokes, hatching and screentone.
        repeat(if (detail) 220 else 40) {
            line.strokeWidth = rnd.nextFloat() * 3f + 0.6f
            line.color = android.graphics.Color.rgb(rnd.nextInt(90), rnd.nextInt(90), rnd.nextInt(90))
            cv.drawLine(rnd.nextFloat() * w, rnd.nextFloat() * h, rnd.nextFloat() * w, rnd.nextFloat() * h, line)
        }
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.GRAY }
        val tx = rnd.nextFloat() * w * 0.5f
        val ty = rnd.nextFloat() * h * 0.5f
        var yy = ty
        while (yy < ty + h * 0.3f) { var xx = tx; while (xx < tx + w * 0.4f) { cv.drawCircle(xx, yy, 1.2f, dot); xx += 5f }; yy += 5f }
        if (detail) {
            line.strokeWidth = 0.8f
            var i = 0f
            while (i < w + h) { cv.drawLine(i, 0f, i - h, h.toFloat(), line); i += 9f }
        }
        // Speech bubbles with vertical Japanese text at realistic manga sizes.
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE }
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f; color = android.graphics.Color.BLACK }
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; typeface = Typeface.DEFAULT_BOLD }
        val bubbleRects = ArrayList<RectF>()
        for (b in bubbles) {
            val r = android.graphics.RectF(b.x * K, b.y * K, (b.x + b.w) * K, (b.y + b.h) * K)
            cv.drawOval(r, fill); cv.drawOval(r, outline)
            text.textSize = b.textSize * K
            val step = b.textSize * K * 1.1f
            val cols = b.text.chunked(((b.h * 0.7f * K) / step).toInt().coerceAtLeast(1))
            var colX = r.centerX() + (cols.size - 1) * step / 2f
            for (col in cols) {
                var cy = r.top + (r.height() - col.length * step) / 2f + step
                for (ch in col) { cv.drawText(ch.toString(), colX - text.textSize / 2f, cy, text); cy += step }
                colX -= step
            }
            bubbleRects += RectF(panelRect.left + b.x, panelRect.top + b.y, panelRect.left + b.x + b.w, panelRect.top + b.y + b.h)
        }
        line.strokeWidth = 5f; line.color = android.graphics.Color.BLACK
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), line)
        val panel = Panel(0, panelRect, safeBounds = panelRect, bubbles = bubbleRects)
        val layout = PageLayout(PAGE, listOf(panel), PageKind.MULTI_PANEL, LayoutConfidence.CERTAIN, ReadingDirection.RIGHT_TO_LEFT, 0)
        return Sample(name, layout, panel, bmp)
    }
}
