package com.mangaflow.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.mangaflow.engine.layout.LowConfidenceFallback
import com.mangaflow.engine.learning.PreferenceLearner
import com.mangaflow.engine.model.ReadingDirection
import com.mangaflow.engine.settings.ReaderSettings
import com.mangaflow.engine.settings.ReadingSizePreset
import com.mangaflow.engine.settings.RevealMode
import com.mangaflow.engine.settings.TransitionSpeed
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private val Context.dataStore by preferencesDataStore(name = "settings")

/** Global "Intelligent Reading" settings + on-device learned preferences. Persisted locally only. */
class SettingsRepository(private val context: Context, private val scope: CoroutineScope) {

    private object K {
        val detection = booleanPreferencesKey("intelligent_detection")
        val direction = stringPreferencesKey("direction")
        val autoZoom = booleanPreferencesKey("auto_zoom")
        val sizePreset = stringPreferencesKey("size_preset")
        val customSize = floatPreferencesKey("custom_size")
        val reveal = stringPreferencesKey("reveal_mode")
        val showComplete = booleanPreferencesKey("show_complete")
        val bubbles = booleanPreferencesKey("bubble_protection")
        val transition = stringPreferencesKey("transition")
        val learn = booleanPreferencesKey("learn")
        val manual = booleanPreferencesKey("manual_corrections")
        val fallback = stringPreferencesKey("fallback")
        val reducedMotion = booleanPreferencesKey("reduced_motion")
        val calibrated = booleanPreferencesKey("calibrated")
        val learned = stringPreferencesKey("learned_stats")
    }

    val settings: Flow<ReaderSettings> = context.dataStore.data.map { it.toSettings() }
    val calibrated: Flow<Boolean> = context.dataStore.data.map { it[K.calibrated] ?: false }

    /** Single shared learner; its statistics are persisted after every accepted observation. */
    val learner = PreferenceLearner()

    suspend fun init() {
        learner.restore(context.dataStore.data.first()[K.learned])
    }

    private inline fun <reified T : Enum<T>> Preferences.enum(key: Preferences.Key<String>, default: T): T =
        this[key]?.let { v -> runCatching { enumValueOf<T>(v) }.getOrNull() } ?: default

    private fun Preferences.toSettings(): ReaderSettings {
        val d = ReaderSettings()
        return ReaderSettings(
            intelligentDetection = this[K.detection] ?: d.intelligentDetection,
            direction = enum(K.direction, d.direction),
            automaticPanelZoom = this[K.autoZoom] ?: d.automaticPanelZoom,
            sizePreset = enum(K.sizePreset, d.sizePreset),
            customSize = this[K.customSize] ?: d.customSize,
            revealMode = enum(K.reveal, d.revealMode),
            showCompletePanelAfterReveal = this[K.showComplete] ?: d.showCompletePanelAfterReveal,
            speechBubbleProtection = this[K.bubbles] ?: d.speechBubbleProtection,
            transition = enum(K.transition, d.transition),
            learnPreferences = this[K.learn] ?: d.learnPreferences,
            manualCorrections = this[K.manual] ?: d.manualCorrections,
            lowConfidenceFallback = enum(K.fallback, d.lowConfidenceFallback),
            reducedMotion = this[K.reducedMotion] ?: d.reducedMotion,
        )
    }

    fun update(transform: (ReaderSettings) -> ReaderSettings) {
        scope.launch {
            context.dataStore.edit { p ->
                val s = transform(p.toSettings())
                p[K.detection] = s.intelligentDetection
                p[K.direction] = s.direction.name
                p[K.autoZoom] = s.automaticPanelZoom
                p[K.sizePreset] = s.sizePreset.name
                p[K.customSize] = s.customSize
                p[K.reveal] = s.revealMode.name
                p[K.showComplete] = s.showCompletePanelAfterReveal
                p[K.bubbles] = s.speechBubbleProtection
                p[K.transition] = s.transition.name
                p[K.learn] = s.learnPreferences
                p[K.manual] = s.manualCorrections
                p[K.fallback] = s.lowConfidenceFallback.name
                p[K.reducedMotion] = s.reducedMotion
            }
        }
    }

    fun setCalibrated(size: Float) {
        val preset = ReadingSizePreset.entries.firstOrNull { it != ReadingSizePreset.CUSTOM && kotlin.math.abs(it.value - size) < 0.02f }
        update { it.copy(sizePreset = preset ?: ReadingSizePreset.CUSTOM, customSize = size) }
        scope.launch { context.dataStore.edit { it[K.calibrated] = true } }
    }

    /** Marks onboarding as done without changing the reading size (used by "Skip"). */
    fun setCalibratedIfUnset() {
        scope.launch { context.dataStore.edit { it[K.calibrated] = true } }
    }

    fun persistLearner() {
        scope.launch { context.dataStore.edit { it[K.learned] = learner.serialize() } }
    }

    fun resetLearner() {
        learner.reset()
        persistLearner()
    }
}
