package com.mangaflow.detection

import android.util.Log
import com.mangaflow.data.Codecs
import com.mangaflow.data.RawDetection
import com.mangaflow.data.db.AppDatabase
import com.mangaflow.data.db.PageAnalysisEntity
import com.mangaflow.data.db.PageCorrectionEntity
import com.mangaflow.data.source.PageSource
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.layout.AssemblerConfig
import com.mangaflow.engine.layout.LayoutAssembler
import com.mangaflow.engine.layout.PageCorrection
import com.mangaflow.engine.model.PageLayout
import com.mangaflow.engine.settings.ReaderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Orchestrates the hybrid pipeline for one page:
 *   manual correction (always wins) → versioned cache → OpenCV (A, B) + ML (C) → assembler (D–F).
 *
 * Expensive work runs on a single background lane so detection never competes with itself for
 * memory and never touches the main thread. If the ML model is absent or fails, the classical
 * result is used alone; if everything fails, the page falls back to full-page viewing.
 */
class DetectionService(
    private val db: AppDatabase,
    val ml: MlPanelDetector,
) {
    private val classical = ClassicalPanelDetector()
    private val assembler = LayoutAssembler(CV_VERSION)

    @OptIn(ExperimentalCoroutinesApi::class)
    private val lane = Dispatchers.Default.limitedParallelism(1)
    private val inFlight = HashMap<String, Mutex>()

    /** Cache key: classical-detector version + ML model identity. Changing either invalidates. */
    val detectorId: String get() = "cv$CV_VERSION+ml:${ml.modelId}"

    suspend fun layoutFor(fingerprint: String, source: PageSource, page: Int, settings: ReaderSettings): PageLayout {
        val size = withContext(Dispatchers.IO) { source.pageSize(page) }

        if (settings.manualCorrections) {
            db.corrections().get(fingerprint, page)?.let {
                return Codecs.decodeCorrection(it.correctionJson).toLayout(size, settings.direction, CV_VERSION)
            }
        }
        if (!settings.intelligentDetection) return PageLayout.fullPage(size, settings.direction, CV_VERSION)

        val raw = rawFor(fingerprint, source, page, size) ?: return PageLayout.fullPage(size, settings.direction, CV_VERSION, "detection failed")
        val layout = assembler.assemble(
            raw.pageSize, raw.contentBounds, raw.classical, raw.ml, raw.bubbles,
            AssemblerConfig(
                direction = settings.direction,
                fallback = settings.lowConfidenceFallback,
                speechBubbleProtection = settings.speechBubbleProtection,
            ),
        )
        return layout.copy(diagnostics = layout.diagnostics + "ml: ${raw.mlStatus}")
    }

    private suspend fun rawFor(fp: String, source: PageSource, page: Int, size: SizeF): RawDetection? {
        val key = "$fp/$page"
        val mutex = synchronized(inFlight) { inFlight.getOrPut(key) { Mutex() } }
        return mutex.withLock {
            val cached = db.analysis().get(fp, page)
            if (cached != null && cached.detectorId == detectorId) {
                return@withLock runCatching { Codecs.decodeRaw(cached.rawJson) }.getOrNull()
            }
            val started = System.nanoTime()
            val raw = withContext(lane) { runCatching { analyze(source, page, size) }.onFailure { Log.e(TAG, "detect $key", it) }.getOrNull() }
                ?: return@withLock null
            val ms = (System.nanoTime() - started) / 1_000_000
            db.analysis().put(PageAnalysisEntity(fp, page, size.width, size.height, detectorId, Codecs.encode(raw), null, System.currentTimeMillis(), ms))
            raw
        }.also { synchronized(inFlight) { inFlight.remove(key) } }
    }

    private fun analyze(source: PageSource, page: Int, size: SizeF): RawDetection {
        val bmp = source.decodeScaled(page, ANALYSIS_LONG_SIDE) ?: error("decode failed")
        try {
            val img = classical.preprocess(bmp, size.width, size.height)
            val cv = try { classical.detect(img) } finally { img.release() }
            val mlCands = if (ml.isAvailable) {
                runCatching { ml.detect(bmp, size.width, size.height) }
                    .onFailure { Log.w(TAG, "ML inference failed; classical only", it) }
                    .getOrDefault(emptyList())
            } else emptyList()
            return RawDetection(size, cv.contentBounds, cv.panels, mlCands, cv.bubbles, ml.status)
        } finally {
            bmp.recycle()
        }
    }

    /** Saves the assembled layout next to the raw result (geometry, sequence and confidences). */
    suspend fun rememberLayout(fp: String, page: Int, layout: PageLayout) {
        val e = db.analysis().get(fp, page) ?: return
        db.analysis().put(e.copy(layoutJson = Codecs.encode(layout)))
    }

    suspend fun saveCorrection(fp: String, page: Int, c: PageCorrection) =
        db.corrections().put(PageCorrectionEntity(fp, page, Codecs.encode(c), System.currentTimeMillis()))

    suspend fun clearCorrection(fp: String, page: Int) = db.corrections().delete(fp, page)

    suspend fun hasCorrection(fp: String, page: Int) = db.corrections().get(fp, page) != null

    /** Drops automatic results from other detector versions; corrections are untouched. */
    suspend fun pruneStaleCache() = db.analysis().invalidateOtherThan(detectorId)

    suspend fun averageDetectMillis(): Double? = db.analysis().averageMillis(detectorId)

    companion object {
        const val CV_VERSION = 3
        const val ANALYSIS_LONG_SIDE = 1200
        private const val TAG = "Detection"
    }
}
