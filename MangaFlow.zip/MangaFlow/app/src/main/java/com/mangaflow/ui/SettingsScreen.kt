package com.mangaflow.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mangaflow.AppContainer
import com.mangaflow.engine.layout.LowConfidenceFallback
import com.mangaflow.engine.model.ReadingDirection
import com.mangaflow.engine.settings.ReaderSettings
import com.mangaflow.engine.settings.ReadingSizePreset
import com.mangaflow.engine.settings.RevealMode
import com.mangaflow.engine.settings.TransitionSpeed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(c: AppContainer, onBack: () -> Unit, onCalibrate: () -> Unit) {
    val s by c.settings.settings.collectAsState(initial = ReaderSettings())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var modelStatus by remember { mutableStateOf(c.ml.status) }
    val avgMs by produceState<Double?>(null, modelStatus) { value = c.detection.averageDetectMillis() }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { c.ml.installUserModel(it.readBytes()) }
            }
            modelStatus = c.ml.status
            c.detection.pruneStaleCache()
        }
    }

    fun set(f: (ReaderSettings) -> ReaderSettings) = c.settings.update(f)

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Intelligent Reading") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            SwitchRow("Intelligent panel detection", "Detect panels and read panel by panel", s.intelligentDetection) { v -> set { it.copy(intelligentDetection = v) } }
            ChoiceRow("Reading direction", ReadingDirection.entries, s.direction, { it.label() }) { v -> set { it.copy(direction = v) } }
            SwitchRow("Automatic panel zoom", "Frame each panel at your reading size", s.automaticPanelZoom) { v -> set { it.copy(automaticPanelZoom = v) } }

            ChoiceRow("Preferred reading size", ReadingSizePreset.entries, s.sizePreset, { it.label() }) { v -> set { it.copy(sizePreset = v) } }
            OutlinedButton(onClick = onCalibrate) { Text("Choose your reading comfort…") }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            ChoiceRow("Cinematic panel reveal", RevealMode.entries, s.revealMode, { it.label() }) { v -> set { it.copy(revealMode = v) } }
            SwitchRow("Show complete panel after reveal", null, s.showCompletePanelAfterReveal) { v -> set { it.copy(showCompletePanelAfterReveal = v) } }
            SwitchRow("Speech bubble protection", "Never crop dialogue; expand framing to whole bubbles", s.speechBubbleProtection) { v -> set { it.copy(speechBubbleProtection = v) } }
            ChoiceRow("Smooth camera transitions", TransitionSpeed.entries, s.transition, { it.label() }) { v -> set { it.copy(transition = v) } }
            SwitchRow("Reduce motion", "Jump between panels without animation", s.reducedMotion) { v -> set { it.copy(reducedMotion = v) } }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            SwitchRow("Learn my reading preferences", "Uses your deliberate zoom and skip choices. Stored only on this device.", s.learnPreferences) { v -> set { it.copy(learnPreferences = v) } }
            TextButton(onClick = { c.settings.resetLearner() }) { Text("Reset learned preferences") }
            SwitchRow("Manual panel corrections", "Allow editing panels; your edits always take priority", s.manualCorrections) { v -> set { it.copy(manualCorrections = v) } }
            ChoiceRow("Low-confidence detection fallback", LowConfidenceFallback.entries, s.lowConfidenceFallback, { it.label() }) { v -> set { it.copy(lowConfidenceFallback = v) } }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Panel detection engine", style = MaterialTheme.typography.titleSmall)
            Text(
                "OpenCV detector: ${if (c.openCvReady) "ready" else "unavailable on this device (full-page reading)"}\n" +
                    "ML model: $modelStatus\n" +
                    (avgMs?.let { "Average detection time: ${it.toInt()} ms/page" } ?: ""),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(vertical = 6.dp),
            )
            Row {
                OutlinedButton(onClick = { modelPicker.launch(arrayOf("*/*")) }) { Text("Import .onnx model") }
                if (c.ml.userModelFile.exists()) {
                    TextButton(onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { c.ml.removeUserModel() }
                            modelStatus = c.ml.status
                            c.detection.pruneStaleCache()
                        }
                    }) { Text("Remove") }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}
