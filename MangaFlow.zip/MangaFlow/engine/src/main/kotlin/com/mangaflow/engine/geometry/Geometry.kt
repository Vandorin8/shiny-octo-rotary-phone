package com.mangaflow.engine.geometry

import kotlin.math.max
import kotlin.math.min

/** Integer-free size in source-image pixels. */
data class SizeF(val width: Float, val height: Float) {
    init {
        require(width > 0f && height > 0f) { "Size must be positive: $width x $height" }
    }
    val aspect: Float get() = width / height
    val area: Float get() = width * height
    fun toRect(): RectF = RectF(0f, 0f, width, height)
}

data class PointF(val x: Float, val y: Float)

/**
 * Axis-aligned rectangle in source-image pixel coordinates.
 * Every subsystem (detection, zoom, reveal, animation) uses this single coordinate system.
 */
data class RectF(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val area: Float get() = if (isEmpty) 0f else width * height
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
    val isEmpty: Boolean get() = right <= left || bottom <= top
    val aspect: Float get() = if (height <= 0f) 0f else width / height

    fun intersect(o: RectF): RectF? {
        val l = max(left, o.left)
        val t = max(top, o.top)
        val r = min(right, o.right)
        val b = min(bottom, o.bottom)
        return if (r > l && b > t) RectF(l, t, r, b) else null
    }

    fun intersectionArea(o: RectF): Float = intersect(o)?.area ?: 0f

    fun union(o: RectF): RectF =
        RectF(min(left, o.left), min(top, o.top), max(right, o.right), max(bottom, o.bottom))

    fun iou(o: RectF): Float {
        val inter = intersectionArea(o)
        if (inter <= 0f) return 0f
        return inter / (area + o.area - inter)
    }

    /** Fraction of THIS rectangle that lies inside [o]. */
    fun fractionInside(o: RectF): Float = if (area <= 0f) 0f else intersectionArea(o) / area

    fun contains(o: RectF, tolerance: Float = 0f): Boolean =
        o.left >= left - tolerance && o.top >= top - tolerance &&
            o.right <= right + tolerance && o.bottom <= bottom + tolerance

    fun contains(x: Float, y: Float): Boolean = x in left..right && y in top..bottom

    fun expand(dx: Float, dy: Float = dx): RectF = RectF(left - dx, top - dy, right + dx, bottom + dy)

    fun clampTo(bounds: RectF): RectF = RectF(
        left.coerceIn(bounds.left, bounds.right),
        top.coerceIn(bounds.top, bounds.bottom),
        right.coerceIn(bounds.left, bounds.right),
        bottom.coerceIn(bounds.top, bounds.bottom),
    )

    fun translate(dx: Float, dy: Float): RectF = RectF(left + dx, top + dy, right + dx, bottom + dy)

    /** Moves (without resizing) so the rect lies within [bounds] where possible. */
    fun shiftInto(bounds: RectF): RectF {
        var dx = 0f
        var dy = 0f
        if (width <= bounds.width) {
            if (left < bounds.left) dx = bounds.left - left
            if (right > bounds.right) dx = bounds.right - right
        } else {
            dx = bounds.centerX - centerX
        }
        if (height <= bounds.height) {
            if (top < bounds.top) dy = bounds.top - top
            if (bottom > bounds.bottom) dy = bounds.bottom - bottom
        } else {
            dy = bounds.centerY - centerY
        }
        return translate(dx, dy)
    }

    fun normalized(page: SizeF): RectF =
        RectF(left / page.width, top / page.height, right / page.width, bottom / page.height)

    fun denormalized(page: SizeF): RectF =
        RectF(left * page.width, top * page.height, right * page.width, bottom * page.height)

    fun scaled(sx: Float, sy: Float = sx): RectF = RectF(left * sx, top * sy, right * sx, bottom * sy)

    companion object {
        fun fromCenter(cx: Float, cy: Float, w: Float, h: Float) =
            RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)

        fun bounding(points: List<PointF>): RectF {
            require(points.isNotEmpty())
            return RectF(points.minOf { it.x }, points.minOf { it.y }, points.maxOf { it.x }, points.maxOf { it.y })
        }

        fun unionAll(rects: List<RectF>): RectF? = rects.reduceOrNull { a, b -> a.union(b) }
    }
}

/** Closed polygon in source pixels. Used for irregular / diagonal panels. */
data class Polygon(val points: List<PointF>) {
    val bounds: RectF get() = RectF.bounding(points)

    /** Shoelace area. */
    val area: Float
        get() {
            if (points.size < 3) return 0f
            var s = 0.0
            for (i in points.indices) {
                val a = points[i]
                val b = points[(i + 1) % points.size]
                s += a.x.toDouble() * b.y - b.x.toDouble() * a.y
            }
            return (kotlin.math.abs(s) / 2.0).toFloat()
        }

    /** How rectangular the shape is (1.0 = perfect axis-aligned rectangle). */
    val rectangularity: Float get() = bounds.area.let { if (it <= 0f) 0f else area / it }

    fun scaled(sx: Float, sy: Float = sx) = Polygon(points.map { PointF(it.x * sx, it.y * sy) })
}

/** Union area of a set of rectangles (exact, via coordinate compression). */
fun unionArea(rects: List<RectF>): Float {
    val rs = rects.filter { !it.isEmpty }
    if (rs.isEmpty()) return 0f
    val xs = rs.flatMap { listOf(it.left, it.right) }.distinct().sorted()
    var total = 0.0
    for (i in 0 until xs.size - 1) {
        val x0 = xs[i]
        val x1 = xs[i + 1]
        val spans = rs.filter { it.left <= x0 && it.right >= x1 }.map { it.top to it.bottom }.sortedBy { it.first }
        var covered = 0.0
        var curStart = Float.NaN
        var curEnd = Float.NaN
        for ((s, e) in spans) {
            if (curStart.isNaN()) { curStart = s; curEnd = e; continue }
            if (s <= curEnd) curEnd = max(curEnd, e) else {
                covered += curEnd - curStart
                curStart = s; curEnd = e
            }
        }
        if (!curStart.isNaN()) covered += curEnd - curStart
        total += covered * (x1 - x0)
    }
    return total.toFloat()
}
