package com.mangaflow.engine.layout

import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.model.LayoutConfidence
import com.mangaflow.engine.model.PageKind
import com.mangaflow.engine.model.PageLayout
import com.mangaflow.engine.model.Panel
import com.mangaflow.engine.model.ReadingDirection
import com.mangaflow.engine.model.RevealOverride

/** A user-edited panel, stored normalized (0..1) so it is independent of decode resolution. */
data class EditedPanel(
    val bounds: RectF,
    val safeBounds: RectF = bounds,
    val reveal: RevealOverride = RevealOverride.DEFAULT,
    /** Extra dialogue-safe margin, normalized to the page's short side. */
    val margin: Float = 0f,
)

/** Persisted manual correction for one page. Overrides automatic detection entirely. */
data class PageCorrection(
    val panels: List<EditedPanel>,
    val fullPage: Boolean = false,
) {
    fun toLayout(page: SizeF, direction: ReadingDirection, detectorVersion: Int): PageLayout {
        if (fullPage || panels.isEmpty()) {
            return PageLayout.fullPage(page, direction, detectorVersion, "marked full-page by user").copy(manual = true)
        }
        val short = minOf(page.width, page.height)
        val ps = panels.mapIndexed { i, e ->
            val b = e.bounds.denormalized(page)
            Panel(
                id = i,
                bounds = b,
                safeBounds = e.safeBounds.denormalized(page).union(b),
                confidence = 1f,
                revealOverride = e.reveal,
                extraMargin = e.margin * short,
            )
        }
        return PageLayout(page, ps, PageKind.MULTI_PANEL, LayoutConfidence.CERTAIN, direction, detectorVersion, manual = true)
    }

    companion object {
        fun fromLayout(layout: PageLayout): PageCorrection = PageCorrection(
            panels = layout.panels.map {
                EditedPanel(
                    it.bounds.normalized(layout.pageSize),
                    it.safeBounds.normalized(layout.pageSize),
                    it.revealOverride,
                    it.extraMargin / minOf(layout.pageSize.width, layout.pageSize.height),
                )
            },
            fullPage = layout.kind == PageKind.FULL_PAGE,
        )
    }
}

/** Pure editing operations used by the panel editor (all coordinates normalized). */
object PanelEdits {
    fun add(c: PageCorrection, rect: RectF): PageCorrection =
        c.copy(panels = c.panels + EditedPanel(rect.normalizedRect()), fullPage = false)

    fun remove(c: PageCorrection, index: Int): PageCorrection =
        c.copy(panels = c.panels.filterIndexed { i, _ -> i != index })

    fun resize(c: PageCorrection, index: Int, rect: RectF): PageCorrection = c.copy(
        panels = c.panels.mapIndexed { i, p ->
            if (i != index) p else {
                val r = rect.normalizedRect()
                // Keep safe region at least as large as the panel.
                p.copy(bounds = r, safeBounds = p.safeBounds.union(r).intersect(RectF(0f, 0f, 1f, 1f)) ?: r)
            }
        },
    )

    fun move(c: PageCorrection, from: Int, to: Int): PageCorrection {
        val l = c.panels.toMutableList()
        val p = l.removeAt(from)
        l.add(to.coerceIn(0, l.size), p)
        return c.copy(panels = l)
    }

    /** Combines panels into one region placed at the earliest reading position. */
    fun merge(c: PageCorrection, indices: Set<Int>): PageCorrection {
        if (indices.size < 2) return c
        val members = indices.sorted().map { c.panels[it] }
        val merged = EditedPanel(
            bounds = RectF.unionAll(members.map { it.bounds })!!,
            safeBounds = RectF.unionAll(members.map { it.safeBounds })!!,
            reveal = members.first().reveal,
            margin = members.maxOf { it.margin },
        )
        val first = indices.min()
        val l = c.panels.filterIndexed { i, _ -> i !in indices }.toMutableList()
        l.add(first.coerceAtMost(l.size), merged)
        return c.copy(panels = l)
    }

    /**
     * Splits a panel at [fraction] along one axis. For a vertical cut in right-to-left reading
     * the right half comes first.
     */
    fun split(c: PageCorrection, index: Int, vertical: Boolean, fraction: Float, direction: ReadingDirection): PageCorrection {
        val p = c.panels[index]
        val b = p.bounds
        val f = fraction.coerceIn(0.1f, 0.9f)
        val (a, z) = if (vertical) {
            val x = b.left + b.width * f
            val left = RectF(b.left, b.top, x, b.bottom)
            val right = RectF(x, b.top, b.right, b.bottom)
            if (direction == ReadingDirection.RIGHT_TO_LEFT) right to left else left to right
        } else {
            val y = b.top + b.height * f
            RectF(b.left, b.top, b.right, y) to RectF(b.left, y, b.right, b.bottom)
        }
        val l = c.panels.toMutableList()
        l[index] = EditedPanel(a, a, p.reveal, p.margin)
        l.add(index + 1, EditedPanel(z, z, p.reveal, p.margin))
        return c.copy(panels = l)
    }

    fun setMargin(c: PageCorrection, index: Int, margin: Float) =
        c.copy(panels = c.panels.mapIndexed { i, p -> if (i == index) p.copy(margin = margin.coerceIn(0f, 0.2f)) else p })

    fun setReveal(c: PageCorrection, index: Int, reveal: RevealOverride) =
        c.copy(panels = c.panels.mapIndexed { i, p -> if (i == index) p.copy(reveal = reveal) else p })

    fun markFullPage(c: PageCorrection, fullPage: Boolean) = c.copy(fullPage = fullPage)

    private fun RectF.normalizedRect(): RectF {
        val l = minOf(left, right).coerceIn(0f, 1f)
        val r = maxOf(left, right).coerceIn(0f, 1f)
        val t = minOf(top, bottom).coerceIn(0f, 1f)
        val b = maxOf(top, bottom).coerceIn(0f, 1f)
        return RectF(l, t, r, b)
    }
}
