package com.mangaflow.engine.camera

import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.model.PageKind
import com.mangaflow.engine.model.PageLayout
import com.mangaflow.engine.model.Panel
import com.mangaflow.engine.model.RevealOverride
import com.mangaflow.engine.settings.ReaderSettings
import com.mangaflow.engine.settings.RevealMode
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

enum class PanelClass { SMALL, TALL, WIDE, LARGE, BORDERLESS, FULL_PAGE }

enum class FramingStrategy { FIT_WHOLE, PROGRESSIVE_REVEAL }

data class Framing(
    /** Safe content region the camera must respect. */
    val content: RectF,
    /** Scale that shows the whole content region. */
    val fitScale: Float,
    /** Scale the user's comfort preference asks for on this page. */
    val desiredScale: Float,
    /** Scale actually used for the panel (FIT) or for reveal steps (REVEAL). */
    val scale: Float,
    val panelClass: PanelClass,
    val strategy: FramingStrategy,
)

/** Learned adjustments supplied by [PreferenceLearner]. */
interface LearnedBias {
    /** Multiplicative zoom bias in log space for a panel class (0 = none). */
    fun logZoomBias(panelClass: PanelClass): Float = 0f
    fun suppressReveal(panelClass: PanelClass): Boolean = false

    object None : LearnedBias
}

/**
 * Section 2: personalised automatic zoom.
 *
 * The reading-size preference (0..1) is interpreted as "how much of a page's width should span
 * the screen's short side" — a physical readability target that stays consistent across phones
 * and orientations — and is then adapted per panel using its size, its dialogue and the image
 * resolution. It is never applied as a single fixed multiplier.
 */
class ZoomEngine(
    /** Maximum on-screen magnification of source pixels before the image visibly softens. */
    private val maxSourceMagnification: Float = 3.0f,
) {

    fun desiredScale(layout: PageLayout, vp: Viewport, readingSize: Float): Float {
        // Compact ≈ 95 % of the page width across the short side; Extra Large ≈ 42 %.
        val visibleFraction = lerp(0.95f, 0.42f, readingSize.coerceIn(0f, 1f))
        return vp.shortSide / (layout.pageSize.width * visibleFraction)
    }

    fun frame(
        panel: Panel,
        layout: PageLayout,
        vp: Viewport,
        settings: ReaderSettings,
        bias: LearnedBias = LearnedBias.None,
    ): Framing {
        val page = layout.pageSize.toRect()
        val breathing = min(panel.safeBounds.width, panel.safeBounds.height) * 0.015f
        val content = panel.safeBounds.expand(breathing + panel.extraMargin).clampTo(page)
        val fitScale = min(vp.width / content.width, vp.height / content.height)

        val size = settings.readingSize
        var desired = desiredScale(layout, vp, size)

        // Dialogue readability: bubbles should reach a minimum on-screen size.
        if (panel.bubbles.isNotEmpty()) {
            val sizes = panel.bubbles.map { min(it.width, it.height) }.sorted()
            val median = sizes[sizes.size / 2]
            val minBubblePx = vp.shortSide * lerp(0.15f, 0.30f, size)
            val textScale = minBubblePx / median
            desired = max(desired, min(textScale, desired * 1.35f))
        }

        val isFullPage = layout.kind == PageKind.FULL_PAGE ||
            content.area >= layout.pageSize.area * 0.8f
        val cls = classify(panel, content, fitScale, desired, vp, isFullPage)
        desired *= exp(bias.logZoomBias(cls))

        val resolutionCap = maxSourceMagnification
        if (!settings.automaticPanelZoom) {
            return Framing(content, fitScale, desired, min(fitScale, resolutionCap), cls, FramingStrategy.FIT_WHOLE)
        }

        val ratio = desired / fitScale
        val revealWanted = when {
            panel.revealOverride == RevealOverride.NEVER -> false
            panel.revealOverride == RevealOverride.ALWAYS -> ratio > 1.02f
            settings.revealMode == RevealMode.OFF -> false
            isFullPage -> false // splash pages stay whole unless explicitly requested per panel
            bias.suppressReveal(cls) -> false
            panel.confidence < 0.4f -> false
            settings.revealMode == RevealMode.AUTOMATIC -> ratio >= 1.30f
            else -> ratio >= 1.08f
        }

        if (!revealWanted) {
            val enlargeCap = desired * lerp(1.4f, 2.0f, size)
            val scale = min(fitScale, min(enlargeCap, resolutionCap))
            return Framing(content, fitScale, desired, scale, cls, FramingStrategy.FIT_WHOLE)
        }

        // Progressive reveal: use the preferred scale, but never so large that a bubble is cut.
        var scale = min(desired, resolutionCap)
        for (b in panel.bubbles) {
            scale = min(scale, 0.94f * min(vp.width / b.width, vp.height / b.height))
        }
        if (scale <= fitScale * 1.05f) {
            return Framing(content, fitScale, desired, fitScale, cls, FramingStrategy.FIT_WHOLE)
        }
        return Framing(content, fitScale, desired, scale, cls, FramingStrategy.PROGRESSIVE_REVEAL)
    }

    private fun classify(panel: Panel, content: RectF, fit: Float, desired: Float, vp: Viewport, fullPage: Boolean): PanelClass = when {
        fullPage -> PanelClass.FULL_PAGE
        fit >= desired * 1.15f -> PanelClass.SMALL
        panel.borderless -> PanelClass.BORDERLESS
        else -> {
            // Which axis overflows the screen at the preferred scale → which way the camera must travel.
            val overX = content.width * desired / vp.width
            val overY = content.height * desired / vp.height
            when {
                overY > 1f && overY > overX * 1.25f -> PanelClass.TALL
                overX > 1f && overX > overY * 1.25f -> PanelClass.WIDE
                else -> PanelClass.LARGE
            }
        }
    }
}

internal fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
