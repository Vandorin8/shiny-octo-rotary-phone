package com.mangaflow.engine.settings

import com.mangaflow.engine.layout.LowConfidenceFallback
import com.mangaflow.engine.model.ReadingDirection

enum class RevealMode { OFF, AUTOMATIC, ALWAYS_FOR_OVERSIZED }

enum class TransitionSpeed(val millis: Int) { OFF(0), FAST(260), NORMAL(420), SLOW(650) }

/**
 * Reading-size presets. [value] is a continuous comfort preference in 0..1 that the zoom
 * engine adapts per panel; it is NOT a fixed zoom multiplier.
 */
enum class ReadingSizePreset(val value: Float) {
    COMPACT(0.0f), BALANCED(0.35f), LARGE(0.65f), EXTRA_LARGE(1.0f), CUSTOM(-1f);

    companion object {
        fun nearest(v: Float): ReadingSizePreset =
            entries.filter { it != CUSTOM }.minBy { kotlin.math.abs(it.value - v) }
    }
}

/** Global "Intelligent Reading" settings. Defaults match the specification table. */
data class ReaderSettings(
    val intelligentDetection: Boolean = true,
    val direction: ReadingDirection = ReadingDirection.RIGHT_TO_LEFT,
    val automaticPanelZoom: Boolean = true,
    val sizePreset: ReadingSizePreset = ReadingSizePreset.BALANCED,
    /** Used when [sizePreset] is CUSTOM; 0..1. */
    val customSize: Float = 0.35f,
    val revealMode: RevealMode = RevealMode.AUTOMATIC,
    val showCompletePanelAfterReveal: Boolean = true,
    val speechBubbleProtection: Boolean = true,
    val transition: TransitionSpeed = TransitionSpeed.FAST,
    val learnPreferences: Boolean = false,
    val manualCorrections: Boolean = true,
    val lowConfidenceFallback: LowConfidenceFallback = LowConfidenceFallback.FULL_PAGE,
    val reducedMotion: Boolean = false,
) {
    val readingSize: Float get() = if (sizePreset == ReadingSizePreset.CUSTOM) customSize.coerceIn(0f, 1f) else sizePreset.value
}

/** Per-book overrides; null means "inherit global". */
data class BookOverrides(
    val intelligentDetection: Boolean? = null,
    val direction: ReadingDirection? = null,
    val automaticPanelZoom: Boolean? = null,
    val sizePreset: ReadingSizePreset? = null,
    val customSize: Float? = null,
    val revealMode: RevealMode? = null,
    val showCompletePanelAfterReveal: Boolean? = null,
    val speechBubbleProtection: Boolean? = null,
) {
    fun applyTo(g: ReaderSettings): ReaderSettings = g.copy(
        intelligentDetection = intelligentDetection ?: g.intelligentDetection,
        direction = direction ?: g.direction,
        automaticPanelZoom = automaticPanelZoom ?: g.automaticPanelZoom,
        sizePreset = sizePreset ?: g.sizePreset,
        customSize = customSize ?: g.customSize,
        revealMode = revealMode ?: g.revealMode,
        showCompletePanelAfterReveal = showCompletePanelAfterReveal ?: g.showCompletePanelAfterReveal,
        speechBubbleProtection = speechBubbleProtection ?: g.speechBubbleProtection,
    )

    val isEmpty: Boolean get() = this == BookOverrides()
}
