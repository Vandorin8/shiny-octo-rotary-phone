package com.mangaflow.engine.camera

import com.mangaflow.engine.geometry.PointF
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Usable on-screen drawing area in screen pixels. */
data class Viewport(val width: Float, val height: Float) {
    init { require(width > 0 && height > 0) }
    val aspect: Float get() = width / height
    val shortSide: Float get() = min(width, height)
}

/**
 * Camera in source-image coordinates: the source point at the center of the screen and the
 * uniform scale (screen px per source px). Uniform scale means no stretching is possible.
 */
data class CameraState(val centerX: Float, val centerY: Float, val scale: Float) {
    init { require(scale > 0f) { "scale must be > 0" } }

    fun visibleRect(vp: Viewport): RectF = RectF.fromCenter(centerX, centerY, vp.width / scale, vp.height / scale)

    /** Source → screen. */
    fun toScreen(x: Float, y: Float, vp: Viewport): PointF =
        PointF((x - centerX) * scale + vp.width / 2f, (y - centerY) * scale + vp.height / 2f)

    /** Screen → source. */
    fun toSource(sx: Float, sy: Float, vp: Viewport): PointF =
        PointF((sx - vp.width / 2f) / scale + centerX, (sy - vp.height / 2f) / scale + centerY)

    /**
     * Keeps the camera inside the page. When the visible window is larger than the page along
     * an axis the page is centered on that axis instead.
     */
    fun constrainedTo(page: SizeF, vp: Viewport, minScale: Float, maxScale: Float): CameraState {
        val s = scale.coerceIn(minScale, max(minScale, maxScale))
        val halfW = vp.width / s / 2f
        val halfH = vp.height / s / 2f
        val cx = if (halfW * 2 >= page.width) page.width / 2f else centerX.coerceIn(halfW, page.width - halfW)
        val cy = if (halfH * 2 >= page.height) page.height / 2f else centerY.coerceIn(halfH, page.height - halfH)
        return CameraState(cx, cy, s)
    }

    companion object {
        /** Frames [rect] entirely in the viewport. */
        fun fit(rect: RectF, vp: Viewport): CameraState =
            CameraState(rect.centerX, rect.centerY, min(vp.width / rect.width, vp.height / rect.height))

        /**
         * Interpolates two camera states. Scale is interpolated in log space so zooming feels
         * perceptually linear; the center follows the screen-space path so the motion has no
         * "swing" when zooming and panning together.
         */
        fun lerp(a: CameraState, b: CameraState, t: Float): CameraState {
            val tt = t.coerceIn(0f, 1f)
            val la = ln(a.scale)
            val lb = ln(b.scale)
            val s = exp(la + (lb - la) * tt)
            val w = if (kotlin.math.abs(lb - la) < 1e-4) tt else ((1f / a.scale) - (1f / s)) / ((1f / a.scale) - (1f / b.scale))
            val cx = a.centerX + (b.centerX - a.centerX) * w
            val cy = a.centerY + (b.centerY - a.centerY) * w
            return CameraState(cx, cy, s)
        }
    }
}

/** One stop of the reading camera inside a panel. */
data class CameraStep(
    /** Reading sequence index within the panel. */
    val index: Int,
    val camera: CameraState,
    /** Visible crop boundaries in source pixels. */
    val crop: RectF,
    /** Center and crop normalized to the page (0..1) — portable across screen sizes. */
    val normalizedCenter: PointF,
    val normalizedCrop: RectF,
    /** Indices into Panel.bubbles that are fully visible in this step. */
    val dialogue: List<Int>,
    /** True for the "show the whole panel" step. */
    val overview: Boolean,
)
