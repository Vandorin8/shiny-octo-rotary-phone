package com.mangaflow.engine.camera

import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.model.PageLayout
import com.mangaflow.engine.model.ReadingDirection
import com.mangaflow.engine.settings.ReaderSettings

/** Camera stops for one page: one list of steps per panel, in reading order. */
data class PagePlan(
    val page: Int,
    val panels: List<List<CameraStep>>,
    val framings: List<Framing?>,
    /** True when built before detection finished (whole-page placeholder). */
    val provisional: Boolean,
) {
    init {
        require(panels.isNotEmpty() && panels.all { it.isNotEmpty() }) { "every page needs ≥1 panel with ≥1 step" }
    }
    val lastPanel: Int get() = panels.lastIndex
    fun lastStep(panel: Int): Int = panels[panel].lastIndex
    fun step(pos: ReadingPosition): CameraStep = panels[pos.panel][pos.step]
}

/** Current page, panel and reveal step. [enteredFromEnd] remembers backward entry into a page. */
data class ReadingPosition(val page: Int, val panel: Int, val step: Int, val enteredFromEnd: Boolean = false)

/** Builds [PagePlan]s from layouts using the zoom engine and reveal planner. */
class PlanBuilder(
    private val zoom: ZoomEngine = ZoomEngine(),
    private val reveal: RevealPlanner = RevealPlanner(),
) {
    fun build(page: Int, layout: PageLayout, vp: Viewport, settings: ReaderSettings, bias: LearnedBias = LearnedBias.None): PagePlan {
        val usePanels = settings.intelligentDetection && !layout.lowConfidenceFallback
        if (!usePanels) return fullPage(page, layout.pageSize, vp, provisional = false)
        val framings = layout.panels.map { zoom.frame(it, layout, vp, settings, bias) }
        val steps = layout.panels.mapIndexed { i, p ->
            reveal.plan(p, framings[i], layout.pageSize, vp, layout.direction, settings.showCompletePanelAfterReveal)
        }
        return PagePlan(page, steps, framings, provisional = false)
    }

    fun fullPage(page: Int, size: SizeF, vp: Viewport, provisional: Boolean): PagePlan {
        val layout = PageLayout.fullPage(size, ReadingDirection.RIGHT_TO_LEFT, 0)
        val p = layout.panels[0]
        val cam = CameraState.fit(p.bounds, vp)
        val step = CameraStep(
            0, cam, cam.visibleRect(vp),
            com.mangaflow.engine.geometry.PointF(0.5f, 0.5f), cam.visibleRect(vp).normalized(size), emptyList(), overview = true,
        )
        return PagePlan(page, listOf(listOf(step)), listOf(null), provisional)
    }
}

sealed class NavResult {
    data class Moved(val position: ReadingPosition) : NavResult()
    object StartOfBook : NavResult()
    object EndOfBook : NavResult()
}

/**
 * Deterministic reading-position state machine (section 1.4).
 *
 * Invariants (covered by unit tests):
 *  - forward then backward returns to the same position; never a duplicated stop;
 *  - every panel has ≥ 1 step so the reader can never be trapped;
 *  - the last step of the last panel advances to the first step of the next page.
 */
class ReadingNavigator(
    val pageCount: Int,
    private val plans: (Int) -> PagePlan,
) {
    fun forward(pos: ReadingPosition): NavResult {
        val plan = plans(pos.page)
        val p = clamp(pos, plan)
        return when {
            p.step < plan.lastStep(p.panel) -> NavResult.Moved(p.copy(step = p.step + 1))
            p.panel < plan.lastPanel -> NavResult.Moved(p.copy(panel = p.panel + 1, step = 0))
            p.page + 1 < pageCount -> NavResult.Moved(ReadingPosition(p.page + 1, 0, 0, enteredFromEnd = false))
            else -> NavResult.EndOfBook
        }
    }

    fun backward(pos: ReadingPosition): NavResult {
        val plan = plans(pos.page)
        val p = clamp(pos, plan)
        return when {
            p.step > 0 -> NavResult.Moved(p.copy(step = p.step - 1))
            p.panel > 0 -> NavResult.Moved(p.copy(panel = p.panel - 1, step = plan.lastStep(p.panel - 1)))
            p.page > 0 -> {
                val prev = plans(p.page - 1)
                NavResult.Moved(ReadingPosition(p.page - 1, prev.lastPanel, prev.lastStep(prev.lastPanel), enteredFromEnd = true))
            }
            else -> NavResult.StartOfBook
        }
    }

    /**
     * Re-anchors a position after its page plan changed (detection finished, settings or
     * orientation changed). A position on a provisional placeholder moves to the start or end
     * of the real plan depending on the direction the page was entered from.
     */
    fun reconcile(pos: ReadingPosition, oldPlan: PagePlan?, newPlan: PagePlan): ReadingPosition {
        if (oldPlan == null || oldPlan.provisional) {
            return if (pos.enteredFromEnd) pos.copy(panel = newPlan.lastPanel, step = newPlan.lastStep(newPlan.lastPanel))
            else pos.copy(panel = 0, step = 0)
        }
        val panel = pos.panel.coerceIn(0, newPlan.lastPanel)
        val oldSteps = oldPlan.panels.getOrNull(pos.panel)?.size ?: 1
        val newSteps = newPlan.panels[panel].size
        // Keep relative progress through the panel; overview step maps to overview step.
        val step = when {
            pos.step >= oldSteps - 1 -> newSteps - 1
            oldSteps <= 1 -> 0
            else -> ((pos.step.toFloat() / (oldSteps - 1)) * (newSteps - 1)).toInt().coerceIn(0, newSteps - 1)
        }
        return pos.copy(panel = panel, step = step)
    }

    fun clamp(pos: ReadingPosition, plan: PagePlan = plans(pos.page)): ReadingPosition {
        val panel = pos.panel.coerceIn(0, plan.lastPanel)
        return pos.copy(panel = panel, step = pos.step.coerceIn(0, plan.lastStep(panel)))
    }
}
