package com.mangaflow.engine.layout

import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.model.ReadingDirection
import kotlin.math.max
import kotlin.math.min

/**
 * Stage E: layout graph + reading order.
 *
 * The page is recursively decomposed (recursive XY-cut) into a tree whose internal nodes are
 * ROWS (stacked bands, read top-to-bottom) or COLUMNS (side-by-side groups, read right-to-left
 * for Japanese manga). This mirrors how manga pages are actually composed: a tall panel on the
 * right spanning two stacked panels on the left yields COLUMNS[ tall , ROWS[top, bottom] ],
 * which is read tall -> top -> bottom. A naive sort by (y, x) gets that page wrong.
 *
 * When a group of panels cannot be separated by any gutter (overlaps, diagonal cuts, insets),
 * an AMBIGUOUS node orders them by banded position and lowers the reading-order confidence.
 */
sealed class LayoutNode {
    abstract val bounds: RectF
    data class Leaf(val index: Int, override val bounds: RectF) : LayoutNode()
    data class Rows(val children: List<LayoutNode>, override val bounds: RectF) : LayoutNode()
    data class Columns(val children: List<LayoutNode>, override val bounds: RectF) : LayoutNode()
    data class Ambiguous(val children: List<LayoutNode>, override val bounds: RectF) : LayoutNode()

    fun leaves(): List<Int> = when (this) {
        is Leaf -> listOf(index)
        is Rows -> children.flatMap { it.leaves() }
        is Columns -> children.flatMap { it.leaves() }
        is Ambiguous -> children.flatMap { it.leaves() }
    }
}

data class ReadingOrderResult(
    val order: List<Int>,
    val tree: LayoutNode?,
    val confidence: Float,
    /** Top-level reading bands; used by the "conservative larger crop" fallback. */
    val topLevelGroups: List<List<Int>>,
)

class ReadingOrderAnalyzer(
    /** Allowed overlap across a gutter, as a fraction of the smaller panel's extent. */
    private val overlapTolerance: Float = 0.12f,
) {

    fun analyze(rects: List<RectF>, direction: ReadingDirection): ReadingOrderResult {
        if (rects.isEmpty()) return ReadingOrderResult(emptyList(), null, 1f, emptyList())
        val items = rects.indices.map { LayoutNode.Leaf(it, rects[it]) }
        var ambiguousCount = 0
        val tree = build(items, direction) { ambiguousCount += it }
        val order = tree.leaves()
        val conf = 1f - 0.45f * (ambiguousCount.toFloat() / rects.size)
        val groups = when (tree) {
            is LayoutNode.Rows -> tree.children.map { it.leaves() }
            is LayoutNode.Columns -> tree.children.map { it.leaves() }
            else -> listOf(order)
        }
        return ReadingOrderResult(order, tree, conf.coerceIn(0f, 1f), groups)
    }

    private fun build(items: List<LayoutNode>, dir: ReadingDirection, ambiguous: (Int) -> Unit): LayoutNode {
        if (items.size == 1) return items[0]
        val bounds = RectF.unionAll(items.map { it.bounds })!!

        val rows = splitBands(items, horizontalCut = true)
        if (rows.size > 1) {
            return LayoutNode.Rows(rows.map { build(it, dir, ambiguous) }, bounds)
        }
        val cols = splitBands(items, horizontalCut = false)
        if (cols.size > 1) {
            val ordered = if (dir == ReadingDirection.RIGHT_TO_LEFT) cols.reversed() else cols
            return LayoutNode.Columns(ordered.map { build(it, dir, ambiguous) }, bounds)
        }
        // No clean gutter separates these panels.
        ambiguous(items.size)
        return LayoutNode.Ambiguous(bandedOrder(items, dir), bounds)
    }

    /**
     * Splits items into groups separated by a gutter along one axis.
     * horizontalCut = true → bands stacked vertically (sorted top→bottom).
     * horizontalCut = false → bands side by side (sorted left→right).
     */
    private fun splitBands(items: List<LayoutNode>, horizontalCut: Boolean): List<List<LayoutNode>> {
        fun lo(n: LayoutNode) = if (horizontalCut) n.bounds.top else n.bounds.left
        fun hi(n: LayoutNode) = if (horizontalCut) n.bounds.bottom else n.bounds.right
        val sorted = items.sortedBy { lo(it) }
        val groups = mutableListOf(mutableListOf(sorted[0]))
        var groupHi = hi(sorted[0])
        var groupMinExtent = hi(sorted[0]) - lo(sorted[0])
        for (n in sorted.drop(1)) {
            val extent = hi(n) - lo(n)
            val tol = overlapTolerance * min(groupMinExtent, extent)
            if (lo(n) >= groupHi - tol) {
                groups += mutableListOf(n)
                groupHi = hi(n)
                groupMinExtent = extent
            } else {
                groups.last() += n
                groupHi = max(groupHi, hi(n))
                groupMinExtent = min(groupMinExtent, extent)
            }
        }
        return groups
    }

    /** Fallback ordering: cluster into vertical bands by overlap, then order within each band by direction. */
    private fun bandedOrder(items: List<LayoutNode>, dir: ReadingDirection): List<LayoutNode> {
        val sorted = items.sortedBy { it.bounds.centerY }
        val bands = mutableListOf<MutableList<LayoutNode>>()
        for (n in sorted) {
            val band = bands.lastOrNull()
            if (band != null) {
                val ref = band.last().bounds
                val overlap = min(ref.bottom, n.bounds.bottom) - max(ref.top, n.bounds.top)
                if (overlap > 0.5f * min(ref.height, n.bounds.height)) { band += n; continue }
            }
            bands += mutableListOf(n)
        }
        return bands.flatMap { band ->
            if (dir == ReadingDirection.RIGHT_TO_LEFT) band.sortedByDescending { it.bounds.centerX }
            else band.sortedBy { it.bounds.centerX }
        }
    }
}
