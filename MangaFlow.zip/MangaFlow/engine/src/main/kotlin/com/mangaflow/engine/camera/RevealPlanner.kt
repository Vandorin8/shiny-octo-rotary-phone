package com.mangaflow.engine.camera

import com.mangaflow.engine.geometry.PointF
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.model.Panel
import com.mangaflow.engine.model.ReadingDirection
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Section 1: builds the ordered virtual-camera sequence for one panel.
 *
 * The number of steps is derived from the content size, the window the chosen scale allows and
 * the dialogue positions — never a fixed count. Window boundaries are placed so that every
 * speech bubble is fully visible in at least one step; a dedicated step is inserted as a last
 * resort if geometry makes that impossible otherwise.
 */
class RevealPlanner(
    /** Minimum overlap between consecutive steps to preserve visual context. */
    private val overlap: Float = 0.18f,
) {

    fun plan(
        panel: Panel,
        framing: Framing,
        page: SizeF,
        vp: Viewport,
        direction: ReadingDirection,
        showCompleteAtEnd: Boolean,
    ): List<CameraStep> {
        val content = framing.content
        val overviewCamera = CameraState(content.centerX, content.centerY, framing.fitScale)

        if (framing.strategy == FramingStrategy.FIT_WHOLE) {
            val cam = CameraState(content.centerX, content.centerY, framing.scale)
            return listOf(step(0, cam, vp, page, panel, overview = true))
        }

        val s = framing.scale
        val winW = vp.width / s
        val winH = vp.height / s

        // Axis positions (window top-left), dialogue-aware.
        val ys = axisPositions(content.top, content.bottom, winH, panel.bubbles.map { it.top to it.bottom }, reverse = false)
        val xs = axisPositions(
            content.left, content.right, winW, panel.bubbles.map { it.left to it.right },
            reverse = direction == ReadingDirection.RIGHT_TO_LEFT,
        )

        val windows = mutableListOf<RectF>()
        for (y in ys) for (x in xs) windows += RectF(x, y, x + winW, y + winH)

        // Guarantee: every bubble fully visible in some window.
        val pageRect = page.toRect()
        for (b in panel.bubbles) {
            if (windows.any { it.contains(b, tolerance = 0.5f) }) continue
            val nearest = windows.indices.minBy { dist2(windows[it].centerX, windows[it].centerY, b.centerX, b.centerY) }
            val dedicated = RectF.fromCenter(b.centerX, b.centerY, winW, winH).shiftInto(pageRect)
            windows.add(nearest + 1, dedicated)
        }

        val steps = mutableListOf<CameraStep>()
        for (w in windows) {
            val cam = CameraState(w.centerX, w.centerY, s).constrainedTo(page, vp, s, s)
            val st = step(steps.size, cam, vp, page, panel, overview = false)
            // Drop near-duplicates created by clamping at page edges.
            if (steps.isNotEmpty() && steps.last().crop.iou(st.crop) > 0.92f) continue
            steps += st
        }
        if (showCompleteAtEnd) steps += step(steps.size, overviewCamera, vp, page, panel, overview = true)
        return steps.mapIndexed { i, st -> st.copy(index = i) }
    }

    /**
     * Window start positions along one axis covering [lo, hi] with windows of length [win].
     * Greedy: advance by win·(1-overlap), but if that would cut a bubble that the window could
     * hold, pull the next window back so it starts at that bubble.
     */
    internal fun axisPositions(lo: Float, hi: Float, win: Float, bubbles: List<Pair<Float, Float>>, reverse: Boolean): List<Float> {
        val len = hi - lo
        if (len <= win) return listOf(lo + len / 2f - win / 2f)
        // Work in "reading coordinate" u where u=0 is the reading start.
        fun toU(a: Float, b: Float) = if (reverse) (hi - b) to (hi - a) else (a - lo) to (b - lo)
        val spans = bubbles.map { toU(it.first, it.second) }.filter { it.second - it.first <= win }
        val maxStart = len - win
        val stride = win * (1f - overlap)
        val starts = mutableListOf(0f)
        while (starts.last() < maxStart - 0.5f) {
            val p = starts.last()
            var next = min(p + stride, maxStart)
            val windowEnd = p + win
            // Bubbles cut by the current window's far edge: start the next window at them.
            val cut = spans.filter { it.first < windowEnd && it.second > windowEnd && it.first > p }
            if (cut.isNotEmpty()) {
                val pull = cut.minOf { it.first }
                if (pull > p + win * 0.25f) next = min(next, pull)
            }
            // Never leave a gap and always make progress.
            next = max(next, p + win * 0.25f)
            next = min(next, p + win)
            next = min(next, maxStart)
            starts += next
            if (starts.size > 64) break
        }
        val n = starts.size
        // Expected count sanity (purely informational guard against pathological loops).
        check(n <= max(64, ceil(len / (win * 0.25f)).toInt() + 1))
        return starts.map { u -> if (reverse) hi - u - win else lo + u }
    }

    private fun step(i: Int, cam: CameraState, vp: Viewport, page: SizeF, panel: Panel, overview: Boolean): CameraStep {
        val crop = cam.visibleRect(vp)
        val dialogue = panel.bubbles.indices.filter { crop.contains(panel.bubbles[it], tolerance = 0.5f) }
        return CameraStep(
            index = i,
            camera = cam,
            crop = crop,
            normalizedCenter = PointF(cam.centerX / page.width, cam.centerY / page.height),
            normalizedCrop = crop.normalized(page),
            dialogue = dialogue,
            overview = overview,
        )
    }

    private fun dist2(ax: Float, ay: Float, bx: Float, by: Float) = (ax - bx) * (ax - bx) + (ay - by) * (ay - by)
}
