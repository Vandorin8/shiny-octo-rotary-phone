package com.mangaflow.engine.layout

import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.geometry.unionArea
import com.mangaflow.engine.model.Bubble
import com.mangaflow.engine.model.LayoutConfidence
import com.mangaflow.engine.model.PageKind
import com.mangaflow.engine.model.PageLayout
import com.mangaflow.engine.model.Panel
import com.mangaflow.engine.model.PanelCandidate
import com.mangaflow.engine.model.ReadingDirection
import kotlin.math.max
import kotlin.math.min

/** How the reader behaves when page confidence is below threshold. */
enum class LowConfidenceFallback { FULL_PAGE, CONSERVATIVE_CROP, SUGGEST_REGIONS }

data class AssemblerConfig(
    val direction: ReadingDirection = ReadingDirection.RIGHT_TO_LEFT,
    val confidenceThreshold: Float = 0.45f,
    val fallback: LowConfidenceFallback = LowConfidenceFallback.FULL_PAGE,
    val speechBubbleProtection: Boolean = true,
    /** Extra margin for borderless panels, as a fraction of the page's short side. */
    val borderlessMarginFraction: Float = 0.015f,
)

/**
 * Turns fused candidates + bubbles into an ordered, confidence-scored [PageLayout].
 * Covers stages D (fusion), E (order), F (confidence) and section 4 (bubble protection).
 */
class LayoutAssembler(
    private val detectorVersion: Int,
    private val fusion: CandidateFusion = CandidateFusion(),
    private val orderAnalyzer: ReadingOrderAnalyzer = ReadingOrderAnalyzer(),
) {

    fun assemble(
        page: SizeF,
        contentBounds: RectF,
        classical: List<PanelCandidate>,
        ml: List<PanelCandidate>,
        bubbles: List<Bubble>,
        config: AssemblerConfig,
    ): PageLayout {
        val diagnostics = mutableListOf<String>()
        val pageRect = page.toRect()
        val fused = fusion.fuse(page, classical, ml)
        diagnostics += "candidates classical=${classical.size} ml=${ml.size} fused=${fused.size}"

        val contentArea = max(contentBounds.area, page.area * 0.25f)

        // ---- Full-page classification ----
        if (fused.isEmpty()) {
            return PageLayout.fullPage(page, config.direction, detectorVersion, "no panels detected").copy(
                confidence = LayoutConfidence(0.6f, 0.6f, 1f, 1f, 0.6f),
            )
        }
        val largest = fused.maxBy { it.bounds.area }
        val largestCoverage = largest.bounds.area / contentArea
        val othersInsideLargest = fused.all { it === largest || it.bounds.fractionInside(largest.bounds) >= 0.85f }
        if ((fused.size == 1 && largestCoverage >= 0.55f) || (largestCoverage >= 0.80f && othersInsideLargest)) {
            run {
                val conf = LayoutConfidence(largest.score, 0.9f, 1f, 1f, (0.6f + largestCoverage * 0.4f).coerceAtMost(1f))
                diagnostics += "classified as full-page illustration (coverage=${"%.2f".format(largestCoverage)})"
                return PageLayout.fullPage(page, config.direction, detectorVersion).copy(confidence = conf, diagnostics = diagnostics)
            }
        }

        // ---- Reading order ----
        val order = orderAnalyzer.analyze(fused.map { it.bounds }, config.direction)
        val ordered = order.order.map { fused[it] }

        // ---- Speech bubble attribution (section 4) ----
        val attribution = if (config.speechBubbleProtection) attributeBubbles(ordered.map { it.bounds }, bubbles)
        else BubbleAttribution(List(ordered.size) { emptyList() }, 1f)

        val margin = min(page.width, page.height) * config.borderlessMarginFraction
        val panels = ordered.mapIndexed { i, c ->
            val own = attribution.perPanel[i]
            var safe = c.bounds
            for (b in own) safe = safe.union(b)
            if (c.borderless) safe = safe.expand(margin)
            Panel(
                id = i,
                bounds = c.bounds,
                polygon = c.polygon,
                safeBounds = safe.clampTo(pageRect),
                confidence = c.score,
                bubbles = own,
                borderless = c.borderless,
            )
        }

        // ---- Confidence (stage F) ----
        val boundaryConf = run {
            val wsum = ordered.sumOf { it.bounds.area.toDouble() }
            val s = ordered.sumOf { (it.score * it.bounds.area).toDouble() } / wsum
            // Heavy mutual overlap between distinct panels suggests duplicated / wrong boxes.
            var overlapPenalty = 0f
            for (i in ordered.indices) for (j in i + 1 until ordered.size) {
                val iou = ordered[i].bounds.iou(ordered[j].bounds)
                if (iou > 0.3f) overlapPenalty += (iou - 0.3f)
            }
            (s.toFloat() - overlapPenalty).coerceIn(0f, 1f)
        }
        val coverage = (unionArea(ordered.map { it.bounds }) / contentArea).coerceAtMost(1f)
        val countConf = run {
            val cov = smoothstep(0.45f, 0.85f, coverage)
            val tooMany = if (ordered.size > 14) 0.5f else 1f
            (cov * tooMany).coerceIn(0.05f, 1f)
        }
        val confidence = LayoutConfidence(
            boundaries = boundaryConf,
            panelCount = countConf,
            readingOrder = order.confidence,
            dialogue = attribution.confidence,
            classification = 0.85f,
        )
        diagnostics += "coverage=${"%.2f".format(coverage)} order=${"%.2f".format(order.confidence)} overall=${"%.2f".format(confidence.overall)}"

        val base = PageLayout(
            pageSize = page,
            panels = panels,
            kind = PageKind.MULTI_PANEL,
            confidence = confidence,
            direction = config.direction,
            detectorVersion = detectorVersion,
            diagnostics = diagnostics,
        )
        if (confidence.overall >= config.confidenceThreshold) return base

        diagnostics += "low confidence → fallback ${config.fallback}"
        return when (config.fallback) {
            LowConfidenceFallback.FULL_PAGE, LowConfidenceFallback.SUGGEST_REGIONS ->
                // Keep the suggested panels so the editor can offer them for confirmation,
                // but navigate the page as a whole.
                base.copy(lowConfidenceFallback = true)
            LowConfidenceFallback.CONSERVATIVE_CROP -> {
                // Merge each top-level reading band into one larger region.
                val merged = order.topLevelGroups.mapIndexed { gi, group ->
                    val idx = group.map { order.order.indexOf(it) }
                    val members = idx.map { panels[it] }
                    val b = RectF.unionAll(members.map { it.bounds })!!
                    val s = RectF.unionAll(members.map { it.safeBounds })!!
                    Panel(gi, b, safeBounds = s, confidence = members.minOf { it.confidence }, bubbles = members.flatMap { it.bubbles })
                }
                base.copy(panels = merged, diagnostics = diagnostics)
            }
        }
    }

    data class BubbleAttribution(val perPanel: List<List<RectF>>, val confidence: Float)

    /**
     * Assigns each bubble to the most plausible panel. A bubble mostly inside one panel belongs
     * to it; when it straddles panels, the smallest panel holding most of it wins (insets);
     * ambiguity lowers the dialogue-containment confidence.
     */
    fun attributeBubbles(panels: List<RectF>, bubbles: List<Bubble>): BubbleAttribution {
        val per = List(panels.size) { mutableListOf<RectF>() }
        if (bubbles.isEmpty() || panels.isEmpty()) return BubbleAttribution(per, 1f)
        var ambiguous = 0f
        for (b in bubbles) {
            val fractions = panels.map { b.bounds.fractionInside(it) }
            val best = fractions.withIndex().filter { it.value > 0f }
                .sortedWith(compareByDescending<IndexedValue<Float>> { it.value }.thenBy { panels[it.index].area })
            if (best.isEmpty()) {
                // Floating text in a gutter: attach to the nearest panel if it is close.
                val nearest = panels.indices.minBy { gap(panels[it], b.bounds) }
                val d = gap(panels[nearest], b.bounds)
                if (d <= max(b.bounds.width, b.bounds.height)) {
                    per[nearest] += b.bounds
                    ambiguous += 0.5f
                } else ambiguous += 1f
                continue
            }
            // Prefer the smallest panel that holds the bubble almost entirely (inset panels).
            val holders = best.filter { it.value >= 0.9f }
            val chosen = holders.minByOrNull { panels[it.index].area } ?: best.first()
            per[chosen.index] += b.bounds
            val second = best.firstOrNull { it.index != chosen.index }?.value ?: 0f
            if (chosen.value < 0.6f && second > 0.25f) ambiguous += 1f
            else if (chosen.value < 0.9f) ambiguous += 0.25f
        }
        val conf = 1f - (ambiguous / bubbles.size) * 0.8f
        return BubbleAttribution(per, conf.coerceIn(0.05f, 1f))
    }

    private fun gap(a: RectF, b: RectF): Float {
        val dx = max(0f, max(a.left - b.right, b.left - a.right))
        val dy = max(0f, max(a.top - b.bottom, b.top - a.bottom))
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    private fun smoothstep(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3 - 2 * t)
    }
}
