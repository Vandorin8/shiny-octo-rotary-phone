package com.mangaflow.engine.learning

import com.mangaflow.engine.camera.LearnedBias
import com.mangaflow.engine.camera.PanelClass
import kotlin.math.abs
import kotlin.math.ln

/** A user adjustment observed by the reader. */
sealed class Adjustment {
    abstract val panelClass: PanelClass

    /** User pinched to a new scale and then kept reading with it. */
    data class Zoom(override val panelClass: PanelClass, val autoScale: Float, val userScale: Float, val heldMillis: Long) : Adjustment()

    /** User asked for the full panel instead of the automatic framing. */
    data class FullPanel(override val panelClass: PanelClass, val autoScale: Float, val fitScale: Float) : Adjustment()

    /** User skipped or disabled a cinematic reveal on this panel type. */
    data class RevealRejected(override val panelClass: PanelClass) : Adjustment()

    /** User let a reveal play out normally (counter-evidence to rejection). */
    data class RevealAccepted(override val panelClass: PanelClass) : Adjustment()
}

/**
 * Section 2.6: lightweight, on-device preference learning using running statistics.
 *
 * - Accidental gestures are ignored: a zoom must change scale by >12 % and be held ≥ 1.5 s.
 * - A class needs ≥ 3 consistent observations before its bias is applied.
 * - Bias is an exponentially-weighted mean of log(user/auto), clamped to ±0.6 (≈ ×0.55…×1.8).
 * - Reveal suppression needs ≥ 3 more rejections than acceptances.
 */
class PreferenceLearner(
    private val alpha: Float = 0.25f,
    private val minObservations: Int = 3,
    private val minHoldMillis: Long = 1500,
    private val minLogChange: Float = 0.12f,
    private val maxBias: Float = 0.6f,
) : LearnedBias {

    data class ClassStats(val n: Int = 0, val meanLog: Float = 0f, val revealNet: Int = 0)

    private val stats = mutableMapOf<PanelClass, ClassStats>()

    @Synchronized
    fun observe(a: Adjustment): Boolean {
        val s = stats[a.panelClass] ?: ClassStats()
        val updated = when (a) {
            is Adjustment.Zoom -> {
                if (a.heldMillis < minHoldMillis || a.autoScale <= 0f || a.userScale <= 0f) return false
                val l = ln(a.userScale / a.autoScale)
                if (abs(l) < minLogChange) return false
                s.withSample(l)
            }
            is Adjustment.FullPanel -> {
                if (a.fitScale <= 0f || a.autoScale <= 0f) return false
                val l = ln(a.fitScale / a.autoScale)
                if (abs(l) < minLogChange) return false
                s.withSample(l)
            }
            is Adjustment.RevealRejected -> s.copy(revealNet = (s.revealNet + 1).coerceAtMost(10))
            is Adjustment.RevealAccepted -> s.copy(revealNet = (s.revealNet - 1).coerceAtLeast(-10))
        }
        stats[a.panelClass] = updated
        return true
    }

    private fun ClassStats.withSample(l: Float): ClassStats {
        val mean = if (n == 0) l else meanLog + alpha * (l - meanLog)
        return copy(n = n + 1, meanLog = mean)
    }

    @Synchronized
    override fun logZoomBias(panelClass: PanelClass): Float {
        val s = stats[panelClass] ?: return 0f
        if (s.n < minObservations || abs(s.meanLog) < 0.05f) return 0f
        return s.meanLog.coerceIn(-maxBias, maxBias)
    }

    @Synchronized
    override fun suppressReveal(panelClass: PanelClass): Boolean = (stats[panelClass]?.revealNet ?: 0) >= 3

    @Synchronized
    fun reset() = stats.clear()

    @Synchronized
    fun snapshot(): Map<PanelClass, ClassStats> = stats.toMap()

    /** Compact string form for local persistence: CLASS:n:mean:net;... */
    @Synchronized
    fun serialize(): String = stats.entries.joinToString(";") { (k, v) -> "${k.name}:${v.n}:${v.meanLog}:${v.revealNet}" }

    @Synchronized
    fun restore(data: String?) {
        stats.clear()
        if (data.isNullOrBlank()) return
        for (part in data.split(';')) {
            val f = part.split(':')
            if (f.size != 4) continue
            val cls = runCatching { PanelClass.valueOf(f[0]) }.getOrNull() ?: continue
            val n = f[1].toIntOrNull() ?: continue
            val m = f[2].toFloatOrNull() ?: continue
            val r = f[3].toIntOrNull() ?: continue
            stats[cls] = ClassStats(n, m, r)
        }
    }
}
