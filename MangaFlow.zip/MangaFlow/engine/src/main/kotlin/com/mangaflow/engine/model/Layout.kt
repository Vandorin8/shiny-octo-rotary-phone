package com.mangaflow.engine.model

import com.mangaflow.engine.geometry.Polygon
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF

enum class ReadingDirection { RIGHT_TO_LEFT, LEFT_TO_RIGHT }

enum class CandidateSource { CLASSICAL, ML, FUSED, MANUAL }

/** A raw panel hypothesis produced by one detector. Coordinates are source-image pixels. */
data class PanelCandidate(
    val bounds: RectF,
    val polygon: Polygon? = null,
    /** 0..1 confidence from the producing detector. */
    val score: Float,
    val source: CandidateSource,
    /** 0..1: how much clean gutter / border surrounds this region. */
    val gutterEvidence: Float = 0f,
    /** True when the region has no drawn border (art bleeds into the gutter). */
    val borderless: Boolean = false,
)

/** A detected speech bubble or free-floating text region. */
data class Bubble(
    val bounds: RectF,
    val score: Float,
    /** Japanese vertical text columns detected inside. */
    val verticalText: Boolean = true,
)

enum class PageKind { MULTI_PANEL, FULL_PAGE, UNKNOWN }

/** Per-panel user override for cinematic reveal. */
enum class RevealOverride { DEFAULT, NEVER, ALWAYS }

data class Panel(
    val id: Int,
    /** Detected panel boundary (panel region). */
    val bounds: RectF,
    val polygon: Polygon? = null,
    /** Panel plus any dialogue / artwork margins that must stay visible (safe content region). */
    val safeBounds: RectF = bounds,
    val confidence: Float = 1f,
    /** Bubbles attributed to this panel. */
    val bubbles: List<RectF> = emptyList(),
    val borderless: Boolean = false,
    val revealOverride: RevealOverride = RevealOverride.DEFAULT,
    /** Extra safe margin in source pixels requested by the user in the editor. */
    val extraMargin: Float = 0f,
)

data class LayoutConfidence(
    val boundaries: Float,
    val panelCount: Float,
    val readingOrder: Float,
    val dialogue: Float,
    val classification: Float,
) {
    /** Weighted geometric-style mean: a single very weak component drags the total down. */
    val overall: Float
        get() {
            val parts = listOf(boundaries to 0.3f, panelCount to 0.2f, readingOrder to 0.25f, dialogue to 0.15f, classification to 0.1f)
            var logSum = 0.0
            for ((v, w) in parts) logSum += w * kotlin.math.ln(v.coerceIn(0.01f, 1f).toDouble())
            return kotlin.math.exp(logSum).toFloat()
        }

    companion object {
        val CERTAIN = LayoutConfidence(1f, 1f, 1f, 1f, 1f)
    }
}

/**
 * Final, ordered layout of one page. [panels] are already in reading order.
 */
data class PageLayout(
    val pageSize: SizeF,
    val panels: List<Panel>,
    val kind: PageKind,
    val confidence: LayoutConfidence,
    val direction: ReadingDirection,
    val detectorVersion: Int,
    val manual: Boolean = false,
    /** True when the engine decided the detection is too uncertain to navigate by panel. */
    val lowConfidenceFallback: Boolean = false,
    val diagnostics: List<String> = emptyList(),
) {
    companion object {
        fun fullPage(size: SizeF, direction: ReadingDirection, detectorVersion: Int, reason: String? = null) = PageLayout(
            pageSize = size,
            panels = listOf(Panel(0, size.toRect(), safeBounds = size.toRect())),
            kind = PageKind.FULL_PAGE,
            confidence = LayoutConfidence.CERTAIN,
            direction = direction,
            detectorVersion = detectorVersion,
            diagnostics = listOfNotNull(reason),
        )
    }
}
