package com.mangaflow.engine.layout

import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.geometry.unionArea
import com.mangaflow.engine.model.CandidateSource
import com.mangaflow.engine.model.PanelCandidate

/**
 * Stage D: fuses classical-CV and ML panel candidates.
 *
 * Strategy:
 *  1. Drop fragments that are too small to be panels.
 *  2. Match classical <-> ML candidates by IoU; matched pairs become a score-weighted box
 *     with noisy-OR confidence (agreement between independent detectors is strong evidence).
 *  3. Unmatched candidates survive with a penalty.
 *  4. Non-maximum suppression only at HIGH IoU, so genuinely overlapping manga panels
 *     (diagonal cuts, insets, broken borders) are not discarded just because boxes intersect.
 *  5. "Container" suppression: a region whose area is mostly explained by >= 2 smaller
 *     candidates is a merged multi-panel hypothesis and is removed.
 */
class CandidateFusion(
    private val minAreaFraction: Float = 0.010f,
    private val matchIou: Float = 0.55f,
    private val nmsIou: Float = 0.72f,
    private val unmatchedPenalty: Float = 0.85f,
    private val minScore: Float = 0.25f,
) {

    fun fuse(page: SizeF, classical: List<PanelCandidate>, ml: List<PanelCandidate>): List<PanelCandidate> {
        val minArea = page.area * minAreaFraction
        val c = classical.filter { it.bounds.area >= minArea }
        val m = ml.filter { it.bounds.area >= minArea }

        val fused = mutableListOf<PanelCandidate>()
        val usedMl = BooleanArray(m.size)

        for (cc in c) {
            var bestIdx = -1
            var bestIou = 0f
            for (j in m.indices) {
                if (usedMl[j]) continue
                val iou = cc.bounds.iou(m[j].bounds)
                if (iou > bestIou) { bestIou = iou; bestIdx = j }
            }
            if (bestIdx >= 0 && bestIou >= matchIou) {
                usedMl[bestIdx] = true
                fused += merge(cc, m[bestIdx])
            } else {
                fused += cc.copy(score = cc.score * unmatchedPenalty)
            }
        }
        for (j in m.indices) if (!usedMl[j]) fused += m[j].copy(score = m[j].score * unmatchedPenalty)

        val afterNms = nms(fused.filter { it.score >= minScore })
        return suppressContainers(afterNms)
    }

    private fun merge(a: PanelCandidate, b: PanelCandidate): PanelCandidate {
        val wa = a.score.coerceAtLeast(0.01f)
        val wb = b.score.coerceAtLeast(0.01f)
        fun avg(x: Float, y: Float) = (x * wa + y * wb) / (wa + wb)
        val box = RectF(
            avg(a.bounds.left, b.bounds.left), avg(a.bounds.top, b.bounds.top),
            avg(a.bounds.right, b.bounds.right), avg(a.bounds.bottom, b.bounds.bottom),
        )
        // Prefer whichever polygon describes a non-rectangular shape better.
        val poly = listOfNotNull(a.polygon, b.polygon).minByOrNull { it.rectangularity }
            ?.takeIf { it.rectangularity < 0.92f }
        val score = 1f - (1f - a.score) * (1f - b.score)
        return PanelCandidate(
            bounds = box,
            polygon = poly,
            score = score.coerceAtMost(0.99f),
            source = CandidateSource.FUSED,
            gutterEvidence = maxOf(a.gutterEvidence, b.gutterEvidence),
            borderless = a.borderless && b.borderless,
        )
    }

    private fun nms(cands: List<PanelCandidate>): List<PanelCandidate> {
        val sorted = cands.sortedByDescending { it.score }
        val keep = mutableListOf<PanelCandidate>()
        for (c in sorted) {
            if (keep.none { it.bounds.iou(c.bounds) >= nmsIou }) keep += c
        }
        return keep
    }

    private fun suppressContainers(cands: List<PanelCandidate>): List<PanelCandidate> {
        val result = cands.toMutableList()
        var changed = true
        while (changed) {
            changed = false
            for (container in result.sortedByDescending { it.bounds.area }) {
                val inner = result.filter {
                    it !== container && it.bounds.area < container.bounds.area * 0.9f &&
                        it.bounds.fractionInside(container.bounds) >= 0.85f
                }
                if (inner.size >= 2) {
                    val covered = unionArea(inner.map { it.bounds.intersect(container.bounds) ?: it.bounds })
                    if (covered >= container.bounds.area * 0.70f) {
                        result.remove(container)
                        changed = true
                        break
                    }
                }
            }
        }
        return result
    }
}
