package com.mangaflow.engine

import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.geometry.unionArea
import com.mangaflow.engine.layout.AssemblerConfig
import com.mangaflow.engine.layout.CandidateFusion
import com.mangaflow.engine.layout.LayoutAssembler
import com.mangaflow.engine.layout.LayoutNode
import com.mangaflow.engine.layout.LowConfidenceFallback
import com.mangaflow.engine.layout.ReadingOrderAnalyzer
import com.mangaflow.engine.model.Bubble
import com.mangaflow.engine.model.CandidateSource
import com.mangaflow.engine.model.PageKind
import com.mangaflow.engine.model.PanelCandidate
import com.mangaflow.engine.model.ReadingDirection.LEFT_TO_RIGHT
import com.mangaflow.engine.model.ReadingDirection.RIGHT_TO_LEFT
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ReadingOrderTest {
    private val ro = ReadingOrderAnalyzer()

    @Test fun gridIsReadRightToLeftThenTopToBottom() {
        val tl = RectF(20f, 20f, 490f, 700f)
        val tr = RectF(510f, 20f, 980f, 700f)
        val bl = RectF(20f, 720f, 490f, 1400f)
        val br = RectF(510f, 720f, 980f, 1400f)
        val r = ro.analyze(listOf(tl, tr, bl, br), RIGHT_TO_LEFT)
        assertEquals(listOf(1, 0, 3, 2), r.order)
        assertEquals(1f, r.confidence)
    }

    @Test fun leftToRightGrid() {
        val tl = RectF(20f, 20f, 490f, 700f)
        val tr = RectF(510f, 20f, 980f, 700f)
        val bl = RectF(20f, 720f, 490f, 1400f)
        val r = ro.analyze(listOf(bl, tr, tl), LEFT_TO_RIGHT)
        assertEquals(listOf(2, 1, 0), r.order)
    }

    @Test fun tallRightPanelBeforeStackedLeftPanels() {
        // Naive (y, x) sorting would read top-left before the tall right panel's bottom half.
        val tall = RectF(600f, 20f, 980f, 1400f)
        val leftTop = RectF(20f, 20f, 580f, 700f)
        val leftBottom = RectF(20f, 720f, 580f, 1400f)
        val r = ro.analyze(listOf(leftBottom, leftTop, tall), RIGHT_TO_LEFT)
        assertEquals(listOf(2, 1, 0), r.order)
        assertTrue(r.tree is LayoutNode.Columns)
    }

    @Test fun mixedRowsWithDifferentColumnCounts() {
        val wide = RectF(20f, 20f, 980f, 400f)
        val r2a = RectF(20f, 420f, 320f, 900f)
        val r2b = RectF(340f, 420f, 650f, 900f)
        val r2c = RectF(670f, 420f, 980f, 900f)
        val last = RectF(20f, 920f, 980f, 1400f)
        val r = ro.analyze(listOf(last, r2a, wide, r2c, r2b), RIGHT_TO_LEFT)
        assertEquals(listOf(2, 3, 4, 1, 0), r.order)
    }

    @Test fun slightlyOverlappingDiagonalGutterStillSeparates() {
        // Diagonal gutter: bounding boxes overlap by a few pixels.
        val a = RectF(500f, 20f, 980f, 720f)
        val b = RectF(20f, 20f, 520f, 700f)
        val r = ro.analyze(listOf(b, a), RIGHT_TO_LEFT)
        assertEquals(listOf(1, 0), r.order)
        assertEquals(1f, r.confidence)
    }

    @Test fun inseparableOverlapLowersConfidence() {
        val big = RectF(20f, 20f, 980f, 1000f)
        val inset = RectF(600f, 400f, 900f, 700f)
        val r = ro.analyze(listOf(big, inset), RIGHT_TO_LEFT)
        assertEquals(2, r.order.size)
        assertTrue(r.confidence < 1f)
    }
}

class FusionTest {
    private val page = SizeF(1000f, 1400f)
    private fun c(r: RectF, s: Float, src: CandidateSource) = PanelCandidate(r, score = s, source = src)

    @Test fun agreeingDetectorsFuseWithHigherConfidence() {
        val a = c(RectF(20f, 20f, 490f, 700f), 0.7f, CandidateSource.CLASSICAL)
        val b = c(RectF(25f, 18f, 495f, 690f), 0.6f, CandidateSource.ML)
        val out = CandidateFusion().fuse(page, listOf(a), listOf(b))
        assertEquals(1, out.size)
        assertEquals(CandidateSource.FUSED, out[0].source)
        assertTrue(out[0].score > 0.85f)
    }

    @Test fun overlappingPanelsAreNotDiscarded() {
        val a = c(RectF(20f, 20f, 600f, 700f), 0.8f, CandidateSource.CLASSICAL)
        val b = c(RectF(400f, 20f, 980f, 700f), 0.8f, CandidateSource.CLASSICAL)
        assertTrue(a.bounds.iou(b.bounds) in 0.1f..0.4f)
        assertEquals(2, CandidateFusion().fuse(page, listOf(a, b), emptyList()).size)
    }

    @Test fun mergedContainerIsSuppressed() {
        val p1 = c(RectF(20f, 20f, 490f, 700f), 0.8f, CandidateSource.CLASSICAL)
        val p2 = c(RectF(510f, 20f, 980f, 700f), 0.8f, CandidateSource.CLASSICAL)
        val both = c(RectF(20f, 20f, 980f, 700f), 0.9f, CandidateSource.ML)
        val out = CandidateFusion().fuse(page, listOf(p1, p2), listOf(both))
        assertEquals(2, out.size)
        assertTrue(out.none { it.bounds.width > 900f })
    }

    @Test fun tinyFragmentsDropped() {
        val tiny = c(RectF(10f, 10f, 40f, 40f), 0.9f, CandidateSource.CLASSICAL)
        assertTrue(CandidateFusion().fuse(page, listOf(tiny), emptyList()).isEmpty())
    }
}

class AssemblerTest {
    private val page = SizeF(1000f, 1400f)
    private val assembler = LayoutAssembler(detectorVersion = 3)
    private fun c(r: RectF, s: Float = 0.85f) = PanelCandidate(r, score = s, source = CandidateSource.CLASSICAL, gutterEvidence = 0.9f)

    private val grid = listOf(
        c(RectF(20f, 20f, 490f, 690f)), c(RectF(510f, 20f, 980f, 690f)),
        c(RectF(20f, 710f, 490f, 1380f)), c(RectF(510f, 710f, 980f, 1380f)),
    )

    @Test fun bubbleCrossingBorderExpandsSafeRegionOfOwningPanel() {
        val bubble = Bubble(RectF(700f, 600f, 820f, 760f), 0.9f) // mostly in top-right panel, spills down
        val layout = assembler.assemble(page, RectF(20f, 20f, 980f, 1380f), grid, emptyList(), listOf(bubble), AssemblerConfig())
        val first = layout.panels[0] // top-right is first in RTL
        assertEquals(510f, first.bounds.left)
        assertTrue(first.safeBounds.contains(bubble.bounds))
        assertTrue(layout.panels.drop(1).none { it.bubbles.contains(bubble.bounds) })
    }

    @Test fun noCandidatesMeansFullPage() {
        val layout = assembler.assemble(page, page.toRect(), emptyList(), emptyList(), emptyList(), AssemblerConfig())
        assertEquals(PageKind.FULL_PAGE, layout.kind)
        assertEquals(1, layout.panels.size)
    }

    @Test fun splashPageClassifiedAsFullPage() {
        val layout = assembler.assemble(page, RectF(20f, 20f, 980f, 1380f), listOf(c(RectF(25f, 25f, 975f, 1375f))), emptyList(), emptyList(), AssemblerConfig())
        assertEquals(PageKind.FULL_PAGE, layout.kind)
    }

    @Test fun lowCoverageTriggersFallback() {
        val weak = listOf(c(RectF(20f, 20f, 300f, 300f), 0.4f), c(RectF(700f, 900f, 980f, 1200f), 0.35f))
        val layout = assembler.assemble(page, RectF(20f, 20f, 980f, 1380f), weak, emptyList(), emptyList(), AssemblerConfig())
        assertTrue(layout.lowConfidenceFallback, layout.diagnostics.joinToString())
    }

    @Test fun conservativeCropMergesBands() {
        val weak = grid.map { it.copy(score = 0.3f) }
        val layout = assembler.assemble(
            page, RectF(20f, 20f, 980f, 1380f), weak, emptyList(), emptyList(),
            AssemblerConfig(fallback = LowConfidenceFallback.CONSERVATIVE_CROP, confidenceThreshold = 0.9f),
        )
        assertEquals(2, layout.panels.size) // two rows
        assertTrue(unionArea(layout.panels.map { it.bounds }) > 0.9f * 960f * 1360f)
    }

    @Test fun confidentGridKeepsPanelNavigation() {
        val layout = assembler.assemble(page, RectF(20f, 20f, 980f, 1380f), grid, emptyList(), emptyList(), AssemblerConfig())
        assertEquals(4, layout.panels.size)
        assertTrue(!layout.lowConfidenceFallback, layout.diagnostics.joinToString())
    }
}
