package com.mangaflow.engine

import com.mangaflow.engine.camera.CameraState
import com.mangaflow.engine.camera.FramingStrategy
import com.mangaflow.engine.camera.NavResult
import com.mangaflow.engine.camera.PagePlan
import com.mangaflow.engine.camera.PanelClass
import com.mangaflow.engine.camera.PlanBuilder
import com.mangaflow.engine.camera.ReadingNavigator
import com.mangaflow.engine.camera.ReadingPosition
import com.mangaflow.engine.camera.RevealPlanner
import com.mangaflow.engine.camera.Viewport
import com.mangaflow.engine.camera.ZoomEngine
import com.mangaflow.engine.geometry.RectF
import com.mangaflow.engine.geometry.SizeF
import com.mangaflow.engine.layout.PageCorrection
import com.mangaflow.engine.layout.PanelEdits
import com.mangaflow.engine.learning.Adjustment
import com.mangaflow.engine.learning.PreferenceLearner
import com.mangaflow.engine.model.LayoutConfidence
import com.mangaflow.engine.model.PageKind
import com.mangaflow.engine.model.PageLayout
import com.mangaflow.engine.model.Panel
import com.mangaflow.engine.model.ReadingDirection
import com.mangaflow.engine.model.RevealOverride
import com.mangaflow.engine.settings.BookOverrides
import com.mangaflow.engine.settings.ReaderSettings
import com.mangaflow.engine.settings.ReadingSizePreset
import com.mangaflow.engine.settings.RevealMode
import org.junit.Test
import kotlin.random.Random
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertTrue

private val PAGE = SizeF(1600f, 2400f)
private val PHONE = Viewport(1080f, 2200f)

private fun layoutOf(vararg panels: Panel, kind: PageKind = PageKind.MULTI_PANEL) =
    PageLayout(PAGE, panels.toList(), kind, LayoutConfidence.CERTAIN, ReadingDirection.RIGHT_TO_LEFT, 1)

class ZoomEngineTest {
    private val zoom = ZoomEngine()
    private val settings = ReaderSettings()

    @Test fun uniformScaleAlwaysPreservesAspect() {
        val p = Panel(0, RectF(100f, 100f, 900f, 700f))
        val f = zoom.frame(p, layoutOf(p), PHONE, settings)
        val cam = CameraState(f.content.centerX, f.content.centerY, f.scale)
        val vis = cam.visibleRect(PHONE)
        assertEquals(PHONE.aspect, vis.aspect, 1e-3f)
    }

    @Test fun smallPanelIsEnlargedButCapped() {
        val p = Panel(0, RectF(100f, 100f, 400f, 300f))
        val f = zoom.frame(p, layoutOf(p), PHONE, settings)
        assertEquals(PanelClass.SMALL, f.panelClass)
        assertEquals(FramingStrategy.FIT_WHOLE, f.strategy)
        assertTrue(f.scale > PHONE.width / PAGE.width, "small panel should be magnified beyond page-fit")
        assertTrue(f.scale <= f.fitScale + 1e-4f)
        assertTrue(f.scale <= 3.0f)
    }

    @Test fun tallOversizedPanelUsesRevealInAutomatic() {
        val p = Panel(0, RectF(500f, 50f, 1100f, 2350f))
        val f = zoom.frame(p, layoutOf(p), PHONE, settings.copy(sizePreset = ReadingSizePreset.EXTRA_LARGE))
        assertEquals(PanelClass.TALL, f.panelClass)
        assertEquals(FramingStrategy.PROGRESSIVE_REVEAL, f.strategy)
        assertTrue(f.scale > f.fitScale)
    }

    @Test fun revealOffAlwaysFitsWholePanel() {
        val p = Panel(0, RectF(50f, 50f, 1450f, 2350f))
        val f = zoom.frame(p, layoutOf(p), PHONE, settings.copy(revealMode = RevealMode.OFF, sizePreset = ReadingSizePreset.EXTRA_LARGE))
        assertEquals(FramingStrategy.FIT_WHOLE, f.strategy)
        assertEquals(f.fitScale, f.scale, 1e-4f)
    }

    @Test fun splashPageStaysWholeUnlessPanelOverrideSaysAlways() {
        val p = Panel(0, PAGE.toRect())
        val s = settings.copy(sizePreset = ReadingSizePreset.EXTRA_LARGE, revealMode = RevealMode.ALWAYS_FOR_OVERSIZED)
        assertEquals(FramingStrategy.FIT_WHOLE, zoom.frame(p, layoutOf(p, kind = PageKind.FULL_PAGE), PHONE, s).strategy)
        val forced = p.copy(revealOverride = RevealOverride.ALWAYS)
        assertEquals(FramingStrategy.PROGRESSIVE_REVEAL, zoom.frame(forced, layoutOf(forced, kind = PageKind.FULL_PAGE), PHONE, s).strategy)
    }

    @Test fun revealScaleNeverCutsTheLargestBubble() {
        val bubble = RectF(200f, 200f, 1300f, 700f) // very wide bubble
        val p = Panel(0, RectF(50f, 50f, 1550f, 2350f), bubbles = listOf(bubble))
        val f = zoom.frame(p, layoutOf(p), PHONE, settings.copy(sizePreset = ReadingSizePreset.EXTRA_LARGE))
        val windowW = PHONE.width / f.scale
        assertTrue(windowW >= bubble.width, "bubble ${bubble.width} must fit window $windowW")
    }

    @Test fun readingSizeIsConsistentAcrossOrientation() {
        val p = Panel(0, RectF(100f, 100f, 1500f, 2300f))
        val l = layoutOf(p)
        val portrait = zoom.desiredScale(l, Viewport(1080f, 2200f), 0.5f)
        val landscape = zoom.desiredScale(l, Viewport(2200f, 1080f), 0.5f)
        assertEquals(portrait, landscape, 1e-4f)
    }

    @Test fun largerPresetMeansLargerScale() {
        val p = Panel(0, RectF(100f, 100f, 1500f, 2300f))
        val l = layoutOf(p)
        val values = ReadingSizePreset.entries.filter { it != ReadingSizePreset.CUSTOM }.map { zoom.desiredScale(l, PHONE, it.value) }
        assertEquals(values.sorted(), values)
    }
}

class RevealPlannerTest {
    private val zoom = ZoomEngine()
    private val planner = RevealPlanner()
    private val xl = ReaderSettings(sizePreset = ReadingSizePreset.EXTRA_LARGE)

    @Test fun tallPanelRevealsTopToBottomThenShowsWhole() {
        val bubbles = listOf(RectF(900f, 150f, 1150f, 600f), RectF(300f, 1100f, 550f, 1500f), RectF(800f, 1900f, 1050f, 2250f))
        val p = Panel(0, RectF(100f, 50f, 1300f, 2350f), bubbles = bubbles)
        val f = zoom.frame(p, layoutOf(p), PHONE, xl)
        assertEquals(FramingStrategy.PROGRESSIVE_REVEAL, f.strategy)
        val steps = planner.plan(p, f, PAGE, PHONE, ReadingDirection.RIGHT_TO_LEFT, showCompleteAtEnd = true)
        assertTrue(steps.size >= 3, "expected ≥ 2 reveal steps + overview, got ${steps.size}")
        val reveal = steps.dropLast(1)
        assertEquals(reveal.map { it.crop.top }.sorted(), reveal.map { it.crop.top }, "top-to-bottom")
        assertTrue(steps.last().overview)
        assertTrue(steps.last().crop.contains(f.content, tolerance = 1f))
        // Every bubble fully visible in at least one reveal step.
        for (b in bubbles.indices) assertTrue(reveal.any { b in it.dialogue }, "bubble $b omitted")
        // Steps overlap: no gaps.
        for (i in 1 until reveal.size) assertTrue(reveal[i].crop.top <= reveal[i - 1].crop.bottom)
        // Coverage of the content's vertical extent.
        assertTrue(reveal.first().crop.top <= f.content.top + 1f && reveal.last().crop.bottom >= f.content.bottom - 1f)
    }

    @Test fun widePanelRevealsRightToLeftInJapaneseMode() {
        val land = Viewport(1080f, 1600f)
        val p = Panel(0, RectF(50f, 200f, 1550f, 900f))
        val f = zoom.frame(p, layoutOf(p), land, xl)
        assertEquals(FramingStrategy.PROGRESSIVE_REVEAL, f.strategy)
        val steps = planner.plan(p, f, PAGE, land, ReadingDirection.RIGHT_TO_LEFT, true).dropLast(1)
        assertTrue(steps.size >= 2)
        assertEquals(steps.map { it.crop.left }.sortedDescending(), steps.map { it.crop.left })
        val ltr = planner.plan(p, f, PAGE, land, ReadingDirection.LEFT_TO_RIGHT, true).dropLast(1)
        assertEquals(ltr.map { it.crop.left }.sorted(), ltr.map { it.crop.left })
    }

    @Test fun stepsStayInsideImageAndKeepAspect() {
        val p = Panel(0, RectF(0f, 0f, 1600f, 2400f), revealOverride = RevealOverride.ALWAYS)
        val f = zoom.frame(p, layoutOf(p), PHONE, xl)
        for (s in planner.plan(p, f, PAGE, PHONE, ReadingDirection.RIGHT_TO_LEFT, true)) {
            assertTrue(s.overview || PAGE.toRect().contains(s.crop, tolerance = 0.5f), "crop ${s.crop} outside page")
            assertEquals(PHONE.aspect, s.crop.aspect, 1e-3f)
            assertTrue(s.normalizedCenter.x in 0f..1f && s.normalizedCenter.y in 0f..1f)
        }
    }

    @Test fun showCompleteDisabledDropsOverview() {
        val p = Panel(0, RectF(100f, 50f, 1300f, 2350f))
        val f = zoom.frame(p, layoutOf(p), PHONE, xl)
        val steps = planner.plan(p, f, PAGE, PHONE, ReadingDirection.RIGHT_TO_LEFT, showCompleteAtEnd = false)
        assertFalse(steps.last().overview)
    }

    @Test fun disablingRevealRestoresSingleStepPanels() {
        val p = Panel(0, RectF(100f, 50f, 1300f, 2350f))
        val plan = PlanBuilder().build(0, layoutOf(p), PHONE, xl.copy(revealMode = RevealMode.OFF))
        assertEquals(1, plan.panels[0].size)
    }

    @Test fun axisPositionsPullBackToAvoidCuttingBubble() {
        // Window 1000, content 0..2500; a bubble at 900..1300 would be cut by the first window.
        val pos = planner.axisPositions(0f, 2500f, 1000f, listOf(900f to 1300f), reverse = false)
        assertTrue(pos.any { it <= 900f && it + 1000f >= 1300f }, "positions $pos")
        assertEquals(0f, pos.first())
        assertEquals(1500f, pos.last())
    }
}

class NavigatorTest {
    private fun randomPlans(seed: Int, pages: Int): List<PagePlan> {
        val rnd = Random(seed)
        val builder = PlanBuilder()
        return (0 until pages).map { pg ->
            val stub = builder.fullPage(pg, PAGE, PHONE, provisional = false)
            val step = stub.panels[0][0]
            val panels = (0 until rnd.nextInt(1, 7)).map { List(rnd.nextInt(1, 5)) { i -> step.copy(index = i) } }
            PagePlan(pg, panels, panels.map { null }, provisional = false)
        }
    }

    @Test fun forwardThenBackwardIsIdentityAndVisitsEveryStopOnce() {
        val plans = randomPlans(7, 5)
        val nav = ReadingNavigator(plans.size) { plans[it] }
        val visited = mutableListOf(ReadingPosition(0, 0, 0))
        while (true) {
            val r = nav.forward(visited.last())
            if (r is NavResult.EndOfBook) break
            visited += (r as NavResult.Moved).position
        }
        val total = plans.sumOf { p -> p.panels.sumOf { it.size } }
        assertEquals(total, visited.size)
        assertEquals(total, visited.map { Triple(it.page, it.panel, it.step) }.toSet().size, "no duplicated stops")
        // Walk back.
        val back = mutableListOf(visited.last())
        while (true) {
            val r = nav.backward(back.last())
            if (r is NavResult.StartOfBook) break
            back += (r as NavResult.Moved).position
        }
        assertEquals(visited.map { Triple(it.page, it.panel, it.step) }, back.reversed().map { Triple(it.page, it.panel, it.step) })
    }

    @Test fun lastStepAdvancesToFirstPanelOfNextPage() {
        val plans = randomPlans(3, 2)
        val nav = ReadingNavigator(2) { plans[it] }
        val p0 = plans[0]
        val last = ReadingPosition(0, p0.lastPanel, p0.lastStep(p0.lastPanel))
        assertEquals(ReadingPosition(1, 0, 0), (nav.forward(last) as NavResult.Moved).position)
        assertIs<NavResult.EndOfBook>(nav.forward(ReadingPosition(1, plans[1].lastPanel, plans[1].lastStep(plans[1].lastPanel))))
    }

    @Test fun provisionalPageReconcilesToCorrectEdge() {
        val plans = randomPlans(11, 2)
        val nav = ReadingNavigator(2) { plans[it] }
        val provisional = PlanBuilder().fullPage(1, PAGE, PHONE, provisional = true)
        val real = plans[1]
        val fromEnd = nav.reconcile(ReadingPosition(1, 0, 0, enteredFromEnd = true), provisional, real)
        assertEquals(real.lastPanel, fromEnd.panel)
        assertEquals(real.lastStep(real.lastPanel), fromEnd.step)
        assertEquals(ReadingPosition(1, 0, 0), nav.reconcile(ReadingPosition(1, 0, 0), provisional, real))
    }

    @Test fun orientationChangeKeepsPanel() {
        val p1 = Panel(0, RectF(100f, 50f, 1300f, 1150f))
        val p2 = Panel(1, RectF(100f, 1200f, 1300f, 2350f))
        val l = layoutOf(p1, p2)
        val portrait = PlanBuilder().build(0, l, PHONE, ReaderSettings())
        val land = PlanBuilder().build(0, l, Viewport(2200f, 1080f), ReaderSettings())
        val nav = ReadingNavigator(1) { portrait }
        val pos = nav.reconcile(ReadingPosition(0, 1, portrait.lastStep(1)), portrait, land)
        assertEquals(1, pos.panel)
        assertEquals(land.lastStep(1), pos.step)
    }
}

class LearnerTest {
    @Test fun accidentalGesturesIgnoredAndBiasNeedsConsistency() {
        val l = PreferenceLearner()
        assertFalse(l.observe(Adjustment.Zoom(PanelClass.TALL, 1f, 1.5f, heldMillis = 300)))
        assertFalse(l.observe(Adjustment.Zoom(PanelClass.TALL, 1f, 1.05f, heldMillis = 5000)))
        repeat(2) { l.observe(Adjustment.Zoom(PanelClass.TALL, 1f, 1.4f, 4000)) }
        assertEquals(0f, l.logZoomBias(PanelClass.TALL))
        l.observe(Adjustment.Zoom(PanelClass.TALL, 1f, 1.4f, 4000))
        assertTrue(l.logZoomBias(PanelClass.TALL) > 0.2f)
        assertEquals(0f, l.logZoomBias(PanelClass.WIDE))
    }

    @Test fun revealSuppressionResetAndPersistence() {
        val l = PreferenceLearner()
        repeat(3) { l.observe(Adjustment.RevealRejected(PanelClass.WIDE)) }
        assertTrue(l.suppressReveal(PanelClass.WIDE))
        val copy = PreferenceLearner().apply { restore(l.serialize()) }
        assertTrue(copy.suppressReveal(PanelClass.WIDE))
        l.reset()
        assertFalse(l.suppressReveal(PanelClass.WIDE))
    }

    @Test fun biasIsClamped() {
        val l = PreferenceLearner()
        repeat(10) { l.observe(Adjustment.Zoom(PanelClass.LARGE, 1f, 10f, 4000)) }
        assertEquals(0.6f, l.logZoomBias(PanelClass.LARGE))
    }
}

class CorrectionsAndSettingsTest {
    @Test fun splitInRightToLeftPutsRightHalfFirst() {
        val c = PageCorrection(listOf(com.mangaflow.engine.layout.EditedPanel(RectF(0f, 0f, 1f, 0.5f))))
        val s = PanelEdits.split(c, 0, vertical = true, fraction = 0.5f, direction = ReadingDirection.RIGHT_TO_LEFT)
        assertEquals(2, s.panels.size)
        assertEquals(0.5f, s.panels[0].bounds.left)
        assertEquals(0f, s.panels[1].bounds.left)
    }

    @Test fun mergeReorderAndManualLayoutPriority() {
        var c = PageCorrection(emptyList())
        c = PanelEdits.add(c, RectF(0.5f, 0f, 1f, 0.5f))
        c = PanelEdits.add(c, RectF(0f, 0f, 0.5f, 0.5f))
        c = PanelEdits.add(c, RectF(0f, 0.5f, 1f, 1f))
        c = PanelEdits.move(c, 2, 0)
        assertEquals(0.5f, c.panels[0].bounds.top)
        c = PanelEdits.merge(c, setOf(1, 2))
        assertEquals(2, c.panels.size)
        assertEquals(RectF(0f, 0f, 1f, 0.5f), c.panels[1].bounds)
        c = PanelEdits.setReveal(c, 1, RevealOverride.NEVER)
        val layout = c.toLayout(PAGE, ReadingDirection.RIGHT_TO_LEFT, 1)
        assertTrue(layout.manual)
        assertEquals(RevealOverride.NEVER, layout.panels[1].revealOverride)
        assertEquals(800f * 2, layout.panels[1].bounds.width)
        assertEquals(PageKind.FULL_PAGE, PanelEdits.markFullPage(c, true).toLayout(PAGE, ReadingDirection.RIGHT_TO_LEFT, 1).kind)
    }

    @Test fun defaultsMatchSpecAndOverridesApply() {
        val g = ReaderSettings()
        assertEquals(ReadingSizePreset.BALANCED, g.sizePreset)
        assertEquals(RevealMode.AUTOMATIC, g.revealMode)
        assertTrue(g.showCompletePanelAfterReveal && g.speechBubbleProtection && !g.learnPreferences)
        val o = BookOverrides(revealMode = RevealMode.OFF, direction = ReadingDirection.LEFT_TO_RIGHT)
        val eff = o.applyTo(g)
        assertEquals(RevealMode.OFF, eff.revealMode)
        assertEquals(ReadingDirection.LEFT_TO_RIGHT, eff.direction)
        assertEquals(g.sizePreset, eff.sizePreset)
        assertEquals(RevealMode.AUTOMATIC, g.revealMode, "global untouched")
    }

    @Test fun cameraInterpolationEndpointsAndMonotoneScale() {
        val a = CameraState(100f, 100f, 0.5f)
        val b = CameraState(900f, 1500f, 2f)
        val start = CameraState.lerp(a, b, 0f)
        assertEquals(a.centerX, start.centerX, 1e-3f)
        assertEquals(a.scale, start.scale, 1e-5f)
        val end = CameraState.lerp(a, b, 1f)
        assertEquals(b.centerX, end.centerX, 1e-2f)
        assertEquals(b.scale, end.scale, 1e-4f)
        var last = 0f
        for (i in 0..10) { val s = CameraState.lerp(a, b, i / 10f).scale; assertTrue(s >= last); last = s }
    }
}

